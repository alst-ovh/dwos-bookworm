#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-pihole.update.sh - Update or Generate Pi-Hole Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  06.08.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-pihole.config'
config_header='/var/dwsetup/header/dw-pihole.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Docker Container Settings"
    dw_conf_line
    echo
    dw_conf_var "DOCKER_CPUS"
    echo
    dw_conf_var "DOCKER_MEM_LIMIT"
    echo
    dw_conf_line
    echo "# Settings for Pi-Hole"
    dw_conf_line
    dw_conf_line
    echo "# General Settings setupVars.conf pihole-FTL.conf"
    dw_conf_line
    dw_conf_var "PIHOLE_WEBPORT"
    dw_conf_comment "# Pi-Hole Port, Default 8003"
    echo
    dw_conf_var "PIHOLE_WEBPASSWORD"
    dw_conf_comment "# Pi-Hole Web Password"
    echo
    dw_conf_var "PIHOLE_DNS"
    dw_conf_comment "# Upstream DNS Server's, separated by a semicolon"
    echo
    dw_conf_var "PIHOLE_ADMIN_EMAIL"
    dw_conf_comment "# Admin Email"
    echo
    dw_conf_var "PIHOLE_BLOCKING_ENABLED"
    dw_conf_comment "# Enable Blocking yes or no"
    echo
    dw_conf_var "PIHOLE_QUERY_LOGGING"
    dw_conf_comment "# Enable Query Logging yes or no"
    echo
    dw_conf_var "PIHOLE_DNSMASQ_LISTENING"
    dw_conf_comment "# DNSMASQ Interface Listening < local | single | bind | all >"
    echo
    dw_conf_var "PIHOLE_DBINTERVAL"
    dw_conf_comment "# How often do we store queries in FTL's database < minutes >"
    echo
    dw_conf_var "PIHOLE_MAXDBDAYS"
    dw_conf_comment "# How long should queries be stored in the database, 0 disables the database"
    echo
    dw_conf_var "PIHOLE_PRIVACYLEVEL"
    dw_conf_comment "# Privacy Level < 0 | 1 | 2 | 3 >"
    echo
    dw_conf_var "PIHOLE_CACHE_SIZE"
    dw_conf_comment "# Cache Size deault 10000"
    echo
    dw_conf_line
    echo "# DHCP Settings setupVars.conf"
    dw_conf_line
    echo
    dw_conf_var "PIHOLE_DHCP"
    dw_conf_comment "# Enable DHCP yes or no"
    dw_conf_var "PIHOLE_DHCP_RANGE_START"
    dw_conf_var "PIHOLE_DHCP_RANGE_END"
    dw_conf_var "PIHOLE_DHCP_ROUTER"
    dw_conf_var "PIHOLE_DHCP_LEASETIME"
    dw_conf_var "PIHOLE_DHCP_RAPID_COMMIT"
    dw_conf_comment "# Enable DHCP Rapid Commit yes or no"
    dw_conf_var "PIHOLE_DHCP_IPV6"
    dw_conf_comment "# Enable DHCP IPv6 yes or no"
    echo
    dw_conf_line
    echo "# Settings /etc/dnsmasq.d/01-dw-pihole.conf"
    echo "# Domain is from Base Settings"
    echo "# (Prefix a PIHOLE_PARAM_x with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "PIHOLE_PARAM_N"
    dw_conf_comment "# Number of Params"
    idx='1'
    while [ "$idx" -le "$PIHOLE_PARAM_N" ]
    do
      eval dns_param='$PIHOLE_PARAM_'$idx
      echo "PIHOLE_PARAM_"$idx"=""'$dns_param'"
      idx=$(expr $idx + 1)
    done
    echo
    dw_conf_line
    echo "# DHCP Settings /etc/dnsmasq.d/04-pihole-static-dhcp.conf"
    echo "#"
    echo "# (Prefix a PIHOLE_DHCP_HOST_x_NAME with a ! to Disable it)"
    dw_conf_line
    echo
    echo "PIHOLE_DHCP_HOST_N=""'$PIHOLE_DHCP_HOST_N'"
    dw_conf_comment "# Number of Fixed Hosts"
    echo
    idx='1'
    while [ "$idx" -le "$PIHOLE_DHCP_HOST_N" ]
    do
      eval dns_name='$PIHOLE_DHCP_HOST_'$idx'_NAME'
      eval dns_mac='$PIHOLE_DHCP_HOST_'$idx'_MAC'
      eval dns_ip='$PIHOLE_DHCP_HOST_'$idx'_IP'
      echo "PIHOLE_DHCP_HOST_"$idx"_NAME=""'$dns_name'"
      echo "PIHOLE_DHCP_HOST_"$idx"_MAC=""'$dns_mac'"
      echo "PIHOLE_DHCP_HOST_"$idx"_IP=""'$dns_ip'"
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_line
    echo "# DNS Settings"
    echo "#"
    echo "# (Prefix a PIHOLE_DNS_HOST_x_NAME with a ! to Disable it)"
    echo "# (With a . in PIHOLE_DNS_HOST_x_NAME no Domain will be added)"
    echo "# (Prefix a PIHOLE_DNS_HOST_x_ALIAS_x with a ! to Disable it)"
    dw_conf_line
    echo
    echo "PIHOLE_DNS_HOST_N=""'$PIHOLE_DNS_HOST_N'"
    dw_conf_comment "# Number of Hosts"
    idx='1'
    while [ "$idx" -le "$PIHOLE_DNS_HOST_N" ]
    do
      eval dns_host_name='$PIHOLE_DNS_HOST_'$idx'_NAME'
      eval dns_host_ip='$PIHOLE_DNS_HOST_'$idx'_IP'
      eval dns_host_alias_n='$PIHOLE_DNS_HOST_'$idx'_ALIAS_N'
      echo "PIHOLE_DNS_HOST_"$idx"_NAME=""'$dns_host_name'"
      echo "PIHOLE_DNS_HOST_"$idx"_IP=""'$dns_host_ip'"
      echo "PIHOLE_DNS_HOST_"$idx"_ALIAS_N=""'$dns_host_alias_n'"
      idxa='1'
      while [ "$idxa" -le "$dns_host_alias_n" ]
      do
        eval dns_host_alias='$PIHOLE_DNS_HOST_'$idx'_ALIAS_'$idxa
        echo "PIHOLE_DNS_HOST_"$idx"_ALIAS_$idxa=""'$dns_host_alias'"
        idxa=$(/usr/bin/expr $idxa + 1)
      done
      idx=$(/usr/bin/expr $idx + 1)
      echo
    done
    dw_conf_footer
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
