#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-cups.sh - Configuration Generator Script for Cups
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwcups_conf_dir='/etc/dw-cups'
dwcups_conf_file="$dwcups_conf_dir/docker-dw-cups/.env"
dwcups_docker_compose_override_file="$dwcups_conf_dir/docker-dw-cups/docker-compose.override.yaml"

#----------------------------------------------------------------------------------------
# Create Cups Configuration File
#----------------------------------------------------------------------------------------
create_dwcups_conf_file() {
  dw_echo_colmsg "==> Create Cups Config File $dwcups_conf_file ..." 1
  (
    echo "# Data Directory"
    echo
    echo 'DATA_DIR="'$DATA_DIR'"'
  ) >$dwcups_conf_file
}

#----------------------------------------------------------------------------------------
# Create Cups Docker Compose Override File
#----------------------------------------------------------------------------------------
create_dwcups_docker_compose_override_file() {
  dw_echo_colmsg "==> Create Cups Docker Compose Override File $dwcups_docker_compose_override_file ..." 1
  (
    echo "services:"
    echo "  dwcups:"
    echo "    environment:"
    echo "      ADMIN_UID: $(docker_get_uid)"
    echo "      ADMIN_GID: $(docker_get_gid)"
    echo "      ADMIN_PASSWORD: $ADMIN_PASSWORD"
    #if [ -n "$DOCKER_CPUS" ]; then
    #  echo "    cpus: $DOCKER_CPUS"
    #fi
    #if [ -n "$DOCKER_MEM_LIMIT" ]; then
    #  echo "    mem_limit: $DOCKER_MEM_LIMIT"
    #fi
    if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
      echo
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_CPUS" ]; then
        #echo "    cpus: $DOCKER_CPUS"
        echo "          cpus: '$DOCKER_CPUS'"
      fi
      if [ -n "$DOCKER_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_MEM_LIMIT"
        echo "          memory: '$DOCKER_MEM_LIMIT'"
      fi
    fi
  ) >$dwcups_docker_compose_override_file
}

#-------------------------------------------------------------------------------
# Restart Other Services
#-------------------------------------------------------------------------------
restart_services ()
{
  do_restart ()
  {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
  do_restart apache2
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-cups.config

create_dwcups_conf_file
create_dwcups_docker_compose_override_file
dwcups compose 1
if [ -f /var/dwsetup/config.d/dw-printers.sh ]; then
   sleep 6
   /var/dwsetup/config.d/dw-printers.sh $quiet
fi
restart_services

#===============================================================================
# End
#===============================================================================
exit 0
