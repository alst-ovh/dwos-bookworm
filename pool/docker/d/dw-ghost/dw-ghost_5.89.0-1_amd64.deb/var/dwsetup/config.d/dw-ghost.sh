#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-ghost.sh - Configuration Generator Script for Ghost
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  06.08.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwghost_conf_dir='/etc/dw-ghost'
dwghost_conf_file="$dwghost_conf_dir/docker-dw-ghost/.env"
dwghost_docker_compose_override_file="$dwghost_conf_dir/docker-dw-ghost/docker-compose.override.yaml"
dwghost_mysql_init_file="$dwghost_conf_dir/mysql.init"
dwghost_mysqldump_conf_file="$dwghost_conf_dir/mysqldump.conf"

#----------------------------------------------------------------------------------------
# Create DW-Ghost Configuration File
#----------------------------------------------------------------------------------------
create_dwghost_conf_file ()
{
  dw_echo_colmsg "==> Create Ghost Config File $dwghost_conf_file ..." 1
  (
  echo "# Data Directory"
  echo
  echo 'DATA_DIR="'$DATA_DIR'"'
  echo
  echo "# ghost environment:"
  echo
  echo 'GHOST_URL="'$GHOST_URL'"'
  echo
  echo 'GHOST_DATABASE_CLIENT="'$GHOST_DATABASE_CLIENT'"'
  echo 'GHOST_DATABASE_CONNECTION_HOST="'$GHOST_DATABASE_CONNECTION_HOST'"'
  echo 'GHOST_DATABASE_CONNECTION_USER="'$GHOST_DATABASE_CONNECTION_USER'"'
  echo 'GHOST_DATABASE_CONNECTION_PASSWORD="'$GHOST_DATABASE_CONNECTION_PASSWORD'"'
  echo 'GHOST_DATABASE_CONNECTION_DATABASE="'$GHOST_DATABASE_CONNECTION_DATABASE'"'
  echo
  if [ "$GHOST_MAIL" == "yes" ]; then
    echo 'GHOST_MAIL_TRANSPORT="'$GHOST_MAIL_TRANSPORT'"'
    echo 'GHOST_MAIL_FROM="'$GHOST_MAIL_FROM'"'
    echo 'GHOST_MAIL_OPTIONS_HOST="'$GHOST_MAIL_OPTIONS_HOST'"'
    echo 'GHOST_MAIL_OPTIONS_PORT="'$GHOST_MAIL_OPTIONS_PORT'"'
    echo 'GHOST_MAIL_OPTIONS_AUTH_USER="'$GHOST_MAIL_OPTIONS_AUTH_USER'"'
    echo 'GHOST_MAIL_OPTIONS_AUTH_PASS="'$GHOST_MAIL_OPTIONS_AUTH_PASS'"'
    echo
  fi
  echo "# mysql environment:"
  echo
  echo 'MYSQL_ROOT_PASSWORD="'$GHOST_MYSQL_ROOT_PASSWORD'"'
  ) > $dwghost_conf_file
}

#----------------------------------------------------------------------------------------
# Create Ghost Docker Compose Override File
#----------------------------------------------------------------------------------------
create_dwghost_docker_compose_override_file ()
{
  if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_DB_CPUS" -o -n "$DOCKER_MEM_LIMIT" -o -n "$DOCKER_DB_MEM_LIMIT" ]; then
    dw_echo_colmsg "==> Create Ghost Docker Compose Override File $dwghost_docker_compose_override_file ..." 1
    (
    #echo "version: '3.1'"
    #echo
    echo "services:"
    if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
      echo "  ghost:"
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_CPUS" ]; then
        #echo "    cpus: $DOCKER_CPUS"
        echo "          cpus: $DOCKER_CPUS"
      fi
      if [ -n "$DOCKER_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_MEM_LIMIT"
        echo "          memory: $DOCKER_MEM_LIMIT"
      fi
    fi
    if [ -n "$DOCKER_DB_CPUS" -o -n "$DOCKER_DB_MEM_LIMIT" ]; then
      echo
      echo "  db:"
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_DB_CPUS" ]; then
        #echo "    cpus: $DOCKER_DB_CPUS"
        echo "          cpus: $DOCKER_DB_CPUS"
      fi
      if [ -n "$DOCKER_DB_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_DB_MEM_LIMIT"
        echo "          memory: $DOCKER_DB_MEM_LIMIT"
      fi
    fi
    ) > $dwghost_docker_compose_override_file
  else
    rm -f $dwghost_docker_compose_override_file
  fi
}

#----------------------------------------------------------------------------------------
# Create DW-Ghost Docker Configuration File
#----------------------------------------------------------------------------------------
create_dwghost_mysql_init_file ()
{
  dw_echo_colmsg "==> Create Ghost Mysql Init File $dwghost_mysql_init_file ..." 1
  (
    #echo "DROP USER IF EXISTS 'root'@'%';"
    echo "ALTER USER IF EXISTS 'root'@'localhost' IDENTIFIED BY '$GHOST_MYSQL_ROOT_PASSWORD';"
    echo "CREATE USER IF NOT EXISTS '$GHOST_DATABASE_CONNECTION_USER'@'%' IDENTIFIED BY '$GHOST_MYSQL_ROOT_PASSWORD';"
    echo "ALTER USER IF EXISTS '$GHOST_DATABASE_CONNECTION_USER'@'%' IDENTIFIED BY '$GHOST_DATABASE_CONNECTION_PASSWORD';"
    echo "CREATE DATABASE IF NOT EXISTS $GHOST_DATABASE_CONNECTION_DATABASE;"
    echo "GRANT ALL PRIVILEGES ON $GHOST_DATABASE_CONNECTION_DATABASE.* TO '$GHOST_DATABASE_CONNECTION_USER'@'%';"
    echo "FLUSH PRIVILEGES;"
  ) > $dwghost_mysql_init_file
}

#----------------------------------------------------------------------------------------
# Create DW-Ghost mysqldump Configuration File
#----------------------------------------------------------------------------------------
create_dwghost_mysqldump_conf_file ()
{
  dw_echo_colmsg "==> Create Ghost mysqldump Config File $dwghost_mysqldump_conf_file ..." 1
  (
  echo "[mysql]"
  echo "user = root"
  echo "password = $GHOST_MYSQL_ROOT_PASSWORD"
  echo
  echo "[mysqldump]"
  echo "user = root"
  echo "password = $GHOST_MYSQL_ROOT_PASSWORD"
  ) > $dwghost_mysqldump_conf_file
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-ghost.config

GHOST_DATABASE_CLIENT="mysql"
GHOST_DATABASE_CONNECTION_HOST="db"
GHOST_DATABASE_CONNECTION_USER="ghost"
GHOST_DATABASE_CONNECTION_DATABASE="ghost"

create_dwghost_conf_file
create_dwghost_docker_compose_override_file
create_dwghost_mysql_init_file
create_dwghost_mysqldump_conf_file
dwghost compose 1

#===============================================================================
# End
#===============================================================================
exit 0
