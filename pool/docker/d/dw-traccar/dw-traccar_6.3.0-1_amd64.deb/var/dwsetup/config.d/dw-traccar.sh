#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-traccar.sh - Configuration Generator Script for Traccar
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  06.08.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwtraccar_conf_dir='/etc/dw-traccar'
dwtraccar_conf_file="$dwtraccar_conf_dir/traccar.xml"
dwtraccar_docker_compose_override_file="$dwtraccar_conf_dir/docker-dw-traccar/docker-compose.override.yaml"
dwtraccar_docker_conf_file="$dwtraccar_conf_dir/docker-dw-traccar/.env"
dwtraccar_docker_mysql_init_file="$dwtraccar_conf_dir/mysql.init"
dwtraccar_docker_mysqldump_conf_file="$dwtraccar_conf_dir/mysqldump.conf"
dwtraccar_docker_mysqltraccar_conf_file="$dwtraccar_conf_dir/mysqltraccar.conf"

dwtraccar_cleardb_cron_file_daily='/etc/cron.daily/traccar-cleardb'
dwtraccar_clearlog_cron_file_daily='/etc/cron.daily/traccar-clearlog'

#-------------------------------------------------------------------------------
# Create Traccar Config File /opt/traccar/conf/traccar.xml
#-------------------------------------------------------------------------------
create_traccar_config_file() {
  dw_echo_colmsg "==> Create Traccar Config File $dwtraccar_conf_file ..." 1
  (
    echo "<?xml version='1.0' encoding='UTF-8'?>"
    echo
    echo "<!DOCTYPE properties SYSTEM 'http://java.sun.com/dtd/properties.dtd'>"
    echo
    echo "<properties>"
    echo
    echo "    <entry key='config.default'>./conf/default.xml</entry>"
    echo
    echo "    <!--"
    echo
    echo "    This is the main configuration file. All your configuration parameters should be placed in this file."
    echo
    echo '    Default configuration parameters are located in the "default.xml" file. You should not modify it to avoid issues'
    echo "    with upgrading to a new version. Parameters in the main config file override values in the default file. Do not"
    echo '    remove "config.default" parameter from this file unless you know what you are doing.'
    echo
    echo "    For list of available parameters see following page: https://www.traccar.org/configuration-file/"
    echo
    echo "    -->"
    echo
    echo "  <!-- Mysql Database -->"
    echo "    <entry key='database.driver'>com.mysql.cj.jdbc.Driver</entry>"
    echo "    <entry key='database.url'>jdbc:$TRACCAR_DATABASE_CLIENT://$TRACCAR_DATABASE_CONNECTION_HOST:3306/$TRACCAR_DATABASE_CONNECTION_DATABASE?serverTimezone=UTC&amp;allowPublicKeyRetrieval=true&amp;useSSL=false&amp;allowMultiQueries=true&amp;autoReconnect=true&amp;useUnicode=yes&amp;characterEncoding=UTF-8&amp;sessionVariables=sql_mode=''</entry>"
    echo "    <entry key='database.user'>$TRACCAR_DATABASE_CONNECTION_USER</entry>"
    echo "    <entry key='database.password'>$TRACCAR_DATABASE_CONNECTION_PASSWORD</entry>"
    echo "  <!-- Web URL -->"
    echo "    <entry key='web.url'>$TRACCAR_WEB_URL</entry>"
    echo "  <!-- Statistics -->"
    echo "    <entry key='server.statistics'></entry>"
    echo "  <!-- Logging -->"
    echo "    <entry key='logger.enable'>$(dw_conf_yesno_to_bool "$TRACCAR_LOG_ENABLED")</entry>"
    if [ -z "$TRACCAR_LOG_LEVEL" ]; then
      TRACCAR_LOG_LEVEL='info'
    fi
    echo "    <entry key='logger.console'>true</entry>"
    echo "    <entry key='logger.level'>$TRACCAR_LOG_LEVEL</entry>"
    #echo "    <entry key='logger.file'>/opt/traccar/logs/tracker-server.log</entry>"
    #echo "    <entry key='logger.rotate'>true</entry>"
    echo "  <!-- Overspeed -->"
    echo "    <entry key='event.overspeed.notRepeat'>$(dw_conf_yesno_to_bool "$TRACCAR_OVERSPEED_NOTREPEAT")</entry>"
    echo "  <!-- Geocoder -->"
    echo "    <entry key='geocoder.enable'>$(dw_conf_yesno_to_bool "$TRACCAR_GEOCODER_ENABLED")</entry>"
    echo "    <entry key='geocoder.type'>$TRACCAR_GEOCODER_TYPE</entry>"
    echo "    <entry key='geocoder.url'>$TRACCAR_GEOCODER_URL</entry>"
    echo "    <entry key='geocoder.onRequest'>$(dw_conf_yesno_to_bool "$TRACCAR_GEOCODER_ONREQUEST")</entry>"
    echo "  <!-- Notification Types -->"
    echo "    <entry key='notificator.types'>$TRACCAR_NOTIFICATION_TYPES</entry>"
    echo "  <!-- Mail Settings -->"
    echo "    <entry key='mail.smtp.host'>$TRACCAR_NOTIFICATION_MAIL_SMTP_HOST</entry>"
    echo "    <entry key='mail.smtp.port'>$TRACCAR_NOTIFICATION_MAIL_SMTP_PORT</entry>"
    echo "    <entry key='mail.smtp.starttls.enable'>$(dw_conf_yesno_to_bool "$TRACCAR_NOTIFICATION_MAIL_SMTP_STARTTLS")</entry>"
    echo "    <entry key='mail.smtp.from'>$TRACCAR_NOTIFICATION_MAIL_SMTP_FROM</entry>"
    echo "    <entry key='mail.smtp.auth'>$(dw_conf_yesno_to_bool "$TRACCAR_NOTIFICATION_MAIL_SMTP_AUTH")</entry>"
    echo "    <entry key='mail.smtp.username'>$TRACCAR_NOTIFICATION_MAIL_SMTP_USERNAME</entry>"
    echo "    <entry key='mail.smtp.password'>$TRACCAR_NOTIFICATION_MAIL_SMTP_PASSWORD</entry>"
    if [ -n "$TRACCAR_NOTIFICATION_TELEGRAM_KEY" -a -n "$TRACCAR_NOTIFICATION_TELEGRAM_CHATID" ]; then
      echo "  <!-- Notification Telegram -->"
      echo "    <entry key='notificator.telegram.key'>$TRACCAR_NOTIFICATION_TELEGRAM_KEY</entry>"
      echo "    <entry key='notificator.telegram.chatId'>$TRACCAR_NOTIFICATION_TELEGRAM_CHATID</entry>"
    fi
  ) >$dwtraccar_conf_file
  (
    echo
    echo "</properties>"
  ) >>$dwtraccar_conf_file
}

#----------------------------------------------------------------------------------------
# Create Traccar Docker Configuration File
#----------------------------------------------------------------------------------------
create_dwtraccar_docker_conf_file ()
{
  dw_echo_colmsg "==> Create Traccar Docker Config File $dwtraccar_docker_conf_file ..." 1
  (
  echo "# Data Directory"
  echo
  echo 'DATA_DIR="'$DATA_DIR'"'
  echo
  echo "# traccar environment:"
  echo
  echo 'TRACCAR_DATABASE_CLIENT="'$TRACCAR_DATABASE_CLIENT'"'
  echo 'TRACCAR_DATABASE_CONNECTION_HOST="'$TRACCAR_DATABASE_CONNECTION_HOST'"'
  echo 'TRACCAR_DATABASE_CONNECTION_USER="'$TRACCAR_DATABASE_CONNECTION_USER'"'
  echo 'TRACCAR_DATABASE_CONNECTION_PASSWORD="'$TRACCAR_DATABASE_CONNECTION_PASSWORD'"'
  echo 'TRACCAR_DATABASE_CONNECTION_DATABASE="'$TRACCAR_DATABASE_CONNECTION_DATABASE'"'
  echo
  echo "# mysql environment:"
  echo
  echo 'MYSQL_ROOT_PASSWORD="'$TRACCAR_MYSQL_ROOT_PASSWORD'"'
  ) > $dwtraccar_docker_conf_file
}

#----------------------------------------------------------------------------------------
# Create Traccar Docker Compose Override File
#----------------------------------------------------------------------------------------
create_dwtraccar_docker_compose_override_file ()
{
  dw_echo_colmsg "==> Create Traccar Docker Compose Override File $dwtraccar_docker_compose_override_file ..." 1
  (
  #echo "version: '3.1'"
  #echo
  echo "services:"
  echo "  traccar:"
  echo "    ports:"
  echo "      - $TRACCAR_PORT:8082"
  for port in $TRACCAR_DEVICE_PORTS
  do
    echo "      - $port:$port"
  done
  #if [ -n "$DOCKER_CPUS" ]; then
  #  echo "    cpus: $DOCKER_CPUS"
  #fi
  #if [ -n "$DOCKER_MEM_LIMIT" ]; then
  #  echo "    mem_limit: $DOCKER_MEM_LIMIT"
  #fi
  #if [ -n "$DOCKER_DB_CPUS" -o -n "$DOCKER_DB_MEM_LIMIT" ]; then
  #  echo
  #  echo "  db:"
  #  if [ -n "$DOCKER_DB_CPUS" ]; then
  #    echo "    cpus: $DOCKER_DB_CPUS"
  #  fi
  #  if [ -n "$DOCKER_DB_MEM_LIMIT" ]; then
  #    echo "    mem_limit: $DOCKER_DB_MEM_LIMIT"
  #  fi
  #fi
    if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
      echo
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_CPUS" ]; then
        #echo "    cpus: $DOCKER_CPUS"
        echo "          cpus: $DOCKER_CPUS"
      fi
      if [ -n "$DOCKER_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_MEM_LIMIT"
        echo "          memory: $DOCKER_MEM_LIMIT"
      fi
    fi
    if [ -n "$DOCKER_DB_CPUS" -o -n "$DOCKER_DB_MEM_LIMIT" ]; then
      echo
      echo "  db:"
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_DB_CPUS" ]; then
        #echo "    cpus: $DOCKER_DB_CPUS"
        echo "          cpus: $DOCKER_DB_CPUS"
      fi
      if [ -n "$DOCKER_DB_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_DB_MEM_LIMIT"
        echo "          memory: $DOCKER_DB_MEM_LIMIT"
      fi
    fi
  ) > $dwtraccar_docker_compose_override_file
}

#----------------------------------------------------------------------------------------
# Create Traccar Docker Mysql Init Configuration File
#----------------------------------------------------------------------------------------
create_dwtraccar_docker_mysql_init_file ()
{
  dw_echo_colmsg "==> Create Traccar Docker Mysql Init File $dwtraccar_docker_mysql_init_file ..." 1
  (
    #echo "DROP USER IF EXISTS 'root'@'%';"
    echo "ALTER USER IF EXISTS 'root'@'localhost' IDENTIFIED BY '$TRACCAR_MYSQL_ROOT_PASSWORD';"
    echo "CREATE USER IF NOT EXISTS '$TRACCAR_DATABASE_CONNECTION_USER'@'%' IDENTIFIED BY '$TRACCAR_MYSQL_ROOT_PASSWORD';"
    echo "ALTER USER IF EXISTS '$TRACCAR_DATABASE_CONNECTION_USER'@'%' IDENTIFIED BY '$TRACCAR_DATABASE_CONNECTION_PASSWORD';"
    echo "CREATE DATABASE IF NOT EXISTS $TRACCAR_DATABASE_CONNECTION_DATABASE CHARACTER SET utf8 COLLATE utf8_bin;"
    echo "GRANT ALL PRIVILEGES ON $TRACCAR_DATABASE_CONNECTION_DATABASE.* TO '$TRACCAR_DATABASE_CONNECTION_USER'@'%';"
    echo "FLUSH PRIVILEGES;"
  ) > $dwtraccar_docker_mysql_init_file
}

#----------------------------------------------------------------------------------------
# Create Traccar Docker mysqldump Configuration File
#----------------------------------------------------------------------------------------
create_dwtraccar_docker_mysqldump_conf_file ()
{
  dw_echo_colmsg "==> Create Traccar Docker mysqldump Config File $dwtraccar_docker_mysqldump_conf_file ..." 1
  (
  echo "[mysql]"
  echo "user = root"
  echo "password = $TRACCAR_MYSQL_ROOT_PASSWORD"
  echo
  echo "[mysqldump]"
  echo "user = root"
  echo "password = $TRACCAR_MYSQL_ROOT_PASSWORD"
  ) > $dwtraccar_docker_mysqldump_conf_file
}

#----------------------------------------------------------------------------------------
# Create Traccar Docker mysqltraccar Configuration File
#----------------------------------------------------------------------------------------
create_dwtraccar_docker_mysqltraccar_conf_file ()
{
  dw_echo_colmsg "==> Create Traccar Docker mysqltraccar Config File $dwtraccar_docker_mysqltraccar_conf_file ..." 1
  (
  echo "[mysql]"
  echo "user = $TRACCAR_DATABASE_CONNECTION_USER"
  echo "password = $TRACCAR_DATABASE_CONNECTION_PASSWORD"
  ) > $dwtraccar_docker_mysqltraccar_conf_file
}

#----------------------------------------------------------------------------------------
# Check Traccar ClearLog Cron File
#----------------------------------------------------------------------------------------
check_dwtraccar_clearlog_cron_file() {
  dw_echo_colmsg "==> Check Traccar ClearLog Cron File ..." 1

  dw_echo_colmsg "==> Create Traccar ClearLog Cron File $dwtraccar_clearlog_cron_file_daily ..." 2
  (
    echo "#!/bin/bash"
    echo 'MAILTO=""'
    echo "/sbin/dwtraccar clearlog force >/dev/null"
  ) >$dwtraccar_clearlog_cron_file_daily
  chmod 0744 $dwtraccar_clearlog_cron_file_daily

  systemctl restart cron
}

#----------------------------------------------------------------------------------------
# Check Traccar ClearDB Cron File
#----------------------------------------------------------------------------------------
check_dwtraccar_cleardb_cron_file() {
  dw_echo_colmsg "==> Check Traccar ClearDB Cron File ..." 1
  local remove_cron_file='no'

  if [ "$TRACCAR_CLEARDB_DAILY" = "yes" ]; then
    dw_echo_colmsg "==> ClearDB Cron Daily Enabled, create Traccar ClearDB Cron File $dwtraccar_cleardb_cron_file_daily ..." 2
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      echo "/sbin/dwtraccar cleardb force >/dev/null"
    ) >$dwtraccar_cleardb_cron_file_daily
    chmod 0744 $dwtraccar_cleardb_cron_file_daily
    remove_cron_file='no'
  else
    remove_cron_file='yes'
  fi

  if [ "$remove_cron_file" = 'yes' ]; then
    dw_echo_colmsg "==> ClearDB Cron Daily Disabled, remove Traccar ClearDB Cron File $dwtraccar_cleardb_cron_file_daily ..." 2
    rm -f $dwtraccar_cleardb_cron_file_daily
  fi

  systemctl restart cron
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-traccar.config

if [ -z "$TRACCAR_PORT" ]; then
  TRACCAR_PORT='8082'
fi

TRACCAR_DATABASE_CLIENT="mysql"
TRACCAR_DATABASE_CONNECTION_HOST="db"
TRACCAR_DATABASE_CONNECTION_USER="traccar"
TRACCAR_DATABASE_CONNECTION_DATABASE="traccar"

create_traccar_config_file
create_dwtraccar_docker_conf_file
create_dwtraccar_docker_compose_override_file
create_dwtraccar_docker_mysql_init_file
create_dwtraccar_docker_mysqldump_conf_file
create_dwtraccar_docker_mysqltraccar_conf_file
check_dwtraccar_cleardb_cron_file
check_dwtraccar_clearlog_cron_file
dwtraccar compose 1

#===============================================================================
# End
#===============================================================================
exit 0
