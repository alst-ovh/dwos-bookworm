#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-traccar.update.sh - Update or Generate Traccar Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  06.08.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-traccar.config'
config_header='/var/dwsetup/header/dw-traccar.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Docker Container Settings"
    dw_conf_line
    echo
    dw_conf_var "DOCKER_CPUS"
    echo
    dw_conf_var "DOCKER_MEM_LIMIT"
    echo
    dw_conf_var "DOCKER_DB_CPUS"
    echo
    dw_conf_var "DOCKER_DB_MEM_LIMIT"
    echo
    dw_conf_line
    echo "# Settings for DW-Traccar"
    dw_conf_line
    echo
    dw_conf_var "TRACCAR_DATABASE_CONNECTION_PASSWORD"
    dw_conf_comment "# Database Password"
    dw_conf_var "TRACCAR_MYSQL_ROOT_PASSWORD"
    dw_conf_comment "# Mysql Root Password"
    echo
    dw_conf_var "TRACCAR_PORT"
    dw_conf_comment "# Traccar Port, Default 8082"
    echo
    dw_conf_var "TRACCAR_DEVICE_PORTS"
    dw_conf_comment "# Traccar Device Ports, see https://www.traccar.org/devices"
    echo
    dw_conf_var "TRACCAR_WEB_URL"
    dw_conf_comment "# Web URL Used for notification"
    echo
    dw_conf_var "TRACCAR_GEOCODER_ENABLED"
    dw_conf_comment "# Enable Geocoder yes or no"
    dw_conf_var "TRACCAR_GEOCODER_TYPE"
    dw_conf_comment "# Geocoder Type"
    dw_conf_var "TRACCAR_GEOCODER_URL"
    dw_conf_comment "# Geocoder URL"
    dw_conf_var "TRACCAR_GEOCODER_ONREQUEST"
    dw_conf_comment "# Perform Geocoding when preparing reports and sending notifications yes or no"
    echo
    dw_conf_var "TRACCAR_NOTIFICATION_TYPES"
    dw_conf_comment "# Notification Types"
    echo
    dw_conf_var "TRACCAR_NOTIFICATION_MAIL_SMTP_HOST"
    dw_conf_comment "# SMTP Host"
    dw_conf_var "TRACCAR_NOTIFICATION_MAIL_SMTP_PORT"
    dw_conf_comment "# SMTP Port"
    dw_conf_var "TRACCAR_NOTIFICATION_MAIL_SMTP_STARTTLS"
    dw_conf_comment "# SMTP Start TLS yes or no"
    dw_conf_var "TRACCAR_NOTIFICATION_MAIL_SMTP_FROM"
    dw_conf_comment "# SMTP From"
    dw_conf_var "TRACCAR_NOTIFICATION_MAIL_SMTP_AUTH"
    dw_conf_comment "# SMTP Auth yes or no"
    dw_conf_var "TRACCAR_NOTIFICATION_MAIL_SMTP_USERNAME"
    dw_conf_comment "# SMTP Username"
    dw_conf_var "TRACCAR_NOTIFICATION_MAIL_SMTP_PASSWORD"
    dw_conf_comment "# SMTP Password"
    echo
    dw_conf_var "TRACCAR_NOTIFICATION_TELEGRAM_KEY"
    dw_conf_comment "# Telegram API Key"
    dw_conf_var "TRACCAR_NOTIFICATION_TELEGRAM_CHATID"
    dw_conf_comment "# Telegram Chat ID"
    echo
    dw_conf_var "TRACCAR_OVERSPEED_NOTREPEAT"
    dw_conf_comment "# Disable Repeated Overspeed Warning yes or no"
    echo
    dw_conf_var "TRACCAR_LOG_ENABLED"
    dw_conf_comment "# Log yes or no"
    dw_conf_var "TRACCAR_LOG_LEVEL"
    dw_conf_comment "# Log Level < off | severe | warning | info | config | fine | finer | finest | all >, if empty info is used"
    echo
    dw_conf_var "TRACCAR_CLEARDB_DAYS"
    dw_conf_comment "# Database Max Days"
    dw_conf_var "TRACCAR_CLEARDB_DAILY"
    dw_conf_comment "# Run Clear Database Daily yes or no"
    dw_conf_footer e
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
