#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-portainer.sh - Configuration Generator Script for Portainer
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  14.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwportainer_conf_dir='/etc/dw-portainer'
dwportainer_conf_file="$dwportainer_conf_dir/docker-dw-portainer/.env"
dwportainer_docker_compose_override_file="$dwportainer_conf_dir/docker-dw-portainer/docker-compose.override.yaml"

#----------------------------------------------------------------------------------------
# Create Portainer Configuration File
#----------------------------------------------------------------------------------------
create_dwportainer_conf_file ()
{
  dw_echo_colmsg "==> Create Portainer Config File $dwportainer_conf_file ..." 1
  (
    echo "# Data Directory"
    echo
    echo 'DATA_DIR="'$DATA_DIR'"'
  ) > $dwportainer_conf_file
}

#----------------------------------------------------------------------------------------
# Create Portainer Docker Compose Override File
#----------------------------------------------------------------------------------------
create_dwportainer_docker_compose_override_file ()
{
  dw_echo_colmsg "==> Create Portainer Docker Compose Override File $dwportainer_docker_compose_override_file ..." 1
  (
  #echo "version: '3.1'"
  #echo
  echo "services:"
  echo "  dwportainer:"
  echo "    ports:"
  echo "      - $PORTAINER_PORT:9000"
  #if [ -n "$DOCKER_CPUS" ]; then
  #  echo "    cpus: $DOCKER_CPUS"
  #fi
  #if [ -n "$DOCKER_MEM_LIMIT" ]; then
  #  echo "    mem_limit: $DOCKER_MEM_LIMIT"
  #fi
    if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
      echo
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_CPUS" ]; then
        #echo "    cpus: $DOCKER_CPUS"
        echo "          cpus: '$DOCKER_CPUS'"
      fi
      if [ -n "$DOCKER_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_MEM_LIMIT"
        echo "          memory: '$DOCKER_MEM_LIMIT'"
      fi
    fi
  ) > $dwportainer_docker_compose_override_file
}

#-------------------------------------------------------------------------------
# Restart Other Services
#-------------------------------------------------------------------------------
restart_services ()
{
  do_restart ()
  {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
  do_restart apache2
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-portainer.config

if [ -z "$PORTAINER_PORT" ]; then
  PORTAINER_PORT='9000'
fi

create_dwportainer_conf_file
create_dwportainer_docker_compose_override_file
dwportainer compose 1
restart_services

#===============================================================================
# End
#===============================================================================
exit 0
