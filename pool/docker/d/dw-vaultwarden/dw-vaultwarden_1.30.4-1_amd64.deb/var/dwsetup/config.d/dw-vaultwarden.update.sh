#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-vaultwarden.update.sh - Update or Generate Vaultwarden Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-vaultwarden.config'
config_header='/var/dwsetup/header/dw-vaultwarden.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Docker Container Settings"
    dw_conf_line
    echo
    dw_conf_var "DOCKER_CPUS"
    echo
    dw_conf_var "DOCKER_MEM_LIMIT"
    echo
    dw_conf_line
    echo "# Settings for Vaultwarden"
    dw_conf_line
    echo
    dw_conf_var "VW_DOMAIN"
    dw_conf_comment "# The domain must match the address from where you access the server"
    echo
    dw_conf_var "VW_SIGNUPS_ALLOWED"
    dw_conf_comment "# New Users can self register, yes or no"
    echo
    dw_conf_var "VW_INVITATIONS_ALLOWED"
    dw_conf_comment "# Invitations org admins to invite users, even when signups are disabled, yes or no"
    dw_conf_var "VW_INVITATION_ORG_NAME"
    dw_conf_comment "# Name shown in the invitation emails that don't come from a specific organization"
    echo
    dw_conf_var "VW_ADMIN_ENABLED"
    dw_conf_comment "# Admin panel enabled, yes or no"
    dw_conf_var "VW_ADMIN_TOKEN_PASSWORD"
    dw_conf_comment "# Token Password for the admin interface"
    echo
    dw_conf_var "VW_ROCKET_ADDRESS"
    dw_conf_comment "# Rocket Address 0.0.0.0, 127.0.0.1 or localhost"
    dw_conf_var "VW_ROCKET_PORT"
    dw_conf_comment "# Rocket Port, Default 8092"
    echo
    dw_conf_var "VW_WEBSOCKET_ENABLED"
    dw_conf_comment "# Websocket enabeld, yes or no"
    dw_conf_var "VW_WEBSOCKET_ADDRESS"
    dw_conf_comment "# Websocket Address 0.0.0.0, 127.0.0.1 or localhost"
    dw_conf_var "VW_WEBSOCKET_PORT"
    dw_conf_comment "# Websocket Port, Default 3012"
    echo
    dw_conf_var "VW_WEB_VAULT_ENABLED"
    dw_conf_comment "# Web vault enabled, yes or no"
    echo
    dw_conf_var "VW_DATABASE_MAX_CONNS"
    dw_conf_comment "# Database max connections"
    echo
    dw_conf_var "VW_LOG_LEVEL"
    dw_conf_comment "# Log Level: trace, debug, info, warn, error and off"
    echo
    dw_conf_var "VW_REQUIRE_DEVICE_EMAIL"
    dw_conf_comment "# Require new device emails. When a user logs in an email is required to be sent, yes or no"
    dw_conf_comment "# If sending the email fails the login attempt will fail!!"
    echo
    dw_conf_var "VW_SMTP_ENABLED"
    dw_conf_comment "# SMTP enabled, yes or no"
    dw_conf_var "VW_SMTP_HOST"
    dw_conf_comment "# SMTP Host"
    dw_conf_var "VW_SMTP_PORT"
    dw_conf_comment "# SMTP Port"
    dw_conf_var "VW_SMTP_FROM"
    dw_conf_comment "# SMTP From"
    dw_conf_var "VW_SMTP_FROM_NAME"
    dw_conf_comment "# SMTP From Name"
    dw_conf_var "VW_SMTP_SECURITY"
    dw_conf_comment "# SMTP TLS starttls | force_tls | off"
    dw_conf_comment "# Enable a secure connection. Default is starttls (Explicit - ports 587 or 25), force_tls (Implicit - port 465) or off, no encryption (port 25)"
    dw_conf_var "VW_SMTP_USERNAME"
    dw_conf_comment "# SMTP Username"
    dw_conf_var "VW_SMTP_PASSWORD"
    dw_conf_comment "# SMTP Password"
    dw_conf_var "VW_SMTP_TIMEOUT"
    dw_conf_comment "# SMTP Timeout"
    dw_conf_var "VW_SMTP_AUTH_MECHANISM"
    dw_conf_comment "# Defaults for SSL is "Plain" and "Login" and nothing for Non-SSL connections."
    dw_conf_footer e
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
