#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-vaultwarden.sh - Configuration Generator Script for Vaultwarden
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  06.08.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwvaultwarden_conf_dir='/etc/dw-vaultwarden'
dwvaultwarden_conf_file="$dwvaultwarden_conf_dir/vaultwarden.env"
dwvaultwarden_docker_compose_override_file="$dwvaultwarden_conf_dir/docker-dw-vaultwarden/docker-compose.override.yaml"

#----------------------------------------------------------------------------------------
# Create Vaultwarden Docker Compose Override File
#----------------------------------------------------------------------------------------
create_dwvaultwarden_docker_compose_override_file ()
{
  dw_echo_colmsg "==> Create Vaultwarden Docker Compose Override File $dwvaultwarden_docker_compose_override_file ..." 1
  (
  #echo "version: '3.1'"
  #echo
  echo "services:"
  echo
  echo "  vaultwarden:"
  echo "    ports:"
  echo "      - $VW_ROCKET_PORT:80"
  echo "      - $VW_WEBSOCKET_PORT:$VW_WEBSOCKET_PORT"
  #if [ -n "$DOCKER_CPUS" ]; then
  #  echo "    cpus: $DOCKER_CPUS"
  #fi
  #if [ -n "$DOCKER_MEM_LIMIT" ]; then
  #  echo "    mem_limit: $DOCKER_MEM_LIMIT"
  #fi
    if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
      echo
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_CPUS" ]; then
        #echo "    cpus: $DOCKER_CPUS"
        echo "          cpus: $DOCKER_CPUS"
      fi
      if [ -n "$DOCKER_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_MEM_LIMIT"
        echo "          memory: $DOCKER_MEM_LIMIT"
      fi
    fi
  ) > $dwvaultwarden_docker_compose_override_file
}

#----------------------------------------------------------------------------------------
# Create Vaultwarden Configuration File
#----------------------------------------------------------------------------------------
create_dwvaultwarden_conf_file ()
{
  dw_echo_colmsg "==> Create Vaultwarden Config File $dwvaultwarden_conf_file ..." 1
   (
    echo "DOMAIN='$VW_DOMAIN'"
    echo
    if [ "$VW_SIGNUPS_ALLOWED" == 'yes' ]
    then
      echo "SIGNUPS_ALLOWED='true'"
    else
      echo "SIGNUPS_ALLOWED='false'"
    fi
    if [ "$VW_INVITATIONS_ALLOWED" == 'yes' ]
    then
      echo "INVITATIONS_ALLOWED='true'"
    else
      echo "INVITATIONS_ALLOWED='false'"
    fi
    echo "INVITATION_ORG_NAME='$VW_INVITATION_ORG_NAME'"
    echo
    if [ "$VW_ADMIN_ENABLED" == 'yes' ]
    then
      if [ -n "$VW_ADMIN_TOKEN_PASSWORD" ]; then
        echo "ADMIN_TOKEN='$(echo -n "$VW_ADMIN_TOKEN_PASSWORD" | argon2 "$(openssl rand -base64 32)" -e -id -k 65540 -t 3 -p 4)'"
        echo
      fi
    fi
    echo "ROCKET_ADDRESS='$VW_ROCKET_ADDRESS'"
    echo "ROCKET_PORT='$VW_ROCKET_PORT'"
    echo
    if [ "$VW_WEBSOCKET_ENABLED" == 'yes' ]
    then
      echo "WEBSOCKET_ENABLED='true'"
    else
      echo "WEBSOCKET_ENABLED='false'"
    fi
    echo "WEBSOCKET_ADDRESS='$VW_WEBSOCKET_ADDRESS'"
    echo "WEBSOCKET_PORT='$VW_WEBSOCKET_PORT'"
    echo
    if [ "$VW_WEB_VAULT_ENABLED" == 'yes' ]
    then
      echo "WEB_VAULT_ENABLED='true'"
    else
      echo "WEB_VAULT_ENABLED='false'"
    fi
    echo
    echo "LOG_LEVEL='$VW_LOG_LEVEL'"
    echo
    if [ "$VW_SMTP_ENABLED" == 'yes' ]
    then
      echo "SMTP_HOST='$VW_SMTP_HOST'"
      echo "SMTP_PORT='$VW_SMTP_PORT'"
      echo "SMTP_FROM='$VW_SMTP_FROM'"
      echo "SMTP_FROM_NAME='$VW_SMTP_FROM_NAME'"
      echo "SMTP_SECURITY='$VW_SMTP_SECURITY'"
      echo "SMTP_USERNAME='$VW_SMTP_USERNAME'"
      echo "SMTP_PASSWORD='$VW_SMTP_PASSWORD'"
      echo "SMTP_TIMEOUT='$VW_SMTP_TIMEOUT'"
      echo "SMTP_AUTH_MECHANIM='$VW_SMTP_AUTH_MECHANISM'"
      if [ "$VW_REQUIRE_DEVICE_EMAIL" == 'yes' ]
      then
        echo "REQUIRE_DEVICE_EMAIL='true'"
      else
        echo "REQUIRE_DEVICE_EMAIL='false'"
      fi
    fi
  ) > $dwvaultwarden_conf_file
}

#-------------------------------------------------------------------------------
# Restart Other Services
#-------------------------------------------------------------------------------
restart_services ()
{
  do_restart ()
  {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
  do_restart apache2
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-vaultwarden.config

create_dwvaultwarden_docker_compose_override_file
create_dwvaultwarden_conf_file
dwvaultwarden compose 1
restart_services

#===============================================================================
# End
#===============================================================================
exit 0
