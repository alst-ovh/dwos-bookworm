#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-nextcloud.sh - Configuration Generator Script for Nextcloud
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  23.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwnextcloud_conf_dir='/etc/dw-nextcloud'
dwnextcloud_conf_file="$dwnextcloud_conf_dir/docker-dw-nextcloud/.env"
dwnextcloud_docker_compose_override_file="$dwnextcloud_conf_dir/docker-dw-nextcloud/docker-compose.override.yaml"

#----------------------------------------------------------------------------------------
# Create Nextcloud Configuration File
#----------------------------------------------------------------------------------------
create_dwnextcloud_conf_file ()
{
  dw_echo_colmsg "==> Create Nextcloud Config File $dwnextcloud_conf_file ..." 1
  (
    echo "# Data Directory"
    echo
    echo 'DATA_DIR="'$DATA_DIR'"'
  ) > $dwnextcloud_conf_file
}

#----------------------------------------------------------------------------------------
# Create Nextcloud Docker Compose Override File
#----------------------------------------------------------------------------------------
create_dwnextcloud_docker_compose_override_file ()
{
  dw_echo_colmsg "==> Create Nextcloud Docker Compose Override File $dwnextcloud_docker_compose_override_file ..." 1
  (
  #echo "version: '3.1'"
  #echo
  echo "services:"
  echo "  dwnextcloud:"
  echo "    ports:"
  echo "      - $NEXTCLOUD_PORT:80"
  echo "    environment:"
  echo "      NEXTCLOUD_TRUSTED_DOMAINS: $NEXTCLOUD_TRUSTED_DOMAINS"
  echo "      OVERWRITEHOST: $NEXTCLOUD_OVERWRITEHOST"
  echo "      OVERWRITEPROTOCOL: $NEXTCLOUD_OVERWRITEPROTOCOL"
  echo "      APACHE_DISABLE_REWRITE_IP: 1"
  echo "      TRUSTED_PROXIES: $NEXTCLOUD_TRUSTED_PROXIES"

  #if [ -n "$DOCKER_CPUS" ]; then
  #  echo "    cpus: $DOCKER_CPUS"
  #fi
  #if [ -n "$DOCKER_MEM_LIMIT" ]; then
  #  echo "    mem_limit: $DOCKER_MEM_LIMIT"
  #fi
    if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
      echo
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_CPUS" ]; then
        #echo "    cpus: $DOCKER_CPUS"
        echo "          cpus: '$DOCKER_CPUS'"
      fi
      if [ -n "$DOCKER_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_MEM_LIMIT"
        echo "          memory: '$DOCKER_MEM_LIMIT'"
      fi
    fi
  ) > $dwnextcloud_docker_compose_override_file
}

#-------------------------------------------------------------------------------
# Restart Other Services
#-------------------------------------------------------------------------------
restart_services ()
{
  do_restart ()
  {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
  do_restart apache2
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-nextcloud.config

if [ -z "$NEXTCLOUD_PORT" ]; then
  NEXTCLOUD_PORT='8009'
fi
if [ -z "$NEXTCLOUD_TRUSTED_DOMAINS" ]; then
  NEXTCLOUD_TRUSTED_DOMAINS="nextcloud-$(hostname -f)"
fi
if [ -z "$NEXTCLOUD_OVERWRITEHOST" ]; then
  NEXTCLOUD_OVERWRITEHOST="nextcloud-$(hostname -f)"
fi

create_dwnextcloud_conf_file
create_dwnextcloud_docker_compose_override_file
dwnextcloud compose 1
dwnextcloud setphoneregion "$NEXTCLOUD_DEFAULT_PHONE_REGION"
restart_services
dw_echo_colmsg "==> Try http(s)://$NEXTCLOUD_OVERWRITEHOST" 1 a

#===============================================================================
# End
#===============================================================================
exit 0
