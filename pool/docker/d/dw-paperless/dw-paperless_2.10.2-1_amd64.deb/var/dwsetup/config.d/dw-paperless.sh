#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-paperless.sh - Configuration Generator Script for Paperless
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  28.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwpaperless_conf_dir='/etc/dw-paperless'
dwpaperless_docker_compose_env_file="$dwpaperless_conf_dir/docker-dw-paperless/docker-compose.env"
dwpaperless_docker_compose_override_file="$dwpaperless_conf_dir/docker-dw-paperless/docker-compose.override.yaml"
dwpaperless_docker_conf_file="$dwpaperless_conf_dir/docker-dw-paperless/.env"

dwpaperless_secret_key_file=/etc/dwconfig.d/conf/dw-paperless-secret-key.conf

dwpaperless_export_cron_file_weekly='/etc/cron.weekly/paperless-export'

#----------------------------------------------------------------------------------------
# Check Paperless Secret Key File
#----------------------------------------------------------------------------------------
check_dwpaperless_secret_key_file ()
{
  dw_echo_colmsg "==> Check Paperless Secret Key File $dwpaperless_secret_key_file ..." 1
  mkdir -p $(dirname $dwpaperless_secret_key_file)
  if [ ! -f $dwpaperless_secret_key_file ]; then
    cat /proc/sys/kernel/random/uuid > $dwpaperless_secret_key_file
  fi
}

#----------------------------------------------------------------------------------------
# Create Paperless Docker Configuration File
#----------------------------------------------------------------------------------------
create_dwpaperless_docker_conf_file ()
{
  dw_echo_colmsg "==> Create Paperless Docker Config File $dwpaperless_docker_conf_file ..." 1
  (
  echo "# Data Directory"
  echo
  echo 'DATA_DIR="'$DATA_DIR'"'
  ) > $dwpaperless_docker_conf_file
}

#----------------------------------------------------------------------------------------
# Create Paperless Docker Compose Env File
#----------------------------------------------------------------------------------------
create_dwpaperless_docker_compose_env_file ()
{
  dw_echo_colmsg "==> Create Paperless Docker Compose Env File $dwpaperless_docker_compose_env_file ..." 1
  (
  echo 'USERMAP_UID="'$(docker_get_uid)'"'
  echo 'USERMAP_GID="'$(docker_get_gid)'"'
  echo 'PAPERLESS_SECRET_KEY="'$(cat $dwpaperless_secret_key_file)'"'
  echo 'PAPERLESS_URL="'$PAPERLESS_URL'"'
  echo 'PAPERLESS_TIME_ZONE="'$PAPERLESS_TIME_ZONE'"'
  echo 'PAPERLESS_OCR_LANGUAGE="'$PAPERLESS_OCR_LANGUAGE'"'
  echo 'PAPERLESS_OCR_LANGUAGES="'$PAPERLESS_OCR_LANGUAGES'"'
  echo 'PAPERLESS_CONSUMER_SUBDIRS_AS_TAGS="'$(dw_conf_yesno_to_bool "$PAPERLESS_CONSUMER_SUBDIRS_AS_TAGS")'"'
  echo 'PAPERLESS_EMAIL_HOST="'$PAPERLESS_EMAIL_HOST'"'
  echo 'PAPERLESS_EMAIL_PORT="'$PAPERLESS_EMAIL_PORT'"'
  echo 'PAPERLESS_EMAIL_HOST_USER="'$PAPERLESS_EMAIL_HOST_USER'"'
  echo 'PAPERLESS_EMAIL_FROM="'$PAPERLESS_EMAIL_FROM'"'
  echo 'PAPERLESS_EMAIL_HOST_PASSWORD="'$PAPERLESS_EMAIL_HOST_PASSWORD'"'
  echo 'PAPERLESS_EMAIL_USE_TLS="'$(dw_conf_yesno_to_bool "$PAPERLESS_EMAIL_USE_TLS")'"'
  echo 'PAPERLESS_EMAIL_USE_SSL="'$(dw_conf_yesno_to_bool "$PAPERLESS_EMAIL_USE_SSL")'"'
  ) > $dwpaperless_docker_compose_env_file
}

#----------------------------------------------------------------------------------------
# Create Paperless Docker Compose Override File
#----------------------------------------------------------------------------------------
create_dwpaperless_docker_compose_override_file ()
{
  dw_echo_colmsg "==> Create Paperless Docker Compose Override File $dwpaperless_docker_compose_override_file ..." 1
  (
  #echo "version: '3.1'"
  #echo
  echo "services:"
  echo "  webserver:"
  echo "    ports:"
  echo "      - $PAPERLESS_PORT:8000"
  if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
    echo "    deploy:"
    echo "      resources:"
    echo "        limits:"
    if [ -n "$DOCKER_CPUS" ]; then
      echo "          cpus: $DOCKER_CPUS"
    fi
    if [ -n "$DOCKER_MEM_LIMIT" ]; then
      #echo "    mem_limit: $DOCKER_MEM_LIMIT"
      echo "          memory: $DOCKER_MEM_LIMIT"
    fi
  fi
  if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT_BROKER" ]; then
    echo "  broker:"
    echo "    deploy:"
    echo "      resources:"
    echo "        limits:"
    if [ -n "$DOCKER_CPUS" ]; then
      echo "          cpus: $DOCKER_CPUS"
    fi
    if [ -n "$DOCKER_MEM_LIMIT_BROKER" ]; then
      #echo "    mem_limit: $DOCKER_MEM_LIMIT_BROKER"
      echo "          memory: $DOCKER_MEM_LIMIT_BROKER"
    fi
  fi
  if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT_GOTENBERG" ]; then
    echo "  gotenberg:"
    echo "    deploy:"
    echo "      resources:"
    echo "        limits:"
    if [ -n "$DOCKER_CPUS" ]; then
      echo "          cpus: $DOCKER_CPUS"
    fi
    if [ -n "$DOCKER_MEM_LIMIT_GOTENBERG" ]; then
      #echo "    mem_limit: $DOCKER_MEM_LIMIT_GOTENBERG"
      echo "          memory: $DOCKER_MEM_LIMIT_GOTENBERG"
    fi
  fi
  if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT_TIKA" ]; then
    echo "  tika:"
    echo "    deploy:"
    echo "      resources:"
    echo "        limits:"
    if [ -n "$DOCKER_CPUS" ]; then
      echo "          cpus: $DOCKER_CPUS"
    fi
    if [ -n "$DOCKER_MEM_LIMIT_TIKA" ]; then
      #echo "    mem_limit: $DOCKER_MEM_LIMIT_TIKA"
      echo "          memory: $DOCKER_MEM_LIMIT_TIKA"
    fi
  fi
  ) > $dwpaperless_docker_compose_override_file
}

#----------------------------------------------------------------------------------------
# Check Paperless Export Cron File
#----------------------------------------------------------------------------------------
check_dwpaperless_export_cron_file() {
  dw_echo_colmsg "==> Check Paperless Export Cron File ..." 1
  local remove_cron_file='no'

  if dw_conf_var_is_yes "$PAPERLESS_EXPORT_WEEKLY"; then
    dw_echo_colmsg "==> Export Cron Weekly Enabled, create Paperless Export Cron File $dwpaperless_export_cron_file_weekly ..." 2
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      echo "/sbin/dwpaperless export &>/dev/null"
    ) >$dwpaperless_export_cron_file_weekly
    chmod 0744 $dwpaperless_export_cron_file_weekly
    remove_cron_file='no'
  else
    remove_cron_file='yes'
  fi

  if dw_conf_var_is_yes "$remove_cron_file"; then
    dw_echo_colmsg "==> Export Cron Weekly Disabled, remove Paperless Export Cron File $dwpaperless_export_cron_file_weekly ..." 2
    rm -f $dwpaperless_export_cron_file_weekly
  fi

  systemctl restart cron
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-paperless.config

if [ -z "$PAPERLESS_PORT" ]; then
  PAPERLESS_PORT='8092'
fi

check_dwpaperless_secret_key_file
create_dwpaperless_docker_conf_file
create_dwpaperless_docker_compose_env_file
create_dwpaperless_docker_compose_override_file
check_dwpaperless_export_cron_file
dwpaperless compose 1
#if dw_conf_var_is_yes "$PAPERLESS_2_NEXTCLOUD_ENABLED"; then
#  dw_echo_colmsg "==> PAPERLESS_2_NEXTCLOUD_ENABLED is enabled ..." 1
#  dw_sctl_activate dwpaperless-watch
#else
#  dw_echo_colmsg "==> PAPERLESS_2_NEXTCLOUD_ENABLED is disabled ..." 1 n
#  dw_sctl_deactivate dwpaperless-watch
#fi

#===============================================================================
# End
#===============================================================================
exit 0
