#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-gitea.sh - Configuration Generator Script for Gitea
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  26.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwgitea_conf_dir='/etc/dw-gitea'
dwgitea_docker_compose_file="$dwgitea_conf_dir/docker-dw-gitea/docker-compose.yaml"

#----------------------------------------------------------------------------------------
# Create Gitea Docker Compose File
#----------------------------------------------------------------------------------------
create_dwgitea_docker_compose_file() {
  dw_echo_colmsg "==> Create Gitea Docker Compose File $dwgitea_docker_compose_file ..." 1
  (
    #echo "version: '3.1'"
    #echo
    echo "services:"
    echo "  dwgitea:"
    echo "    environment:"
    echo "      - USER_UID=$(docker_get_uid)"
    echo "      - USER_GID=$(docker_get_gid)"
    echo "      - GITEA__server__DISABLE_SSH=true"
    echo "      - GITEA__server__SSH_SERVER=false"
    echo "      - GITEA__server__SSH_PORT="
    echo "      - GITEA__server__SSH_LISTEN_PORT="
    echo "      - GITEA__database__DB_TYPE=sqlite3"
    echo
    echo "      - GITEA__attachment__ENABLE=true"
    echo "      - GITEA__attachment__MAX_SIZE=100"
    echo "      - GITEA__attachment__MAX_FILES=1000"
    echo
    echo "      - GITEA__security__MIN_PASSWORD_LENGTH=$GITEA_MIN_PASSWORD_LENGTH"
    echo
    echo "      - GITEA__openid__ENABLE_OPENID_SIGNIN=$(dw_conf_yesno_to_bool "$GITEA_ENABLE_OPENID_SIGNIN")"
    echo "      - GITEA__openid__ENABLE_OPENID_SIGNUP=$(dw_conf_yesno_to_bool "$GITEA_ENABLE_OPENID_SIGNUP")"
    echo
    echo "      - GITEA__mailer__ENABLED=$(dw_conf_yesno_to_bool "$GITEA_MAIL_ENABLED")"
    echo
    echo "      - GITEA__service__DISABLE_REGISTRATION=$(dw_conf_yesno_to_bool_invert "$GITEA_ENABLE_REGISTRATION")"
    echo "      - GITEA__service__REQUIRE_SIGNIN_VIEW=$(dw_conf_yesno_to_bool_invert "$GITEA_ENABLE_NOSIGNIN_VIEW")"
    #if [ -n "$DOCKER_CPUS" ]; then
    #  echo "    cpus: $DOCKER_CPUS"
    #fi
    #if [ -n "$DOCKER_MEM_LIMIT" ]; then
    #  echo "    mem_limit: $DOCKER_MEM_LIMIT"
    #fi
    if [ -n "$DOCKER_CPUS" -o -n "$DOCKER_MEM_LIMIT" ]; then
      echo
      echo "    deploy:"
      echo "      resources:"
      echo "        limits:"
      if [ -n "$DOCKER_CPUS" ]; then
        #echo "    cpus: $DOCKER_CPUS"
        echo "          cpus: $DOCKER_CPUS"
      fi
      if [ -n "$DOCKER_MEM_LIMIT" ]; then
        #echo "    mem_limit: $DOCKER_MEM_LIMIT"
        echo "          memory: $DOCKER_MEM_LIMIT"
      fi
    fi
  ) >$dwgitea_docker_compose_file
}

#-------------------------------------------------------------------------------
# Restart Other Services
#-------------------------------------------------------------------------------
restart_services() {
  do_restart() {
    if [ -f /etc/init.d/$1 ]; then
      service $1 restart
    fi
  }
  do_restart apache2
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-gitea.config

create_dwgitea_docker_compose_file
dwgitea compose 1
restart_services

#===============================================================================
# End
#===============================================================================
exit 0
