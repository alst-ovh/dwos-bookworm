#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-clone.sh - Configuration Generator Script for Clone
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  04.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-clone'
dwclone_conf_dir='/etc/dw-clone'
dwclone_conf_file="$dwclone_conf_dir/dw-clone.conf"
dwclone_exclude_file="$dwclone_conf_dir/dw-clone-exclude"
dwclone_auto_uuid_file="$dwclone_conf_dir/dw-clone-auto-uuid"

#----------------------------------------------------------------------------------------
# Create Clone Configuration File
#----------------------------------------------------------------------------------------
create_dwclone_conf_file ()
{
  dw_echo_colmsg "==> Create Clone Config File $dwclone_conf_file" 1
  (
    dw_conf_var "NOTIFY_MAIL"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    dw_conf_var "NOTIFY_TELEGRAM"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    dw_conf_var "CLONE_BEEP"
    echo
    dw_conf_var "CLONE_DELETE_BEFORE"
    echo
    dw_conf_var "CLONE_AUTO"
  ) > $dwclone_conf_file
  dw_add_pkg_files "$pkg_name" "$dwclone_conf_file"
}

#----------------------------------------------------------------------------------------
# Create Clone Exclude File
#----------------------------------------------------------------------------------------
create_dwclone_exclude_file ()
{
  dw_echo_colmsg "==> Create Exclude File $dwclone_exclude_file" 1
  :> $dwclone_exclude_file
  chmod 0644 $dwclone_exclude_file
  dw_add_pkg_files "$pkg_name" "$dwclone_exclude_file"
  idx='1'
  eval pi_excludes_n='$CLONE_EXCLUDES_N'
  while [ "$idx" -le "$pi_excludes_n" ]
  do
    eval pi_excludes='$CLONE_EXCLUDES_'$idx
    if dw_conf_var_is_enabled "$pi_excludes"; then
      echo "$pi_excludes" >> $dwclone_exclude_file
    else
      pi_excludes_disabled='CLONE_EXCLUDES_'$idx
      dw_echo_colmsg "==> INFO: Exclude $pi_excludes_disabled is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#----------------------------------------------------------------------------------------
# Check Clone Auto Clone enabled
#----------------------------------------------------------------------------------------
check_dwclone_auto_enabled ()
{
  if dw_conf_var_is_yes "$CLONE_AUTO"; then
    dw_echo_colmsg "==> INFO: Clone Auto Clone is enabled !" 1 a
  else
    dw_echo_colmsg "==> INFO: Clone Auto Clone is disabled !" 1 n
  fi
}

#----------------------------------------------------------------------------------------
# Create Clone Auto UUID File
#----------------------------------------------------------------------------------------
create_dwclone_auto_uuid_file ()
{
  dw_echo_colmsg "==> Create Auto UUID File ${dwclone_auto_uuid_file}" 1
  :> ${dwclone_auto_uuid_file}
  chmod 0644 ${dwclone_auto_uuid_file}
  idx='1'
  eval auto_uuid_n='$CLONE_AUTO_UUID_N'
  while [ "$idx" -le "$auto_uuid_n" ]
  do
    eval auto_uuid='$CLONE_AUTO_UUID_'$idx
    if dw_conf_var_is_enabled "$auto_uuid"; then
      echo "$auto_uuid" >> ${dwclone_auto_uuid_file}
    else
      auto_uuid_disabled='CLONE_AUTO_UUID_'$idx
      dw_echo_colmsg "==> INFO: Auto UUID $auto_uuid_disabled is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-base.config
. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-clone.config

create_dwclone_conf_file
create_dwclone_auto_uuid_file
create_dwclone_exclude_file
check_dwclone_auto_enabled

#===============================================================================
# End
#===============================================================================
exit 0
