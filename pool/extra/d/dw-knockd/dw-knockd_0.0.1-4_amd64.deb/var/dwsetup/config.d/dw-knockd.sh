#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-knockd.sh - Configuration Generator Script for KnockD
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-knockd'
knockd_script_dir="/etc/dw-knockd"
knockd_conf_file="/etc/knockd.conf"

#----------------------------------------------------------------------------------------
# Create KnockD Configuration File
#----------------------------------------------------------------------------------------
create_knockd_conf_file ()
{
  write_script ()
  {
    # $1 = Name
    s_name="$1"
    # $2 = Filename
    s_file_name="$2"
    # $3 = Start or Stop
    s_start_stop="$3"
    # $4 = Command
    s_cmd="$4"
    (
      echo "#!/bin/bash"
      echo
      echo ". /var/dwsetup/lib/dw-all.libs"
      echo
      echo 'subject="KnockD INFO: on $(hostname --fqdn) at $(dw_date)"'
      echo 'msg="'$s_start_stop' Sequence '$s_name'"'

      if [ "$KNOCKD_TG" = 'yes' ]; then
        echo
        echo 'dwtg -quiet --quiet --info --title "$subject" --text "$msg"'
      fi

      if [ "$KNOCKD_MAIL" = 'yes' ]; then
        echo
        echo 'dwmail "-quiet" "$subject" "$msg"'
      fi

      echo
      echo "$s_cmd"
      echo
      echo "exit 0"
    ) > $s_file_name
    chmod +x $s_file_name
    dw_add_pkg_files "$pkg_name" "$s_file_name"
  }

  if [ ! -d $knockd_script_dir ]; then
    mkdir -p $knockd_script_dir
  else
    rm -rf $knockd_script_dir/*.script
  fi
  dw_echo_colmsg "==> Create KnockD Config File $knockd_conf_file ..." 2
  (
    echo "[options]"
    echo "    UseSyslog"
    if [ -n "$KNOCKD_OPTIONS_INTERFACE" ]; then
      echo "    Interface = $KNOCKD_OPTIONS_INTERFACE"
    fi
    echo
  ) > $knockd_conf_file
  idx=1
  while [ "$idx" -le "$KNOCKD_N" ]
  do
    eval name='$KNOCKD_'$idx'_NAME'
    eval sequence='$KNOCKD_'$idx'_SEQUENCE'
    eval seq_timeout='$KNOCKD_'$idx'_SEQ_TIMEOUT'
    eval tcp_flags='$KNOCKD_'$idx'_TCP_FLAGS'
    eval start_cmd='$KNOCKD_'$idx'_START_CMD'
    eval cmd_timeout='$KNOCKD_'$idx'_CMD_TIMEOUT'
    eval stop_cmd='$KNOCKD_'$idx'_STOP_CMD'
    eval start_cmd_script="$knockd_script_dir/${name}_start.script"
    eval stop_cmd_script="$knockd_script_dir/${name}_stop.script"
    if dw_conf_var_is_enabled "$name";then
      (
        echo "[$name]"
        echo "    sequence    = $sequence"
        echo "    seq_timeout = $seq_timeout"
        echo "    tcpflags    = $tcp_flags"
        if [ -n "$start_cmd" ]; then
          echo "    start_command = $start_cmd_script"
          write_script "$name" "$start_cmd_script" "Start" "$start_cmd"
        else
          echo "    start_command ="
        fi
        echo "    cmd_timeout = $cmd_timeout"
        if [ -n "$stop_cmd" ]; then
          echo "    stop_command = $stop_cmd_script"
          write_script "$name" "$stop_cmd_script" "Stop" "$stop_cmd"
        else
          echo "    stop_command ="
        fi
        echo
      ) >> $knockd_conf_file
      dw_add_pkg_files "$pkg_name" "$knockd_conf_file"
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: KnockD KNOCKD_NAME_$idx is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-knockd.config
. /var/dwsetup/bin/setup-functions

sed -i -e "s/.*START_KNOCKD=.*$/START_KNOCKD=1/" /etc/default/knockd
create_knockd_conf_file

#===============================================================================
# End
#===============================================================================
exit 0
