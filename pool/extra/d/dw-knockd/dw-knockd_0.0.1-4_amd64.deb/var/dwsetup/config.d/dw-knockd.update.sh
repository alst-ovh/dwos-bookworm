#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-knockd.update.sh - Update or Generate KnockD Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-knockd.config'
config_header='/var/dwsetup/header/dw-knockd.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Settings for KnockD"
    dw_conf_line
    echo
    dw_conf_var "KNOCKD_OPTIONS_INTERFACE"
    dw_conf_comment "# Network interface to listen on, if not eth0 you must define it!"
    echo
    dw_conf_var "KNOCKD_GEN_SEQUENCE_FROM_TO"
    dw_conf_comment "# dwknockd gen from to Portnumber for eaxmple 65000-65100!"
    echo
    dw_conf_var "KNOCKD_GEN_SEQUENCE_COUNT"
    dw_conf_comment "# dwknockd gen default count!"
    echo
    dw_conf_line
    echo "# Sequence Settings for KnockD"
    echo "# (Prefix a KNOCKD_x_NAME with a ! to Disable it)"
    echo "# KNOCKD_x_NAME Specify the sequence unique Name"
    echo "# KNOCKD_x_SEQUENCE Specify the sequence of ports in the special knock. port1:<tcp|udp>,port2:tcp|udp..."
    echo "# KNOCKD_x_SEQ_TIMEOUT ime to wait for a sequence to complete in seconds."
    echo "# KNOCKD_x_TCP_FLAGS Only pay attention to packets that have this flag set. fin|syn|rst|psh|ack|urg"
    echo "# KNOCKD_x_START_CMD Specify the command to be executed when a client makes the correct port-knock."
    echo "#                    %IP% will be replaced with the knocker's IP address"
    echo "# KNOCKD_x_CMD_TIMEOUT Time to wait between Start_Command and Stop_Command in seconds."
    echo "# KNOCKD_x_STOP_CMD Specify the command to be executed when Cmd_Timeout seconds have passed since Start_Command has been executed."
    echo "#                   %IP% will be replaced with the knocker's IP address"
    echo "#"
    echo "# You can generate a random sequence with /sbin/dwknockd"
    dw_conf_line
    echo
    dw_conf_var "KNOCKD_MAIL"
    dw_conf_comment "# Send Mail yes or no"
    echo
    dw_conf_var "KNOCKD_TG"
    dw_conf_comment "# Send Telegram Message yes or no"
    echo
    dw_conf_var "KNOCKD_N"
    dw_conf_comment "# Number of sequences"
    if [ $KNOCKD_N -eq 0 ]
    then
      imax=1
    else
      imax=$KNOCKD_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval name='$KNOCKD_'$idx'_NAME'
      eval sequence='$KNOCKD_'$idx'_SEQUENCE'
      eval seq_timeout='$KNOCKD_'$idx'_SEQ_TIMEOUT'
      eval tcp_flags='$KNOCKD_'$idx'_TCP_FLAGS'
      eval start_cmd='$KNOCKD_'$idx'_START_CMD'
      eval cmd_timeout='$KNOCKD_'$idx'_CMD_TIMEOUT'
      eval stop_cmd='$KNOCKD_'$idx'_STOP_CMD'
      echo "KNOCKD_"$idx"_NAME=""'$name'"
      echo "KNOCKD_"$idx"_SEQUENCE=""'$sequence'"
      echo "KNOCKD_"$idx"_SEQ_TIMEOUT=""'$seq_timeout'"
      echo "KNOCKD_"$idx"_TCP_FLAGS=""'$tcp_flags'"
      echo "KNOCKD_"$idx"_START_CMD=""'$start_cmd'"
      echo "KNOCKD_"$idx"_CMD_TIMEOUT=""'$cmd_timeout'"
      echo "KNOCKD_"$idx"_STOP_CMD=""'$stop_cmd'"
      idx=$(expr $idx + 1)
      echo
    done
    dw_conf_footer
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
