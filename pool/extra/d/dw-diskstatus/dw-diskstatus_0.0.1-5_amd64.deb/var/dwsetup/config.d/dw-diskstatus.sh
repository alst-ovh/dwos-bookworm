#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-diskstatus.sh - Configuration Generator Script for DiskStatus
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-diskstatus'
dwdiskstatus_conf_dir='/etc/dw-diskstatus'
dwdiskstatus_conf_file="$dwdiskstatus_conf_dir/dw-diskstatus.conf"

dwdiskstatus_cron_file_daily='/etc/cron.daily/diskstatus'

#----------------------------------------------------------------------------------------
# Create DiskStatus Configuration File
#----------------------------------------------------------------------------------------
create_dwdiskstatus_conf_file ()
{
  if [ ! -d $dwdiskstatus_conf_dir ]; then
    mkdir -p $dwdiskstatus_conf_dir
  fi
  dw_echo_colmsg "==> Create DiskStatus Config File $dwdiskstatus_conf_file ..." 2
  (
    echo "DS_WARN_PERCENT='$DS_WARN_PERCENT'"
    echo
    echo "NOTIFY_MAIL='$NOTIFY_MAIL'"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    echo "NOTIFY_TELEGRAM='$NOTIFY_TELEGRAM'"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
  ) > $dwdiskstatus_conf_file
  dw_add_pkg_files "$pkg_name" "$dwdiskstatus_conf_file"
}

#----------------------------------------------------------------------------------------
# Create DiskStatus Cron Files
#----------------------------------------------------------------------------------------
check_dwdiskstatus_cron_files ()
{
  dw_echo_colmsg "==> Check DiskStatus Cron Files ..." 2
  remove_cron_file='no'

  if [ "$DS_CRON_DAILY" = "yes" ]; then
    dw_echo_colmsg "==> Cron Daily Enabled, create DiskStatus Cron File $dwdiskstatus_cron_file_daily ..." 3
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      echo "/sbin/dwdiskstatus notify >/dev/null"
    ) >$dwdiskstatus_cron_file_daily
    chmod 0744 $dwdiskstatus_cron_file_daily
    dw_add_pkg_files "$pkg_name" "$dwdiskstatus_cron_file_daily"
    remove_cron_file='no'
  else
    remove_cron_file='yes'
  fi

  if [ "$remove_cron_file" = 'yes' ]; then
    dw_echo_colmsg "==> Cron Daily Disabled, remove DiskStatus Cron File $dwdiskstatus_cron_file_daily ..." 3
    rm -f $dwdiskstatus_cron_file_daily
  fi
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-diskstatus.config
. /var/dwsetup/bin/setup-functions

create_dwdiskstatus_conf_file
check_dwdiskstatus_cron_files
dw_sctl_restart cron

#===============================================================================
# End
#===============================================================================
exit 0
