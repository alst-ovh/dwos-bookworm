#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-wg.sh - Configuration Generator Script for Wireguard
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-wg'

wg_conf_dir='/etc/dw-wg'
wg_conf_file="$wg_conf_dir/dw-wg.conf"

wg_dir='/etc/wireguard'
wg_config="$wg_dir/wg0.conf"
wg_clients_conf_dir="$wg_dir/clients"
wg_key_dir='/etc/dwconfig.d/share/wireguard-keys'

wg_server_key_private="$wg_key_dir/server_private.key"
wg_server_key_public="$wg_key_dir/server_public.key"

sysctl_conf='/etc/sysctl.conf'

#----------------------------------------------------------------------------------------
# Check IP Forward /etc/sysctl.conf
#----------------------------------------------------------------------------------------
check_ip_forward() {
  dw_echo_colmsg "==> Check IP Forward Enabled in $sysctl_conf ..." 1
  if  [ -n "$(cat $sysctl_conf | grep "^net.ipv4.ip_forward=1")" ]; then
    dw_echo_colmsg "==> OK IP Forward is Enabled" 2 o
  else
    dw_echo_colmsg "==> Enable IP Forward ..." 2
    echo "net.ipv4.ip_forward=1" >> "$sysctl_conf"
    sysctl -p >/dev/null
  fi
}

#----------------------------------------------------------------------------------------
# Create Wireguard Configuration File
#----------------------------------------------------------------------------------------
create_dwwg_config_file ()
{
  dw_echo_colmsg "==> Create Wireguard Config File $wg_conf_file ..." 1
  if [ ! -d "$wg_conf_dir" ]; then
    mkdir -p "$wg_conf_dir"
  fi
  (
    dw_conf_var "NOTIFY_MAIL"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    dw_conf_var "NOTIFY_TELEGRAM"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    dw_conf_var "WG_NOTIFY_TIMEOUT"
  ) > "$wg_conf_file"
  chmod 0644 "$wg_conf_file"
  dw_add_pkg_files "$pkg_name" "$wg_conf_file"
}

#----------------------------------------------------------------------------------------
# Create Wireguard Config Server Entry
#----------------------------------------------------------------------------------------
create_server_entry() {
  dw_echo_colmsg "==> Create Wireguard Config $wg_config ..." 1
  dw_echo_colmsg "==> Add Wireguard Server Entry ..." 2
  if [ ! -d "$wg_dir" ]; then
    mkdir -p "$wg_dir"
  fi
  local WG_PREUP=''
  local WG_POSTUP=''
  #"iptables -t nat -A POSTROUTING -s $(echo $WG_DEFAULT_ADDRESS | sed s/x/0/)/24 -o eth0 -j MASQUERADE; iptables -A INPUT -p udp -m udp --dport $WG_PORT -j ACCEPT; iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT;"
  local WG_PREDOWN=''
  local WG_POSTDOWN=''
  #"iptables -t nat -D POSTROUTING -s $(echo $WG_DEFAULT_ADDRESS | sed s/x/0/)/24 -o eth0 -j MASQUERADE; iptables -D INPUT -p udp -m udp --dport $WG_PORT -j ACCEPT; iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT;"
  (
  dw_conf_trim "[Interface] # Server"
  dw_conf_trim "PrivateKey = $(cat $wg_server_key_private)"
  dw_conf_trim "Address = $(echo $WG_DEFAULT_ADDRESS | sed s/x/254/)/24"
  dw_conf_trim "ListenPort = $WG_PORT"
  dw_conf_trim "PreUp = $WG_PREUP"
  dw_conf_trim "PostUp = $WG_POSTUP"
  dw_conf_trim "PreDown = $WG_PREDOWN"
  dw_conf_trim "PostDown = $WG_POSTDOWN"
  echo
  ) >"$wg_config"
}

#----------------------------------------------------------------------------------------
# Create Wireguard Config Client Entry
#----------------------------------------------------------------------------------------
create_client_entry() {
  local client="$1"
  wg_client_conf_dir="$wg_clients_conf_dir"
  wg_client_key_dir="$wg_key_dir/$client"
  wg_client_key_private="$wg_client_key_dir/${client}_private.key"
  wg_client_key_public="$wg_client_key_dir/${client}_public.key"
  wg_client_key_preshared="$wg_client_key_dir/${client}_preshared.key"
  mkdir -p "$wg_client_conf_dir"
  wg_client_key_puplic_key="$(cat $wg_client_key_public)"
  wg_client_key_preshared_key="$(cat $wg_client_key_preshared)"
  #local client_number=$(expr "$client" + 1)
  local client_number="$client"
  wg_client_address="$(echo $WG_DEFAULT_ADDRESS | sed s/x/$client_number/)/32"
  eval client_name='$WG_CLIENT_'$client'_NAME'
  eval client_mail='$WG_CLIENT_'$client'_MAIL'
  (
  dw_conf_trim "[Peer] #Client $client $client_name $(dw_conf_remove_disabled $client_mail)"
  dw_conf_trim "PublicKey = $wg_client_key_puplic_key # $client $client_name"
  dw_conf_trim "PresharedKey = $wg_client_key_preshared_key"
  dw_conf_trim "AllowedIPs = $wg_client_address"
  #, $WG_ALLOWED_IPS"
  echo
  ) >>"$wg_config"
}

create_client_entrys() {
  dw_echo_colmsg "==> Add Wireguard Client Entrys ..." 2
  local idx='1'
  eval client_n='$WG_CLIENT_N'
  while [ "$idx" -le "$client_n" ]; do
    eval client_name='$WG_CLIENT_'$idx'_NAME'
    eval client_mail='$WG_CLIENT_'$idx'_MAIL'
    if dw_conf_var_is_enabled "$client_name"; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Add Wireguard Client Entry $idx $client_name ..." 2
      create_client_entry "$idx"
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Wireguard Client Entry $idx $(dw_conf_remove_disabled $client_name) is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#----------------------------------------------------------------------------------------
# Create Wireguard Client Config
#----------------------------------------------------------------------------------------
create_client_config() {
  if [ ! -d "$wg_client_conf_dir" ]; then
    mkdir -p "$wg_client_conf_dir"
  fi
  local client="$1"
  wg_client_conf_dir="$wg_clients_conf_dir"
  wg_client_key_dir="$wg_key_dir/$client"
  wg_client_key_private="$wg_client_key_dir/${client}_private.key"
  wg_client_key_public="$wg_client_key_dir/${client}_public.key"
  wg_client_key_preshared="$wg_client_key_dir/${client}_preshared.key"
  mkdir -p "$wg_client_conf_dir"
  wg_client_key_private_key="$(cat $wg_client_key_private)"
  wg_client_key_puplic_key="$(cat $wg_client_key_public)"
  wg_client_key_preshared_key="$(cat $wg_client_key_preshared)"
  #local client_number=$(expr "$1" + 1)
  local client_number="$client"
  #wg_client_address="$(echo $WG_DEFAULT_ADDRESS | sed s/x/$client_number/)/24"
  #wg_client_address_alowed="$(echo $WG_DEFAULT_ADDRESS | sed s/x/$client_number/)/32"
  #### Test
  wg_client_address="$(echo $WG_DEFAULT_ADDRESS | sed s/x/$client_number/)/32"
  wg_client_address_alowed="$(echo $WG_DEFAULT_ADDRESS | sed s/x/0/)/24"
  eval client_name='$WG_CLIENT_'$client'_NAME'
  eval client_mail='$WG_CLIENT_'$client'_MAIL'
  (
    dw_conf_trim "[Interface]"
    dw_conf_trim "PrivateKey = $wg_client_key_private_key"
    dw_conf_trim "Address = $wg_client_address"
    dw_conf_trim "DNS = $WG_DEFAULT_DNS"
    dw_conf_trim "MTU = $WG_MTU"
    echo
    dw_conf_trim "[Peer]"
    dw_conf_trim "PublicKey = $(cat $wg_server_key_public)"
    dw_conf_trim "PresharedKey = $wg_client_key_preshared_key"
    if [ "$WG_ALLOWED_IPS" != '0.0.0.0/0' ]; then
      dw_conf_trim "AllowedIPs = $wg_client_address_alowed, $WG_ALLOWED_IPS"
    else
      dw_conf_trim "AllowedIPs = $WG_ALLOWED_IPS"
    fi
    dw_conf_trim "PersistentKeepalive = $WG_PERSISTENT_KEEPALIVE"
    dw_conf_trim "Endpoint = $WG_HOST:$WG_PORT"
  ) >"$wg_client_conf_dir/$client.conf"
  #if dw_conf_var_is_enabled "$client_name" && dw_conf_var_is_enabled "$client_mail"; then
  #  send_client_config "$client"
  #fi
}

create_client_configs() {
  dw_echo_colmsg "==> Create Wireguard Client Configs ..." 1
  local idx='1'
  eval client_n='$WG_CLIENT_N'
  while [ "$idx" -le "$client_n" ]; do
    eval client_name='$WG_CLIENT_'$idx'_NAME'
    eval client_mail='$WG_CLIENT_'$idx'_MAIL'
    #if dw_conf_var_is_enabled "$client_name"; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Wireguard Client Config $(dw_conf_remove_disabled $client_name) ..." 2
      create_client_config "$idx"
    #else
    #  dw_echo_colmsg "==> Wireguard Client Entry $idx $(dw_conf_remove_disabled $client_name) is disabled !" 2 n
    #fi
    idx=$(expr $idx + 1)
  done
}

send_client_config() {
  local client="$1"
  wg_client_conf_dir="$wg_clients_conf_dir"
  mkdir -p "$wg_client_conf_dir"
  eval client_name='$WG_CLIENT_'$client'_NAME'
  eval client_mail='$WG_CLIENT_'$client'_MAIL'
  local tmp_dir="/tmp/$$wg"
  local wg_conf="$tmp_dir/$WG_HOST-$client_name.conf"
  local wg_png="$tmp_dir/$WG_HOST-$client_name.png"
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Wireguard Client $client < $(dw_conf_remove_disabled $client_name) > Send Config via E-Mail ..." 0
  if [ -f "$wg_client_conf_dir/$client.conf" ] && dw_conf_var_is_enabled "$client_name" && dw_conf_var_is_enabled "$client_mail"; then
    mkdir -p "$tmp_dir"
    cat "$wg_client_conf_dir/$client.conf" >"$wg_conf"
    #cat "$wg_client_conf_dir/$client.conf" | qrencode -t ansiutf8 >"$wg_client_conf_dir/$client.ascii"
    cat "$wg_client_conf_dir/$client.conf" | qrencode -t png -o "$wg_png"
    dwmail "-quiet" "Wireguard Config < $WG_HOST-$client_name >" "$(cat $wg_client_conf_dir/$client.conf)" "$wg_conf" "$wg_png" "$client_mail"
    rm "$wg_conf"
    rm "$wg_png"
    rmdir "$tmp_dir"
  else
    if [ -f "$wg_client_conf_dir/$client.conf" ] && ! dw_conf_var_is_enabled "$client_name"; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "Wireguard Client $client < $(dw_conf_remove_disabled $client_name) > is Disabled !" 1 a
    elif [ -f "$wg_client_conf_dir/$client.conf" ] && ! dw_conf_var_is_enabled "$client_mail"; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "Wireguard Client $client < $(dw_conf_remove_disabled $client_name) > E-Mail is Disabled !" 1 a
    fi
  fi
}

send_client_config_all() {
  local idx='1'
  eval client_n='$WG_CLIENT_N'
  while [ "$idx" -le "$client_n" ]; do
    send_client_config "$idx"
    idx=$(expr $idx + 1)
  done
}

show_client_qr() {
  local client="$1"
  wg_client_conf_dir="$wg_clients_conf_dir"
  mkdir -p "$wg_client_conf_dir"
  eval client_name='$WG_CLIENT_'$client'_NAME'
  eval client_mail='$WG_CLIENT_'$client'_MAIL'
  local tmp_dir="/tmp/$$wg"
  mkdir -p "$tmp_dir"
  local wg_conf="$tmp_dir/$client.conf"
  local wg_png="$tmp_dir/$client.png"
  if [ -f "$wg_client_conf_dir/$client.conf" ]; then
    if dw_conf_var_is_enabled "$client_name"; then
      dw_echo_colmsg "Wireguard Client $client < $client_name >" 1 a
    else
      dw_echo_colmsg "Wireguard Client $client < $(dw_conf_remove_disabled $client_name) > is Disabled !" 1 a
    fi
    cat "$wg_client_conf_dir/$client.conf" | qrencode -t ansiutf8
  fi
}

#----------------------------------------------------------------------------------------
# Check Wireguard Keys
#----------------------------------------------------------------------------------------
check_server_keys() {
  if [ ! -d "$wg_key_dir" ]; then
    mkdir -p "$wg_key_dir"
  fi
  local create="$1"
  if [ "$create" = '-create' ]; then
    dw_echo_colmsg "==> Create Wireguard Server Keys ..." 1
  else
    dw_echo_colmsg "==> Check Wireguard Server Keys ..." 1
  fi
  if [ "$1" = '-create' ] || [ ! -f "$wg_server_key_private" ] || [ ! -f "$wg_server_key_public" ]; then
    #dw_echo_colmsg "==> Create Wireguard Server Keys ..." 2
    wg genkey | tee "$wg_server_key_private" | wg pubkey >"$wg_server_key_public"
  else
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK Wireguard Server Keys found ..." 2 o
  fi
}

check_client_key() {
  local client="$1"
  local create="$2"
  wg_client_key_dir="$wg_key_dir/$client"
  wg_client_key_private="$wg_client_key_dir/${client}_private.key"
  wg_client_key_public="$wg_client_key_dir/${client}_public.key"
  wg_client_key_preshared="$wg_client_key_dir/${client}_preshared.key"
  mkdir -p "$wg_client_key_dir"
  if [ "$create" = '-create' ] || [ ! -f "$wg_client_key_private" ] || [ ! -f "$wg_client_key_public" ] || [ ! -f "$wg_client_key_preshared" ]; then
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Wireguard Client Keys $client ..." 2
    umask 077 && wg genkey | tee "$wg_client_key_private" | wg pubkey >"$wg_client_key_public"
    umask 077 && wg genpsk >"$wg_client_key_preshared"
  else
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK Wireguard Client Keys $client found ..." 2 o
  fi
}

check_client_keys() {
  local create="$1"
  if [ "$create" = '-create' ]; then
    dw_echo_colmsg "==> Create Wireguard Client Keys ..." 1
  else
    dw_echo_colmsg "==> Check Wireguard Client Keys ..." 1
  fi
  local idx='1'
  eval client_n='$WG_CLIENT_N'
  while [ "$idx" -le "$client_n" ]; do
    eval client_name='$WG_CLIENT_'$idx'_NAME'
    eval client_mail='$WG_CLIENT_'$idx'_MAIL'
    check_client_key "$idx" "$create"
    idx=$(expr $idx + 1)
  done
}

list_clients() {
  #dw_echo_colmsg "Wireguard Client(s):" 0
  local idx='1'
  eval client_n='$WG_CLIENT_N'
  while [ "$idx" -le "$client_n" ]; do
    eval client_name='$WG_CLIENT_'$idx'_NAME'
    eval client_mail='$WG_CLIENT_'$idx'_MAIL'
    if dw_conf_var_is_enabled "$client_name"; then
      dw_echo_colmsg "$idx $(dw_conf_remove_disabled $client_name)" 0
    else
      dw_echo_colmsg "$idx $(dw_conf_remove_disabled $client_name) = Disabled" 0 n
    fi
    idx=$(expr $idx + 1)
  done
}

#-------------------------------------------------------------------------------
# Check Clients Connect/Disconnect Service
#-------------------------------------------------------------------------------
check_clients_connect_disconnect() {
  dw_echo_colmsg "==> Check Clients Connect/Disconnect Service ..." 1
  dw_sctl_reload
  dw_sctl_enable dwwgcheckclients.service
  dw_sctl_enable dwwgcheckclients.timer
  dw_sctl_restart dwwgcheckclients.timer
}

do_config() {
  check_ip_forward
  create_dwwg_config_file
  check_server_keys "$create"
  check_client_keys "$create"
  create_server_entry
  create_client_entrys
  create_client_configs
  check_clients_connect_disconnect
}

#===============================================================================
# Main
#===============================================================================

#. /var/dwsetup/lib/dw-all.libs
. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-wg.config

create=''

if [ "$1" == "-quiet" -o "$1" == "quiet" ]; then
  quiet="quiet"
  shift
else
  quiet=''
fi

case "$1" in
  showqr)
    shift
    if [ -n "$1" ]; then
      show_client_qr "$1"
    else
     dw_echo_colmsg "Select Client:" 0 a
     list_clients
    fi
    ;;
  mailconf)
    shift
    if [ "$1" = 'all' ]; then
      send_client_config_all
    elif [ -n "$1" ]; then
      send_client_config "$1"
    else
     dw_echo_colmsg "Select Client:" 0 a
     list_clients
    fi
    ;;
  list)
    list_clients
    ;;
  create)
    create='-create'
    do_config
    ;;
  *)
    do_config
    ;;
esac

#===============================================================================
# End
#===============================================================================
exit 0
