#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-mailserver.update.sh
#         - Update or Generate New Mail-Server Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  14.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-mailserver.config'
config_header='/var/dwsetup/header/dw-mailserver.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
  #else
  #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
  #else
  #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
  #else
  #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
  #else
  #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "  ==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Mail Notification Settings"
    dw_conf_line
    echo
    dw_conf_var "MAIL_NOTIFY"
    dw_conf_comment "# Mail Notification yes or no"
    echo
    dw_conf_var "MAIL_NOTIFY_ADDRESS_ADMIN"
    dw_conf_comment "# Admin Email Address for Mail Notification"
    echo
    dw_conf_var "MAIL_NOTIFY_ADDRESS"
    dw_conf_comment "# Email Address for Mail Notification"
    echo
    dw_conf_var "MAIL_NOTIFY_ADDRESS_ALARM"
    dw_conf_comment "# Alarm Email Address for Mail Notification"
    echo
    dw_conf_var "MAIL_ADDRESS_BACKUP"
    dw_conf_comment "# Email Address for sending Backup via Mail"
    echo
    dw_conf_line
    echo "# Mail-Server: Settings"
    dw_conf_line
    echo
    dw_conf_var "MAIL_HOSTNAME"
    dw_conf_comment "# if MAIL_HOSTNAME='' then (hostname HOSTNAME) is used"
    echo
    dw_conf_var "MAIL_DOMAIN"
    dw_conf_comment "# if MAIL_DOMAIN='' then (hostname -d DOMAIN) is used"
    echo
    dw_conf_var "MAIL_ADDITIONALL_DOMAINS"
    dw_conf_comment "# add additionall Domains separated by spaces, domain1 domain2 domain3 ..."
    echo
    dw_conf_var "MAIL_ADDITIONALL_MYNETWORKS"
    dw_conf_comment "# 127.0.0.0/8 [::ffff:127.0.0.0]/104 [::1]/128 always defined, add only others in ip or network/cidr format"
    echo
    dw_conf_var "SPF_CHECK"
    dw_conf_comment "# SPF Check yes or no"
    echo
    dw_conf_var "DKIM_SIGNING"
    dw_conf_comment "# DKIM signing yes or no"
    echo
    dw_conf_var "MAIL_DOMAIN_LETSENCRYPT"
    dw_conf_comment "# if MAIL_LETSENCRYPT='yes' then (MAIL_DOMAIN LetsEnCrypt) is used"
    echo
    dw_conf_var "MAIL_DOMAIN_SIEVE"
    dw_conf_comment "# if MAIL_DOMAIN_SIEVE='' then MAIL_DOMAIN is used if MAIL_DOMAIN_='' (hostname -d DOMAIN) is used"
    echo
    dw_conf_var "MAIL_POSTMASTER"
    dw_conf_comment "# if MAIL_POSTMASTER='' then root is used"
    echo
    dw_conf_var "MAIL_LOCAL_FROM"
    dw_conf_comment "# if MAIL_LOCAL_FROM='' then noreply@(hostname -d DOMAIN) is used"
    echo
    dw_conf_var "MAIL_LOCAL_FROM_NAME"
    dw_conf_comment "# if MAIL_LOCAL_FROM_NAME='' then NoReply@(hostname -f FQDN) is used"
    echo
    dw_conf_var "MAIL_MESSAGE_SIZE_LIMIT"
    dw_conf_comment "# Max E-Mail Size in Bytes (1 MB = 1048576 Bytes) 0 disables it"
    echo
    dw_conf_var "MAIL_RELAYHOST"
    dw_conf_comment "# if MAIL_RELAYHOST='' or Prefix it with a ! to Disable"
    dw_conf_var "MAIL_RELAYHOST_SMTP_AUTH"
    dw_conf_var "MAIL_RELAYHOST_USER"
    dw_conf_var "MAIL_RELAYHOST_PASSWD"
    echo
    dw_conf_var "MAIL_DEBUG"
    dw_conf_comment "# MAIL_DEBUG yes or no"
    dw_conf_comment "# use Postfix -vv or empty"
    dw_conf_comment "# use Dovecot auth_verbose auth_verbose_passwords auth_debug auth_debug_passwords mail_debug verbose_ssl yes or no"
    echo
    dw_conf_line
    echo "# Mail-Server: ALias Domains"
    echo "#"
    echo "# (Prefix a Domain in MAIL_ALIAS_DOMAINS_x with a ! to Disable it)"
    echo "#   in MAIL_ALIAS_DOMAINS_x & MAIL_ALIAS_DOMAINS_x_TO"
    echo "#   you can define a Domain Alias from MAIL_ADDITIONALL_DOMAINS"
    echo "#   if MAIL_ALIAS_DOMAINS_x_TO='' then defaults to MAIL_DOMAIN"
    dw_conf_line
    echo
    dw_conf_var "MAIL_ALIAS_DOMAINS_N"
    if [ $MAIL_ALIAS_DOMAINS_N -eq 0 ]
    then
      imax=1
    else
      imax=$MAIL_ALIAS_DOMAINS_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval mail_alias_domains='$MAIL_ALIAS_DOMAINS_'$idx
      eval mail_alias_domains_to='$MAIL_ALIAS_DOMAINS_'$idx'_TO'
      echo "MAIL_ALIAS_DOMAINS_"$idx"='$mail_alias_domains'"
      echo "MAIL_ALIAS_DOMAINS_"$idx"_TO='$mail_alias_domains_to'"
      idx=$(expr $idx + 1)
    done
    echo
    dw_conf_line
    echo "# Mail-Server: Local Mail Aliases /etc/aliases"
    echo "#"
    echo "# Default Aliases are declared:"
    echo "# MAILER-DAEMON: root"
    echo "# postmaster: root"
    echo "# hostmaster: root"
    echo "# webmaster: root"
    echo "# ftpmaster: root"
    echo "#"
    echo "# (Prefix a FROM in LOCAL_MAIL_ALIASES_x_FROM with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "LOCAL_MAIL_ALIASES_N"
    if [ $LOCAL_MAIL_ALIASES_N -eq 0 ]
    then
      imax=1
    else
      imax=$LOCAL_MAIL_ALIASES_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval local_alias_from='$LOCAL_MAIL_ALIASES_'$idx'_FROM'
      eval local_alias_to='$LOCAL_MAIL_ALIASES_'$idx'_TO'
      echo "LOCAL_MAIL_ALIASES_"$idx"_FROM='$local_alias_from'"
      echo "LOCAL_MAIL_ALIASES_"$idx"_TO='$local_alias_to'"
      idx=$(expr $idx + 1)
    done
    echo
    dw_conf_line
    echo "# Mail-Server: Mail User"
    dw_conf_line
    echo
    dw_conf_var "MAIL_USER_CATCHALL"
    dw_conf_comment "# if MAIL_USER_CATCHALL='' then disables the catchall"
    echo
    dw_conf_var "MAIL_USER_NOREPLY_EXTERNAL_DOMAIN"
    dw_conf_comment "# if MAIL_USER_NOREPLY_EXTERNAL_DOMAIN='' then disables the external noreply rewriting"
    echo
    dw_conf_var "MAIL_USER_NOREPLY_MAIL_DISCARD"
    dw_conf_comment "# Discard Mail to noreply yes or no"
    echo
    echo "MAIL_USER_NOREPLY_VIRTUAL_ALIAS_MAP_TO='$MAIL_USER_NOREPLY_VIRTUAL_ALIAS_MAP_TO'"
    dw_conf_comment "# if MAIL_USER_NOREPLY_VIRTUAL_ALIAS_MAP_TO='' then noreply@MAIL_DOMAIN is used"
    echo
    echo "MAIL_USER_ALLOW_SEND_AS_NOREPLY='$MAIL_USER_ALLOW_SEND_AS_NOREPLY'"
    dw_conf_comment "# if MAIL_USER_ALLOW_SEND_AS_NOREPLY='' then disables the noreply sending"
    echo
    dw_conf_line
    echo "# (Prefix a MAIL_USER_x_NAME with a ! to Disable it)"
    echo "# if MAIL_USER_DOMAINS='' then defaults to MAIL_DOMAIN"
    echo "#   otherwise add Domains separated by spaces, domain1 domain2 domain3"
    echo "#   (Prefix MAIL_USER_DOMAINS with a ! to Disable it)"
    echo "# (Prefix a MAIL_USER_x_ALIAS_x with a ! to Disable it)"
    echo "# *** !!! User noreply is default defined, don't redefine it !!! ***"
    echo "# (Prefix a MAIL_USER_x_ALIAS_x with a ! to Disable it)"
    echo "#   in MAIL_USER_x_ALIAS_x you can add a Domain from MAIL_ADDITIONALL_DOMAINS (alias@domain)"
    dw_conf_line
    echo
    dw_conf_var "MAIL_USER_N"
    dw_conf_comment "# Number of Users"
    echo
    if [ $MAIL_USER_N -eq 0 ]
    then
      imax=1
    else
      imax=$MAIL_USER_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval mail_user_name='$MAIL_USER_'$idx'_NAME'
      eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
      eval mail_user_external_address='$MAIL_USER_'$idx'_EXTERNAL_ADDRESS'
      eval mail_user_pwd='$MAIL_USER_'$idx'_PWD'
      eval mail_user_sendonly='$MAIL_USER_'$idx'_SENDONLY'
      eval mail_user_quota='$MAIL_USER_'$idx'_QUOTA'
      echo "MAIL_USER_"$idx"_NAME='$mail_user_name'"
      echo "MAIL_USER_"$idx"_DOMAIN='$mail_user_domain'"
      echo "MAIL_USER_"$idx"_EXTERNAL_ADDRESS='$mail_user_external_address'"
      echo "MAIL_USER_"$idx"_PWD='$mail_user_pwd'"
      echo "MAIL_USER_"$idx"_QUOTA='$mail_user_quota'"
      eval mail_user_alias_n='$MAIL_USER_'$idx'_ALIAS_N'
      echo "MAIL_USER_"$idx"_ALIAS_N='$mail_user_alias_n'"
      if [ $mail_user_alias_n -eq 0 ]
      then
        imaxa=1
      else
        imaxa=$mail_user_alias_n
      fi
      idxa=1
      while [ $idxa -le $imaxa ]
      do
        eval mail_user_alias='$MAIL_USER_'$idx'_ALIAS_'$idxa
        echo "MAIL_USER_"$idx"_ALIAS_"$idxa"='$mail_user_alias'"
        idxa=$(expr $idxa + 1)
      done
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_footer
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
