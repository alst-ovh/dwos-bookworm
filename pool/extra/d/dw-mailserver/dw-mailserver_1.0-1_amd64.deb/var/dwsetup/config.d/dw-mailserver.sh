#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-mailserver.sh - Configuration Generator Script for Mail-Server
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  14.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-mailserver'

# Mail
mailname_file='/etc/mailname'

snail_rc_file='/etc/s-nail.rc'

aliases_file='/etc/aliases'
new_aliases='/usr/bin/newaliases'

mail_ssl_cert='/etc/dwconfig.d/share/ssl/server-cert.crt'
mail_ssl_key='/etc/dwconfig.d/share/ssl/server-key.crt'

dovecot_passwd_file='/etc/dovecot/dovecot.passwd'
dovecot_config_file='/etc/dovecot/dovecot.conf'
dovecot_dhpem_file='/etc/dovecot/dh2048.pem'
dovecot_logrotate='/etc/logrotate.d/dovecot'

postfix_main_cf='/etc/postfix/main.cf'
postfix_master_cf='/etc/postfix/master.cf'
postfix_submission_header_cleanup='/etc/postfix/submission-header-cleanup'

postfix_hash_dir='/etc/postfix/hash'
postfix_smtp_generic_maps="$postfix_hash_dir/smtp-generic-maps"
postfix_virtual_mailbox_domains="$postfix_hash_dir/virtual-mailbox-domains"
postfix_virtual_mailbox_maps="$postfix_hash_dir/virtual-mailbox-maps"
postfix_smtpd_recipient_restrictions="$postfix_hash_dir/smtpd-recipient-restrictions"
postfix_recipient_canonical_maps="$postfix_hash_dir/recipient-canonical-maps"
postfix_smtpd_sender_login_maps="$postfix_hash_dir/smtpd-sender-login-maps"
postfix_virtual_alias_maps="$postfix_hash_dir/virtual-alias-maps"
postfix_sender_canonical_maps="$postfix_hash_dir/sender-canonical-maps"
postfix_transport_maps="$postfix_hash_dir/transport-maps"
postfix_smtp_sasl_passwd_maps="$postfix_hash_dir/smtp-sasl-passwd-maps"
postfix_smtp_tls_policy_maps="$postfix_hash_dir/smtp-tls-policy-maps"
postfix_client_access_maps="$postfix_hash_dir/client-access-maps"
postfix_postscreen_access="$postfix_hash_dir/postscreen_access"
postfix_relay_recipient_maps="$postfix_hash_dir/relay-recipient-maps"
postfix_sender_dependent_relayhost_maps="$postfix_hash_dir/sender-dependet-relayhost-maps"

mail_relay_domains_transport_type_default='smtp'
mail_relay_domains_transport_port_default='587'

sieve_base_dir='/var/vmail'
sieve_spam_global_dir="$sieve_base_dir/sieve/global"
sieve_spam_global_file="$sieve_spam_global_dir/spam-global.sieve"

opendkim_dkim_selektor='2024'
opendkim_default_file='/etc/default/opendkim'
opendkim_config_file='/etc/opendkim.conf'
opendkim_config_dir='/etc/opendkim'
opendkim_keys_dir='/etc/dwconfig.d/share/opendkim-keys'
opendkim_config_file_trusted="$opendkim_config_dir/trusted"
opendkim_config_file_signing_table="$opendkim_config_dir/signing.table"
opendkim_config_file_key_table="$opendkim_config_dir/key.table"

default_user_sendonly='no'

mail_conf_file='/etc/dwconfig.d/conf/dw-mail.conf'

#===============================================================================
# Mail-Server Begin
#===============================================================================

#----------------------------------------------------------------------------------------
# check directory if exists or create it
#----------------------------------------------------------------------------------------
check_create_dir() {
  if [ ! -d "$1" ]; then
    dw_echo_colmsg "==> Create Directory $1 ..." 1
    mkdir -p "$1"
  fi
}

#----------------------------------------------------------------------------------------
# check vmail Data directory
#----------------------------------------------------------------------------------------
check_vmail_data_dir() {
  if [ ! -d "$DATA_DIR/vmail/mailboxes" ]; then
    mkdir -p "$DATA_DIR/vmail/mailboxes"
  fi
  chown -R vmail:vmail "$DATA_DIR/vmail"
  chmod 770 "$DATA_DIR/vmail"
  chmod 770 "$DATA_DIR/vmail/mailboxes"
}

#----------------------------------------------------------------------------------------
# check vmail Sieve directory
#----------------------------------------------------------------------------------------
check_vmail_sieve_dir() {
  if [ ! -d /var/vmail/sieve/global ]; then
    mkdir -p /var/vmail/sieve/global
  fi
  chown -R vmail:vmail /var/vmail
  chmod 770 /var/vmail
  chmod 770 /var/vmail/sieve
  chmod 770 /var/vmail/sieve/global
  rm -f /var/vmail/sieve/global/*.svbin
}

#-------------------------------------------------------------------------------
# create /etc/mailname $mailname_file file
#-------------------------------------------------------------------------------
create_mailname_file() {
  dw_echo_colmsg "==> Create mailname File $mailname_file ..." 1
  hostname -f >$mailname_file
}

#-------------------------------------------------------------------------------
# create s-nail.rc file
#-------------------------------------------------------------------------------
create_snail_rc() {
  write_snail_rc() {
    (
      dw_conf_line
      echo "# $snail_rc_file - Configuration File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "set autocollapse"
      echo "set append"
      echo "set ask"
      echo "#set bsdannounce"
      echo "set crt"
      echo "set dot"
      echo "set history-gabby"
      echo "set hold"
      echo 'set indentprefix="> "'
      echo "set markanswered"
      echo "set mime-counter-evidence"
      echo "set keep"
      echo "set keepsave"
      echo "set quote"
      echo "set recipients-in-cc"
      echo "set sendcharsets=utf-8,iso-8859-1"
      echo "set sendwait"
      echo "set showname"
      echo "set showto"
      echo "#fwdretain subject date from to"
      echo "retain date from to cc subject message-id mail-followup-to reply-to"
      echo "# if sendmail not set it uses /usr/sbin/sendmail"
      if [ -z $MAIL_LOCAL_FROM ]; then
        MAIL_LOCAL_FROM="noreply@$(hostname -d)"
      fi
      if [ -z $MAIL_LOCAL_FROM_NAME ]; then
        MAIL_LOCAL_FROM_NAME="NoReply.$(hostname -f)"
      fi
      echo 'set from="'$MAIL_LOCAL_FROM_NAME' <'$MAIL_LOCAL_FROM'>"'
      echo
      dw_conf_footer
    ) >$snail_rc_file
  }
  dw_echo_colmsg "==> Create S-Nail Configuration File $snail_rc_file ..." 1
  write_snail_rc
  chmod 0600 $snail_rc_file
}

#-------------------------------------------------------------------------------
# Create aliases File
#-------------------------------------------------------------------------------
create_aliases_file() {
  write_aliases_file() {
    (
      dw_conf_line
      echo "# $aliases_file - Configuration File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "# Basic system aliases -- these MUST be present!"
      echo "MAILER-DAEMON: root"
      echo "postmaster: root"
      echo "hostmaster: root"
      echo "webmaster: root"
      echo "ftpmaster: root"
      echo
      echo "# Local added Aliases"
    ) >$aliases_file
    idx=1
    while [ $idx -le $LOCAL_MAIL_ALIASES_N ]; do
      eval local_mail_aliases_from='$LOCAL_MAIL_ALIASES_'$idx'_FROM'
      if dw_conf_var_is_enabled "$local_mail_aliases_from"; then
        eval local_mail_aliases_to='$LOCAL_MAIL_ALIASES_'$idx'_TO'
        if [ -n "$local_mail_aliases_to" ]; then
          echo "$local_mail_aliases_from: $local_mail_aliases_to" >>$aliases_file
        fi
      else
        dw_echo_colmsg "==> INFO: Alias LOCAL_MAIL_ALIASES_"$idx"_FROM is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    (
      echo
      dw_conf_footer
    ) >>$aliases_file
  }
  dw_echo_colmsg "==> Create Mail Configuration File $aliases_file ..." 1
  write_aliases_file
  chmod 0644 $aliases_file
  $new_aliases
}

#-------------------------------------------------------------------------------
# Create Email Configuration File /etc/dwconfig.d/conf/dw-mail.conf
#-------------------------------------------------------------------------------
create_mail_conf_file() {
  dw_echo_colmsg "==> Create $mail_conf_file..." 1
  (
    dw_conf_line
    echo "# $mail_conf_file - Configuration File"
    echo "#"
    echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
    echo "#"
    echo "# Do not edit this file, use"
    echo "#"
    echo "# 'Edit Configuration'"
    echo "#"
    echo "# in dwsetup > Services > Mail-Server !"
    echo "#"
    dw_conf_date "# Creation date:"
    dw_conf_line
    echo
    echo "MAIL=""'$MAIL_NOTIFY'"
    echo
    echo "MAIL_ADDRESS_ADMIN=""'$MAIL_NOTIFY_ADDRESS_ADMIN'"
    echo
    echo "MAIL_ADDRESS=""'$MAIL_NOTIFY_ADDRESS'"
    echo
    echo "MAIL_ADDRESS_ALARM=""'$MAIL_NOTIFY_ADDRESS_ALARM'"
    echo
    echo "MAIL_ADDRESS_BACKUP=""'$MAIL_ADDRESS_BACKUP'"
    echo
    dw_conf_footer
  ) >$mail_conf_file
  chmod 0644 $mail_conf_file
}

#===============================================================================
# Postfix Begin
#===============================================================================

#----------------------------------------------------------------------------------------
# Postfix main.cf
#----------------------------------------------------------------------------------------

create_postfix_main_cf() {
  write_postfix_main_cf() {
    (
      dw_conf_line
      echo "# $postfix_main_cf - Postfix main.cf File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "# disable backwards compatibility"
      echo "compatibility_level=3.6"
      echo
      echo "##"
      echo "## Netzwerkeinstellungen"
      echo "##"
      echo
      if [ -z "$MAIL_ADDITIONALL_MYNETWORKS" ]; then
        echo "mynetworks = 127.0.0.0/8 [::ffff:127.0.0.0]/104 [::1]/128"
      else
        echo "mynetworks = 127.0.0.0/8 [::ffff:127.0.0.0]/104 [::1]/128 $MAIL_ADDITIONALL_MYNETWORKS"
      fi
      #echo "inet_interfaces = 127.0.0.1, ::1, 5.1.76.152, 2a00:f820:417::7647:b2c2"
      #echo "inet_interfaces = 127.0.0.1, ::1, 5.1.76.152, 2a00:f820:417::7647:b2c2"
      #echo "inet_interfaces = all"
      #echo "inet_interfaces = 127.0.0.1, ::1, 10.9.255.50"
      echo "myhostname = ${MAIL_HOSTNAME}.${MAIL_DOMAIN}"
      #echo "mydomain = $MAIL_DOMAIN"
      #echo "myorigin = $MAIL_DOMAIN"
      echo
      #echo 'mydestination = $myhostname, $mydomain, $myhostname.$mydomain, localhost, localhost.$mydomain'
      echo 'mydestination = $myhostname'
      echo
      echo "##"
      echo "## Mail-Queue Einstellungen"
      echo "##"
      echo
      echo "maximal_queue_lifetime = 1h"
      echo "bounce_queue_lifetime = 1h"
      echo "maximal_backoff_time = 15m"
      echo "minimal_backoff_time = 5m"
      echo "queue_run_delay = 5m"
      echo
      echo "##"
      echo "## TLS Einstellungen"
      echo "###"
      echo
      echo "tls_preempt_cipherlist = yes"
      echo "tls_ssl_options = NO_COMPRESSION"
      echo "tls_high_cipherlist = EDH+CAMELLIA:EDH+aRSA:EECDH+aRSA+AESGCM:EECDH+aRSA+SHA256:EECDH:+CAMELLIA128:+AES128:+SSLv3:!aNULL:!eNULL:!LOW:!3DES:!MD5:!EXP:!PSK:!DSS:!RC4:!SEED:!IDEA:!ECDSA:kEDH:CAMELLIA128-SHA:AES128-SHA"
      echo
      echo '### Ausgehende SMTP-Verbindungen (Postfix als Sender)'
      echo
      # UPC
      #echo "smtp_tls_security_level = encrypt"
      #echo "smtp_tls_wrappermode = yes"
      # Normal
      echo "smtp_tls_security_level = dane"
      echo "smtp_dns_support_level = dnssec"
      #echo "smtp_tls_policy_maps = mysql:/etc/postfix/sql/tls-policy.cf"
      echo "smtp_tls_policy_maps = hash:$postfix_smtp_tls_policy_maps"
      echo 'smtp_tls_session_cache_database = btree:${data_directory}/smtp_scache'
      echo "smtp_tls_protocols = !SSLv2, !SSLv3"
      echo "smtp_tls_ciphers = high"
      echo "smtp_tls_CAfile = /etc/ssl/certs/ca-certificates.crt"
      echo "# Rewrite Rules for Sender Addresses, External Addresses"
      echo "# user@internal.domain external@mail-address.at"
      echo "smtp_generic_maps = hash:$postfix_smtp_generic_maps"
      echo
      echo "### Eingehende SMTP-Verbindungen"
      echo
      echo "smtpd_tls_security_level = may"
      echo "smtpd_tls_protocols = !SSLv2, !SSLv3"
      echo "smtpd_tls_ciphers = high"
      echo 'smtpd_tls_session_cache_database = btree:${data_directory}/smtpd_scache'
      echo
      #echo "smtpd_tls_cert_file=/etc/letsencrypt/live/mail.mysystems.tld/fullchain.pem"
      #echo "smtpd_tls_key_file=/etc/letsencrypt/live/mail.mysystems.tld/privkey.pem"
      #echo "smtpd_tls_cert_file=/etc/dovecot/private/mycert.pem"
      #echo "smtpd_tls_key_file=/etc/dovecot/private/mykey.key"
      echo "smtpd_tls_key_file=$mail_ssl_key"
      echo "smtpd_tls_cert_file=$mail_ssl_cert"
      echo
      echo "##"
      echo "## Lokale Mailzustellung an Dovecot"
      echo "##"
      echo
      echo "virtual_transport = lmtp:unix:private/dovecot-lmtp"
      echo
      if dw_conf_var_is_yes "$DKIM_SIGNING"; then
        echo "##"
        echo "## DKIM-Signaturen via Opendkim"
        echo "##"
        echo
        echo "milter_default_action = accept"
        echo "milter_protocol   = 6"
        echo "smtpd_milters     = inet:localhost:12345"
        echo "non_smtpd_milters = inet:localhost:12345"
        echo
      fi
      echo "##"
      echo "## Server Restrictions für Clients, Empfänger und Relaying"
      echo '## (im Bezug auf S2S-Verbindungen. Mailclient-Verbindungen werden in master.cf im Submission-Bereich konfiguriert)'
      echo "##"
      echo
      echo '### Bedingungen, damit Postfix als Relay arbeitet (für Clients)'
      echo "smtpd_relay_restrictions =      reject_non_fqdn_recipient"
      echo "                                reject_unknown_recipient_domain"
      echo "                                permit_mynetworks"
      echo "                                reject_unauth_destination"
      echo
      echo '### Bedingungen, damit Postfix ankommende E-Mails als Empfängerserver entgegennimmt (zusätzlich zu relay-Bedingungen)'
      echo "### check_recipient_access prüft, ob ein account sendonly ist"
      if dw_conf_var_is_yes "$SPF_CHECK"; then
        echo "### check_policy_service prüft, auf den SPF record"
        echo "policyd-spf_time_limit = 3600"
        echo "smtpd_recipient_restrictions = check_policy_service unix:private/policyd-spf"
        echo "                               check_recipient_access hash:$postfix_smtpd_recipient_restrictions"
      else
        echo "smtpd_recipient_restrictions = check_recipient_access hash:$postfix_smtpd_recipient_restrictions"
      fi
      echo
      echo '### Bedingungen, die SMTP-Clients erfüllen müssen (sendende Server)'
      echo "smtpd_client_restrictions =     permit_mynetworks"
      #echo "                                check_client_access hash:/etc/postfix/without_ptr"
      echo "                                check_client_access hash:$postfix_client_access_maps"
      echo "                                reject_unknown_client_hostname"
      echo
      echo "### Wenn fremde Server eine Verbindung herstellen, müssen sie einen gültigen Hostnamen im HELO haben."
      echo "smtpd_helo_required = yes"
      echo "smtpd_helo_restrictions =   permit_mynetworks"
      echo "                            reject_invalid_helo_hostname"
      echo "                            reject_non_fqdn_helo_hostname"
      echo "                            reject_unknown_helo_hostname"
      echo
      echo "# Clients blockieren, wenn sie versuchen zu früh zu senden"
      echo "smtpd_data_restrictions = reject_unauth_pipelining"
      echo
      echo "##"
      echo '## Restrictions für MUAs (Mail user agents)'
      echo "##"
      echo
      echo "mua_relay_restrictions = reject_non_fqdn_recipient,reject_unknown_recipient_domain,permit_mynetworks,permit_sasl_authenticated,reject"
      #echo "mua_sender_restrictions = permit_mynetworks,reject_non_fqdn_sender,reject_sender_login_mismatch,permit_sasl_authenticated,reject"
      echo "mua_sender_restrictions = permit_mynetworks,reject_non_fqdn_sender,permit_sasl_authenticated,reject"
      echo "mua_client_restrictions = permit_mynetworks,permit_sasl_authenticated,reject"
      echo
      echo "##"
      echo "## Postscreen Filter"
      echo "##"
      echo
      echo "### Postscreen Whitelist / Blocklist"
      echo "postscreen_access_list =        permit_mynetworks"
      echo "                                cidr:$postfix_postscreen_access"
      echo "postscreen_blacklist_action = drop"
      echo
      echo "# Verbindungen beenden, wenn der fremde Server es zu eilig hat"
      echo "postscreen_greet_action = drop"
      echo
      echo "### DNS blocklists"
      echo "postscreen_dnsbl_threshold = 2"
      echo "postscreen_dnsbl_sites =    ix.dnsbl.manitu.net*2"
      echo "                            zen.spamhaus.org*2"
      echo "postscreen_dnsbl_action = drop"
      echo
      echo "##"
      #echo "## MySQL Abfragen"
      echo "## Hash Abfragen"
      echo "##"
      echo
      echo "alias_maps = hash:/etc/aliases"
      #echo "alias_database = hash:/etc/aliases"
      echo
      #echo "virtual_alias_maps = mysql:/etc/postfix/sql/aliases.cf"
      echo "virtual_alias_maps = hash:$postfix_virtual_alias_maps"
      #echo "virtual_mailbox_maps = mysql:/etc/postfix/sql/accounts.cf"
      echo "virtual_mailbox_maps = hash:$postfix_virtual_mailbox_maps"
      #echo "virtual_mailbox_domains = mysql:/etc/postfix/sql/domains.cf"
      #echo "virtual_mailbox_domains = hash:/etc/postfix/virtual_mailbox_domains"
      echo "virtual_mailbox_domains = hash:$postfix_virtual_mailbox_domains"
      echo 'local_recipient_maps = $virtual_mailbox_maps'
      echo
      echo "##"
      echo "## Sonstiges"
      echo "##"
      echo
      echo '### Maximale Größe der gesamten Mailbox (soll von Dovecot festgelegt werden, 0 = unbegrenzt)'
      echo "mailbox_size_limit = 0"
      echo
      echo '### Maximale Größe eingehender E-Mails in Bytes (1 MB = 1048576 Bytes) 0 disables it'
      echo "message_size_limit = $MAIL_MESSAGE_SIZE_LIMIT"
      echo
      echo "### Keine System-Benachrichtigung für Benutzer bei neuer E-Mail"
      echo "biff = no"
      echo
      echo "### Nutzer müssen immer volle E-Mail Adresse angeben - nicht nur Hostname"
      echo "append_dot_mydomain = no"
      #echo "append_dot_mydomain = yes"
      echo
      echo '### Trenn-Zeichen für "Address Tagging"'
      echo "recipient_delimiter = +"
      echo
      echo "### SMTP Auth"
      echo "smtp_sasl_auth_enable = yes"
      echo "smtp_sasl_security_options = noanonymous"
      #echo "smtp_tls_security_level = encrypt"
      echo "smtp_sasl_password_maps = hash:$postfix_smtp_sasl_passwd_maps"
      echo "smtp_tls_CAfile = /etc/ssl/certs/ca-certificates.crt"
      echo
      if dw_conf_var_is_enabled "$MAIL_RELAYHOST"; then
        if [ -n "$MAIL_RELAYHOST" ]; then
          echo "### Relay Host"
          echo "relayhost = $MAIL_RELAYHOST"
          echo
        fi
      fi
      echo "### Sender Rewrite"
      echo "sender_canonical_maps = hash:$postfix_sender_canonical_maps"
      echo
      echo "### Outgoing Mail Redirections"
      echo "recipient_canonical_maps = hash:$postfix_recipient_canonical_maps"
      echo
      echo "transport_maps = hash:$postfix_transport_maps"
      echo
      echo "default_destination_concurrency_limit = 10"
      echo
      echo "maillog_file = /var/log/mail.log"
      dw_conf_footer e
    ) >$postfix_main_cf
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix main.cf File $postfix_main_cf ..." 1
  write_postfix_main_cf
}

#----------------------------------------------------------------------------------------
# Postfix master.cf
#----------------------------------------------------------------------------------------

create_postfix_master_cf() {
  write_postfix_master_cf() {
    (
      dw_conf_line
      echo "# $postfix_master_cf - Postfix master.cf File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "# =========================================================================="
      echo "# service type  private unpriv  chroot  wakeup  maxproc command + args"
      echo '#               (yes)   (yes)   (no)    (never) (100)'
      echo "# =========================================================================="
      echo
      echo "###"
      echo "### Postscreen-Service: Prüft eingehende SMTP-Verbindungen auf Spam-Server"
      echo "###"
      echo "smtp      inet  n       -       y       -       1       postscreen"
      echo "    -o smtpd_sasl_auth_enable=no"
      echo "###"
      echo "### SMTP-Daemon hinter Postscreen."
      echo "###"
      if dw_conf_var_is_yes "$MAIL_DEBUG"; then
        echo "smtpd     pass  -       -       y       -       -       smtpd -vv"
      else
        echo "smtpd     pass  -       -       y       -       -       smtpd"
      fi
      echo "###"
      echo "### dnsblog führt DNS-Abfragen für Blocklists durch"
      echo "###"
      echo "dnsblog   unix  -       -       y       -       0       dnsblog"
      echo "###"
      echo "### tlsproxy gibt Postscreen TLS support"
      echo "###"
      echo "tlsproxy  unix  -       -       y       -       0       tlsproxy"
      echo "###"
      echo '### Submission-Zugang für Clients: Für Mailclients gelten andere Regeln, als für andere Mailserver (siehe smtpd_ in main.cf)'
      echo "###"
      echo "submission inet n       -       y       -       -       smtpd"
      echo "    -o syslog_name=postfix/submission"
      echo "    -o smtpd_tls_security_level=encrypt"
      echo "    -o smtpd_sasl_auth_enable=yes"
      echo "    -o smtpd_sasl_type=dovecot"
      echo "    -o smtpd_sasl_path=private/auth"
      echo "    -o smtpd_sasl_security_options=noanonymous"
      echo '    -o smtpd_client_restrictions=$mua_client_restrictions'
      echo '    -o smtpd_sender_restrictions=$mua_sender_restrictions'
      echo '    -o smtpd_relay_restrictions=$mua_relay_restrictions'
      echo "    -o milter_macro_daemon_name=ORIGINATING"
      #echo "    -o smtpd_smtpd_sender_login_maps=mysql:/etc/postfix/sql/sender-login-maps.cf"
      echo "    -o smtpd_sender_login_maps=hash:$postfix_smtpd_sender_login_maps"
      echo "    -o smtpd_helo_required=no"
      echo "    -o smtpd_helo_restrictions="
      echo "    -o cleanup_service_name=submission-header-cleanup"
      echo "###"
      echo "### Weitere wichtige Dienste für den Serverbetrieb"
      echo "###"
      echo "pickup    unix  n       -       y       60      1       pickup"
      echo "cleanup   unix  n       -       y       -       0       cleanup"
      echo "qmgr      unix  n       -       n       300     1       qmgr"
      echo "tlsmgr    unix  -       -       y       1000?   1       tlsmgr"
      echo "rewrite   unix  -       -       y       -       -       trivial-rewrite"
      echo "bounce    unix  -       -       y       -       0       bounce"
      echo "defer     unix  -       -       y       -       0       bounce"
      echo "trace     unix  -       -       y       -       0       bounce"
      echo "verify    unix  -       -       y       -       1       verify"
      echo "flush     unix  n       -       y       1000?   0       flush"
      echo "proxymap  unix  -       -       n       -       -       proxymap"
      echo "proxywrite unix -       -       n       -       1       proxymap"
      echo "smtp      unix  -       -       y       -       -       smtp"
      echo "relay     unix  -       -       y       -       -       smtp"
      echo "showq     unix  n       -       y       -       -       showq"
      echo "error     unix  -       -       y       -       -       error"
      echo "retry     unix  -       -       y       -       -       error"
      echo "discard   unix  -       -       y       -       -       discard"
      echo "local     unix  -       n       n       -       -       local"
      echo "virtual   unix  -       n       n       -       -       virtual"
      echo "lmtp      unix  -       -       y       -       -       lmtp"
      echo "anvil     unix  -       -       y       -       1       anvil"
      echo "scache    unix  -       -       y       -       1       scache"
      echo "###"
      echo "### Cleanup-Service um MUA header zu entfernen"
      echo "###"
      echo "submission-header-cleanup unix n - n    -       0       cleanup"
      echo "   -o header_checks=regexp:$postfix_submission_header_cleanup"
      if dw_conf_var_is_yes "$SPF_CHECK"; then
        echo "###"
        echo "### SPF Policy Agent"
        echo "###"
        echo "policyd-spf  unix  -       n       n    -       0       spawn"
        echo "   user=policyd-spf argv=/usr/bin/policyd-spf"
      fi
      echo
      echo "postlog   unix-dgram n  -       n       -       1       postlogd"
      dw_conf_footer e
    ) >$postfix_master_cf
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix master.cf File $postfix_master_cf ..." 1
  write_postfix_master_cf
}

#----------------------------------------------------------------------------------------
# Postfix smtp_generic_maps $postfix_smtp_generic_maps
#----------------------------------------------------------------------------------------

create_postfix_smtp_generic_maps() {
  write_postfix_smtp_generic_maps() {
    (
      dw_conf_line
      echo "# $postfix_smtp_generic_maps - Postfix smtp_generic_maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
    ) >$postfix_smtp_generic_maps
    if [ -n "$MAIL_USER_NOREPLY_EXTERNAL_DOMAIN" ]; then
      (
        echo "@${MAIL_HOSTNAME}.${MAIL_DOMAIN} noreply@$MAIL_USER_NOREPLY_EXTERNAL_DOMAIN"
        echo "noreply@$MAIL_DOMAIN noreply@$MAIL_USER_NOREPLY_EXTERNAL_DOMAIN"
      ) >>$postfix_smtp_generic_maps
    fi
    idx=1
    while [ $idx -le $MAIL_USER_N ]; do
      eval user_name='$MAIL_USER_'$idx'_NAME'
      if dw_conf_var_is_enabled "$user_name"; then
        eval user_external_address='$MAIL_USER_'$idx'_EXTERNAL_ADDRESS'
        if [ -n "$user_external_address" ]; then
          eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
          if [ -n "$mail_user_domain" ]; then
            for domain in $mail_user_domain; do
              if dw_conf_var_is_enabled "$domain"; then
                echo "$user_name@$domain $user_external_address" >>$postfix_smtp_generic_maps
              fi
            done
          else
            echo "$user_name@$MAIL_DOMAIN $user_external_address" >>$postfix_smtp_generic_maps
          fi
        fi
      #else
      #  dw_echo_colmsg "==> INFO: User MAIL_USER_$idx is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    (
      echo
      dw_conf_footer
    ) >>$postfix_smtp_generic_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix smtp_generic_maps File $postfix_smtp_generic_maps ..." 1
  write_postfix_smtp_generic_maps
  postmap $postfix_smtp_generic_maps
}

#----------------------------------------------------------------------------------------
# Postfix recipient_canonical_maps $postfix_recipient_canonical_maps
#----------------------------------------------------------------------------------------

create_postfix_recipient_canonical_maps() {
  write_postfix_recipient_canonical_maps() {
    (
      dw_conf_line
      echo "# $postfix_recipient_canonical_maps - Postfix recipient-canonical-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "@${MAIL_HOSTNAME}.${MAIL_DOMAIN} admin@$MAIL_DOMAIN"
    ) >$postfix_recipient_canonical_maps
    idx=1
    while [ $idx -le $MAIL_USER_N ]; do
      eval user_name='$MAIL_USER_'$idx'_NAME'
      if dw_conf_var_is_enabled "$user_name"; then
        eval user_external_address='$MAIL_USER_'$idx'_EXTERNAL_ADDRESS'
        if [ -n "$user_external_address" ]; then
          eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
          if [ -n "$mail_user_domain" ]; then
            for domain in $mail_user_domain; do
              if dw_conf_var_is_enabled "$domain"; then
                echo "$user_external_address $user_name@$domain" >>$postfix_recipient_canonical_maps
              fi
            done
          else
            echo "$user_external_address $user_name@$MAIL_DOMAIN" >>$postfix_recipient_canonical_maps
          fi
        fi
      #else
      #  dw_echo_colmsg "==> INFO: User MAIL_USER_$idx is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    (
      echo
      dw_conf_footer
    ) >>$postfix_recipient_canonical_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix recipient_canonical_maps File $postfix_recipient_canonical_maps ..." 1
  write_postfix_recipient_canonical_maps
  postmap $postfix_recipient_canonical_maps
}

#----------------------------------------------------------------------------------------
# Postfix virtual_mailbox_domains $postfix_virtual_mailbox_domains
#----------------------------------------------------------------------------------------

create_postfix_virtual_mailbox_domains() {
  write_postfix_virtual_mailbox_domains() {
    (
      dw_conf_line
      echo "# $postfix_virtual_mailbox_domains - Postfix virtual-mailbox-domains File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "$MAIL_DOMAIN 1"
      if [ -n "$MAIL_ADDITIONALL_DOMAINS" ]; then
        for domain in "$MAIL_ADDITIONALL_DOMAINS"; do
          if dw_conf_var_is_enabled "$domain"; then
            echo
            echo "$domain 1"
          fi
        done
      fi
      echo
      dw_conf_footer
    ) >$postfix_virtual_mailbox_domains
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix virtual_mailbox_domains File $postfix_virtual_mailbox_domains ..." 1
  write_postfix_virtual_mailbox_domains
  postmap $postfix_virtual_mailbox_domains
}

#----------------------------------------------------------------------------------------
# Postfix virtual_mailbox_maps $postfix_virtual_mailbox_maps
#----------------------------------------------------------------------------------------

create_postfix_virtual_mailbox_maps() {
  write_postfix_virtual_mailbox_maps() {
    (
      dw_conf_line
      echo "# $postfix_virtual_mailbox_maps - Postfix virtual-mailbox-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
    ) >$postfix_virtual_mailbox_maps
    idx=1
    while [ $idx -le $MAIL_USER_N ]; do
      eval user_name='$MAIL_USER_'$idx'_NAME'
      if dw_conf_var_is_enabled "$user_name"; then
        eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
        if [ -n "$mail_user_domain" ]; then
          for domain in $mail_user_domain; do
            if dw_conf_var_is_enabled "$domain"; then
              echo "$user_name@$domain 1" >>$postfix_virtual_mailbox_maps
            fi
          done
        else
          echo "$user_name@$MAIL_DOMAIN 1" >>$postfix_virtual_mailbox_maps
        fi
      #else
      #  dw_echo_colmsg "==> INFO: User MAIL_USER_$idx is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    (
      echo
      dw_conf_footer
    ) >>$postfix_virtual_mailbox_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix virtual_mailbox_maps File $postfix_virtual_mailbox_maps ..." 1
  write_postfix_virtual_mailbox_maps
  postmap $postfix_virtual_mailbox_maps
}

#----------------------------------------------------------------------------------------
# Postfix smtpd_recipient_restrictions $postfix_smtpd_recipient_restrictions
#----------------------------------------------------------------------------------------

create_postfix_smtpd_recipient_restrictions() {
  write_postfix_smtpd_recipient_restrictions() {
    #:>$postfix_smtpd_recipient_restrictions
    (
      dw_conf_line
      echo "# $postfix_smtpd_recipient_restrictions - Postfix smtpd-recipient-restrictions File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
    ) >$postfix_smtpd_recipient_restrictions
    idx=1
    while [ $idx -le $MAIL_USER_N ]; do
      eval user_name='$MAIL_USER_'$idx'_NAME'
      if dw_conf_var_is_enabled "$user_name"; then
        eval user_sendonly='$MAIL_USER_'$idx'_SENDONLY'
        if [ -z "$user_sendonly" ]; then
          user_sendonly=$default_user_sendonly
        fi
        if dw_conf_var_is_yes "$user_sendonly"; then
          eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
          if [ -n "$mail_user_domain" ]; then
            for domain in $mail_user_domain; do
              if dw_conf_var_is_enabled "$domain"; then
                echo "$user_name@$domain REJECT" >>$postfix_smtpd_recipient_restrictions
              fi
            done
          else
            echo "$user_name@$MAIL_DOMAIN REJECT" >>$postfix_smtpd_recipient_restrictions
          fi
        else
          eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
          if [ -n "$mail_user_domain" ]; then
            for domain in $mail_user_domain; do
              if dw_conf_var_is_enabled "$domain"; then
                echo "$user_name@$domain OK" >>$postfix_smtpd_recipient_restrictions
              fi
            done
          else
            echo "$user_name@$MAIL_DOMAIN OK" >>$postfix_smtpd_recipient_restrictions
          fi
        fi
      #else
      #  dw_echo_colmsg "==> INFO: User MAIL_USER_$idx is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    (
      echo
      dw_conf_footer
    ) >>$postfix_smtpd_recipient_restrictions
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix smtpd_recipient_restrictions File $postfix_smtpd_recipient_restrictions ..." 1
  write_postfix_smtpd_recipient_restrictions
  postmap $postfix_smtpd_recipient_restrictions
}

#----------------------------------------------------------------------------------------
# Postfix smtpd_sender_login_maps $postfix_smtpd_sender_login_maps
#----------------------------------------------------------------------------------------

create_postfix_smtpd_sender_login_maps() {
  write_postfix_smtpd_sender_login_maps() {
    #:>$postfix_smtpd_sender_login_maps
    (
      dw_conf_line
      echo "# $postfix_smtpd_sender_login_maps - Postfix smtpd-sender-login-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      if [ -n "$MAIL_USER_ALLOW_SEND_AS_NOREPLY" ]; then
        echo "noreply@$MAIL_DOMAIN $MAIL_USER_ALLOW_SEND_AS_NOREPLY@$MAIL_DOMAIN"
        echo
      fi
    ) >$postfix_smtpd_sender_login_maps
    idx=1
    while [ $idx -le $MAIL_USER_N ]; do
      eval user_name='$MAIL_USER_'$idx'_NAME'
      if dw_conf_var_is_enabled "$user_name"; then
        eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
        if [ -n "$mail_user_domain" ]; then
          for domain in $mail_user_domain; do
            if dw_conf_var_is_enabled "$domain"; then
              echo "$user_name@$domain $user_name@$domain" >>$postfix_smtpd_sender_login_maps
            fi
          done
        else
          echo "$user_name@$MAIL_DOMAIN $user_name@$MAIL_DOMAIN" >>$postfix_smtpd_sender_login_maps
        fi
      #else
      #  dw_echo_colmsg "==> INFO: User MAIL_USER_$idx is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    (
      echo
      dw_conf_footer
    ) >>$postfix_smtpd_sender_login_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix smtp_sender_login_maps File $postfix_smtpd_sender_login_maps ..." 1
  write_postfix_smtpd_sender_login_maps
  postmap $postfix_smtpd_sender_login_maps
}

#----------------------------------------------------------------------------------------
# Postfix virtual_alias_maps $postfix_virtual_alias_maps
#----------------------------------------------------------------------------------------

create_postfix_virtual_alias_maps() {
  write_postfix_virtual_alias_maps() {
    #:>$postfix_virtual_alias_maps
    (
      dw_conf_line
      echo "# $postfix_virtual_alias_maps - Postfix virtual-alias-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      if dw_conf_var_is_yes "$MAIL_USER_NOREPLY_MAIL_DISCARD"; then
        echo "noreply@$MAIL_DOMAIN noreply@$MAIL_DOMAIN"
      else
        if [ -z "$MAIL_USER_NOREPLY_VIRTUAL_ALIAS_MAP_TO" ]; then
          echo "noreply@$MAIL_DOMAIN noreply@$MAIL_DOMAIN"
        else
          echo "noreply@$MAIL_DOMAIN $MAIL_USER_NOREPLY_VIRTUAL_ALIAS_MAP_TO@$MAIL_DOMAIN"
        fi
      fi
    ) >$postfix_virtual_alias_maps
    idx=1
    while [ $idx -le $MAIL_USER_N ]; do
      eval user_name='$MAIL_USER_'$idx'_NAME'
      if dw_conf_var_is_enabled "$user_name"; then
        eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
        if [ -n "$mail_user_domain" ]; then
          for domain in $mail_user_domain; do
            if dw_conf_var_is_enabled "$domain"; then
              echo "$user_name@$domain $user_name@$domain" >>$postfix_virtual_alias_maps
            fi
          done
        else
          echo "$user_name@$MAIL_DOMAIN $user_name@$MAIL_DOMAIN" >>$postfix_virtual_alias_maps
        fi
        idxa=1
        eval mail_user_alias_n='$MAIL_USER_'$idx'_ALIAS_N'
        while [ $idxa -le $mail_user_alias_n ]; do
          eval mail_user_alias='$MAIL_USER_'$idx'_ALIAS_'$idxa
          eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
          if [ -n "$mail_user_alias" ] && dw_conf_var_is_enabled "$mail_user_alias"; then
            if [ -n "$mail_user_domain" ]; then
              for domain in $mail_user_domain; do
              if dw_conf_var_is_enabled "$domain"; then
                if [ $(echo $mail_user_alias | grep '@' | wc -l) -eq 1 ]; then
                  echo "$mail_user_alias $user_name@$domain" >>$postfix_virtual_alias_maps
                else
                  echo "$mail_user_alias@$domain $user_name@$domain" >>$postfix_virtual_alias_maps
                fi
              fi
              done
            else
              if [ $(echo $mail_user_alias | grep '@' | wc -l) -eq 1 ]; then
                echo "$mail_user_alias $user_name@$MAIL_DOMAIN" >>$postfix_virtual_alias_maps
              else
                echo "$mail_user_alias@$MAIL_DOMAIN $user_name@$MAIL_DOMAIN" >>$postfix_virtual_alias_maps
              fi
            fi
          fi
          idxa=$(expr $idxa + 1)
        done
      #else
      #  dw_echo_colmsg "==> INFO: User MAIL_USER_$idx is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    idx=1
    while [ $idx -le $MAIL_ALIAS_DOMAINS_N ]; do
      eval mail_alias_domains='$MAIL_ALIAS_DOMAINS_'$idx
      eval mail_alias_domains_to='$MAIL_ALIAS_DOMAINS_'$idx'_TO'
      if [ -z "$mail_alias_domains_to" ]; then
        mail_alias_domains_to="$MAIL_DOMAIN"
      fi
      if [ -n "$mail_alias_domains" ] && dw_conf_var_is_enabled "$mail_alias_domains" && [ -n "$mail_alias_domains_to" ]; then
        echo "@$mail_alias_domains @$mail_alias_domains_to" >>$postfix_virtual_alias_maps
      fi
      idx=$(expr $idx + 1)
    done
    (
      if [ -n "$MAIL_USER_CATCHALL" ]; then
        echo "@$MAIL_DOMAIN $MAIL_USER_CATCHALL@$MAIL_DOMAIN"
      fi
      echo
      dw_conf_footer
    ) >>$postfix_virtual_alias_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix virtual_alias_maps File $postfix_virtual_alias_maps ..." 1
  write_postfix_virtual_alias_maps
  postmap $postfix_virtual_alias_maps
}

#----------------------------------------------------------------------------------------
# Postfix sender_canonical_maps $postfix_sender_canonical_maps
#----------------------------------------------------------------------------------------

create_postfix_sender_canonical_maps() {
  write_postfix_sender_canonical_maps() {
    (
      dw_conf_line
      echo "# $postfix_sender_canonical_maps - Postfix sender_canonical_maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "@${MAIL_HOSTNAME}.${MAIL_DOMAIN} noreply@$MAIL_DOMAIN"
    ) >$postfix_sender_canonical_maps
    (
      echo
      dw_conf_footer
    ) >>$postfix_sender_canonical_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix sender_canonical_maps File $postfix_sender_canonical_maps ..." 1
  write_postfix_sender_canonical_maps
  postmap $postfix_sender_canonical_maps
}

#----------------------------------------------------------------------------------------
# Postfix transport_maps $postfix_transport_maps
#----------------------------------------------------------------------------------------

create_postfix_transport_maps() {
  write_postfix_transport_maps() {
    #:>$postfix_transport_maps
    (
      dw_conf_line
      echo "# $postfix_transport_maps - Postfix transport-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      if dw_conf_var_is_yes "$MAIL_USER_NOREPLY_MAIL_DISCARD"; then
        echo "noreply@$MAIL_DOMAIN discard:"
      fi
    ) >$postfix_transport_maps
    (
      echo
      dw_conf_footer
    ) >>$postfix_transport_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix transport_maps File $postfix_transport_maps ..." 1
  write_postfix_transport_maps
  postmap $postfix_transport_maps
}

#----------------------------------------------------------------------------------------
# Postfix smtp_sasl_passwd_maps $postfix_smtp_sasl_passwd_maps
#----------------------------------------------------------------------------------------

create_postfix_smtp_sasl_passwd_maps() {
  write_postfix_smtp_sasl_passwd_maps() {
    (
      dw_conf_line
      echo "# $postfix_smtp_sasl_passwd_maps - Postfix smtp-sasl-passwd-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      if dw_conf_var_is_yes "$MAIL_RELAYHOST_SMTP_AUTH"; then
        echo
        echo "$MAIL_RELAYHOST  $MAIL_RELAYHOST_USER:$MAIL_RELAYHOST_PASSWD"
      fi
    ) >$postfix_smtp_sasl_passwd_maps
    (
      echo
      dw_conf_footer
    ) >>$postfix_smtp_sasl_passwd_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix smtp_sasl_passwd_maps File $postfix_smtp_sasl_passwd_maps ..." 1
  write_postfix_smtp_sasl_passwd_maps
  postmap $postfix_smtp_sasl_passwd_maps
}

#----------------------------------------------------------------------------------------
# Postfix smtp_tls_policy_maps $postfix_smtp_tls_policy_maps
#----------------------------------------------------------------------------------------

create_postfix_smtp_tls_policy_maps() {
  write_postfix_smtp_tls_policy_maps() {
    (
      dw_conf_line
      echo "# $postfix_smtp_tls_policy_maps - Postfix smtp-tls-policy-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      dw_conf_footer
    ) >$postfix_smtp_tls_policy_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix smtp_tls_policy_maps File $postfix_smtp_tls_policy_maps ..." 1
  write_postfix_smtp_tls_policy_maps
  postmap $postfix_smtp_tls_policy_maps
}

#----------------------------------------------------------------------------------------
# Postfix postfix_client_access_maps $postfix_client_access_maps
#----------------------------------------------------------------------------------------

create_postfix_client_access_maps() {
  write_postfix_client_access_maps() {
    #:>$postfix_client_access_maps
    (
      dw_conf_line
      echo "# $postfix_client_access_maps - Postfix postfix-client-access-maps File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      dw_conf_footer
    ) >$postfix_client_access_maps
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix client_access_maps File $postfix_client_access_maps ..." 1
  write_postfix_client_access_maps
  postmap $postfix_client_access_maps
}

#----------------------------------------------------------------------------------------
# Postfix postscreen_access $postfix_postscreen_access
#----------------------------------------------------------------------------------------

check_postfix_postscreen_access() {
  write_postfix_postscreen_access() {
    dw_echo_colmsg "==> Create Postfix postfix_postscreen_access File $postfix_postscreen_access ..." 2
    : >$postfix_postscreen_access
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix postfix_postscreen_access File $postfix_postscreen_access ..." 1
  if [ ! -f $postfix_postscreen_access ]; then
    write_postfix_postscreen_access
  fi
}

#----------------------------------------------------------------------------------------
# Postfix submission_header_cleanup etc/postfix/submission_header_cleanup
#----------------------------------------------------------------------------------------

create_postfix_submission_header_cleanup() {
  write_postfix_submission_header_cleanup() {
    (
      dw_conf_line
      echo "# $postfix_submission_header_cleanup - Postfix submission-header-cleanup File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "### Entfernt Datenschutz-relevante Header aus E-Mails von MTUAs"
      echo
      echo "/^Received:/            IGNORE"
      echo "/^X-Originating-IP:/    IGNORE"
      echo "/^X-Mailer:/            IGNORE"
      echo "/^User-Agent:/          IGNORE"
      echo
      dw_conf_footer
    ) >$postfix_submission_header_cleanup
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Postfix submission_header_cleanup File $postfix_submission_header_cleanup ..." 1
  write_postfix_submission_header_cleanup
}

#===============================================================================
# Postfix End
#===============================================================================

#===============================================================================
# Dovecot Begin
#===============================================================================

#----------------------------------------------------------------------------------------
# Dovecot Configuration File
#----------------------------------------------------------------------------------------
create_dovecot_config_file() {
  write_dovecot_config_file() {
    (
      dw_conf_line
      echo "# $dovecot_config_file - Dovecot Config File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo "###"
      echo "### Aktivierte Protokolle"
      echo "#############################"
      echo
      echo "protocols = imap pop3 lmtp sieve"
      echo
      echo "###"
      echo "### TLS Config"
      echo "#######################"
      echo
      echo "ssl = required"
      #ssl_cert = </etc/letsencrypt/live/mail.mysystems.tld/fullchain.pem
      #ssl_key = </etc/letsencrypt/live/mail.mysystems.tld/privkey.pem
      #echo "ssl_cert = /etc/dovecot/private/mycert.pem"
      #echo "ssl_key = /etc/dovecot/private/mykey.key"
      echo "ssl_key = <$mail_ssl_key"
      echo "ssl_cert = <$mail_ssl_cert"
      echo "ssl_dh = <$dovecot_dhpem_file"
      echo "ssl_cipher_list = EDH+CAMELLIA:EDH+aRSA:EECDH+aRSA+AESGCM:EECDH+aRSA+SHA256:EECDH:+CAMELLIA128:+AES128:+SSLv3:!aNULL:!eNULL:!LOW:!3DES:!MD5:!EXP:!PSK:!DSS:!RC4:!SEED:!IDEA:!ECDSA:kEDH:CAMELLIA128-SHA:AES128-SHA"
      echo "ssl_prefer_server_ciphers = yes"
      echo
      echo "###"
      echo "### Dovecot services"
      echo "################################"
      echo
      echo "service imap-login {"
      echo "    inet_listener imap {"
      echo "        port = 143"
      echo "    }"
      echo "}"
      echo
      echo "service managesieve-login {"
      echo "    inet_listener sieve {"
      echo "        port = 4190"
      echo "    }"
      echo "}"
      echo
      echo "service lmtp {"
      echo "    unix_listener /var/spool/postfix/private/dovecot-lmtp {"
      echo "        mode = 0660"
      echo "        group = postfix"
      echo "        user = postfix"
      echo "    }"
      echo
      echo "   user = vmail"
      echo "}"
      echo
      echo "service auth {"
      echo "    ### Auth socket für Postfix"
      echo "    unix_listener /var/spool/postfix/private/auth {"
      echo "        mode = 0660"
      echo "        user = postfix"
      echo "        group = postfix"
      echo "    }"
      echo
      echo "    ### Auth socket für LMTP-Dienst"
      echo "    unix_listener auth-userdb {"
      echo "        mode = 0660"
      echo "        user = vmail"
      echo "        group = vmail"
      echo "    }"
      echo "}"
      echo
      echo "###"
      echo "###  Protocol settings"
      echo "#############################"
      echo
      echo "### Test Fetchmail Sieve Archive"
      echo "protocol lda {"
      echo '    mail_plugins = $mail_plugins sieve'
      echo "}"
      echo
      echo "protocol imap {"
      echo '    mail_plugins = $mail_plugins quota imap_quota imap_sieve'
      echo "    mail_max_userip_connections = 20"
      echo "    imap_idle_notify_interval = 29 mins"
      echo "}"
      echo
      echo "protocol pop3 {"
      echo "    mail_max_userip_connections = 20"
      echo "}"
      echo
      echo "protocol lmtp {"
      if [ -z "$MAIL_POSTMASTER" ]; then
        MAIL_POSTMASTER="root"
      fi
      echo "    postmaster_address = $MAIL_POSTMASTER"
      echo '    mail_plugins = $mail_plugins sieve'
      echo "}"
      echo
      echo "###"
      echo "### Client authentication"
      echo "#############################"
      echo
      #echo "auth_verbose = yes"
      echo "disable_plaintext_auth = yes"
      echo "auth_mechanisms = plain login"
      echo
      echo "passdb {"
      #    driver = sql
      #    args = /etc/dovecot/dovecot-sql.conf
      echo "    driver = passwd-file"
      #echo "    args = username_format=%n $dovecot_passwd_file"
      echo "    args = username_format=%u $dovecot_passwd_file"
      echo "}"
      echo
      echo "userdb {"
      #    driver = sql
      #    args = /etc/dovecot/dovecot-sql.conf
      echo "    driver = static"
      #echo "    args = uid=vmail gid=vmail home=/var/vmail/mailboxes/%d/%n"
      echo "    args = uid=vmail gid=vmail home=$DATA_DIR/vmail/mailboxes/%d/%n"
      echo "}"
      echo
      echo "###"
      echo "### Mail location"
      echo "#######################"
      echo
      echo "mail_uid = vmail"
      echo "mail_gid = vmail"
      echo "mail_privileged_group = vmail"
      echo
      #echo "mail_home = /var/vmail/mailboxes/%d/%n"
      echo "mail_home = $DATA_DIR/vmail/mailboxes/%d/%n"
      # Maildir
      echo "mail_location = maildir:~/mail:LAYOUT=fs"
      # Dbox
      #echo "mail_location = sdbox:~/dbox"
      echo
      echo "###"
      echo "### Mailbox configuration"
      echo "########################################"
      echo
      echo "namespace inbox {"
      echo "    inbox = yes"
      echo
      echo "    mailbox Spam {"
      echo "        auto = subscribe"
      echo "        special_use = \Junk"
      echo "    }"
      echo
      #echo "    mailbox Flagged {"
      #echo "        auto = subscribe"
      #echo "        special_use = \Flagged"
      #echo "    }"
      #echo
      #echo "    mailbox Archive {"
      #echo "        auto = subscribe"
      #echo "        special_use = \Archive"
      #echo "    }"
      #echo
      echo "    mailbox Trash {"
      echo "        auto = subscribe"
      echo "        special_use = \Trash"
      echo "    }"
      echo
      echo "    mailbox Drafts {"
      echo "        auto = subscribe"
      echo "        special_use = \Drafts"
      echo "    }"
      echo
      echo "    mailbox Sent {"
      echo "        auto = subscribe"
      echo "        special_use = \Sent"
      echo "    }"
      echo "}"
      echo
      echo "###"
      echo "### Mail plugins"
      echo "############################"
      echo
      echo "plugin {"
      echo "    sieve_plugins = sieve_imapsieve sieve_extprograms"
      echo "    sieve_before = /var/vmail/sieve/global/spam-global.sieve"
      echo "    sieve = file:/var/vmail/sieve/%d/%n/scripts;active=/var/vmail/sieve/%d/%n/active-script.sieve"
      echo
      #Test
      echo "    sieve_global = /var/vmail/sieve/global/"
      echo
      #echo "    ### Spam learning"
      #echo "    ###"
      #echo "    # From elsewhere to Spam folder"
      #echo "    imapsieve_mailbox1_name = Spam"
      #echo "    imapsieve_mailbox1_causes = APPEND COPY"
      #echo "    imapsieve_mailbox1_before = file:/var/vmail/sieve/global/learn-spam.sieve"
      #echo
      #echo "    # From Spam folder to elsewhere"
      #echo "    imapsieve_mailbox2_name = *"
      #echo "    imapsieve_mailbox2_from = Spam"
      #echo "    imapsieve_mailbox2_causes = COPY"
      #echo "    imapsieve_mailbox2_before = file:/var/vmail/sieve/global/learn-ham.sieve"
      #echo
      echo "    sieve_pipe_bin_dir = /usr/bin"
      echo "    sieve_global_extensions = +vnd.dovecot.pipe"
      echo
      # Maildir
      echo "    quota = maildir:User quota"
      # Dbox
      #echo "    quota = count:User quota"
      #echo "    quota_vsizes=yes"
      # Dbox
      echo "    quota_exceeded_message = Benutzer %u hat das Speichervolumen überschritten."
      #echo "    quota_exceeded_message = Benutzer %u hat das Speichervolumen überschritten. / User %u has exhausted allowed storage space."
      echo "}"
      echo
      echo "###"
      echo "### Log Debug Settings"
      echo "############################"
      echo
      echo "log_path = /var/log/dovecot.log"
      if dw_conf_var_is_yes "$MAIL_DEBUG"; then
        mail_debug='yes'
      else
        mail_debug='no'
      fi
      echo "auth_verbose = $mail_debug"
      echo "auth_verbose_passwords = $mail_debug"
      echo "auth_debug = $mail_debug"
      echo "auth_debug_passwords = $mail_debug"
      echo "mail_debug = $mail_debug"
      echo "verbose_ssl = $mail_debug"
      echo
      echo "### Dovecot Deliver autocreate und autosubscribes"
      echo "############################"
      echo
      echo "lda_mailbox_autocreate = yes"
      echo "lda_mailbox_autosubscribe = yes"
      echo
      dw_conf_footer
    ) >$dovecot_config_file
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Dovecot Config File $dovecot_config_file ..." 1
  write_dovecot_config_file
}

#----------------------------------------------------------------------------------------
# Dovecot Password File
#----------------------------------------------------------------------------------------
create_dovecot_passwd_file() {
  write_dovecot_passwd_file() {
    (
      dw_conf_line
      echo "# $dovecot_passwd_file - Dovecot Password File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-mailserver.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Configuration'"
      echo "#"
      echo "# in dwsetup > Services > Mail-Server !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
    ) >$dovecot_passwd_file
    idx=1
    while [ $idx -le $MAIL_USER_N ]; do
      eval user_name='$MAIL_USER_'$idx'_NAME'
      if dw_conf_var_is_enabled "$user_name"; then
        eval user_pwd='$MAIL_USER_'$idx'_PWD'
        user_pwd_crypted=''
        if [ -n "$user_pwd" ]; then
          user_pwd_crypted=$(doveadm pw -s SHA512-CRYPT -p $user_pwd)
        fi
        eval user_quota='$MAIL_USER_'$idx'_QUOTA'
        if [ -n "$user_quota" ]; then
          eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
          if [ -n "$mail_user_domain" ]; then
            for domain in $mail_user_domain; do
              if dw_conf_var_is_enabled "$domain"; then
                echo "$user_name@$domain:$user_pwd_crypted::::::userdb_quota_rule=*:storage=$user_quota" >>$dovecot_passwd_file
              fi
            done
          else
            echo "$user_name@$MAIL_DOMAIN:$user_pwd_crypted::::::userdb_quota_rule=*:storage=$user_quota" >>$dovecot_passwd_file
          fi
        else
          eval mail_user_domain='$MAIL_USER_'$idx'_DOMAIN'
          if [ -n "$mail_user_domain" ]; then
            for domain in $mail_user_domain; do
              if dw_conf_var_is_enabled "$domain"; then
                echo "$user_name@$domain:$user_pwd_crypted:::::::" >>$dovecot_passwd_file
              fi
            done
          else
            echo "$user_name@$MAIL_DOMAIN:$user_pwd_crypted:::::::" >>$dovecot_passwd_file
          fi
        fi
        #joe:{PLAIN}pass::::::userdb_quota_rule=*:storage=100M
      else
        dw_echo_colmsg "==> INFO: User MAIL_USER_$idx is disabled !" 2 n
      fi
      idx=$(expr $idx + 1)
    done
    echo >>$dovecot_passwd_file
    (
      echo
      dw_conf_footer
    ) >>$dovecot_passwd_file
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Dovecot Password File $dovecot_passwd_file ..." 1
  write_dovecot_passwd_file
}

#----------------------------------------------------------------------------------------
# Dovecot PEM File
#----------------------------------------------------------------------------------------
check_dovecot_dhpem_file() {
  dw_echo_colmsg "==> Check Dovecot dhpem File $dovecot_dhpem_file ..." 1
  if [ -f $dovecot_dhpem_file ]; then
    dw_echo_colmsg "==> OK Found, nothing do to ..." 2 o
  else
    dw_echo_colmsg "==> Fail Not Found, generate new ..." 2 n
    openssl dhparam -out $dovecot_dhpem_file 2048
  fi
}

#----------------------------------------------------------------------------------------
# Dovecot Logrotate File
#----------------------------------------------------------------------------------------

write_dovecot_logrotate() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Dovecot Logrotate Configuration File $dovecot_logrotate ..." 1
  (
    dw_conf_line
    echo "# $dovecot_logrotate - Dovecot Logrotate File"
    echo "#"
    echo "# This file is automatically generated by /var/dwsetup/config.d/mail.sh"
    echo "#"
    echo "# Do not edit this file, use"
    echo "#"
    echo "# 'Edit Base Configuration'"
    echo "#"
    echo "# in dwsetup > Services > Mail-Server !"
    echo "#"
    dw_conf_date "# Creation date:"
    dw_conf_line
    echo
    echo "/var/log/dovecot*.log {"
    echo "    daily"
    echo "    missingok"
    echo "    rotate 7"
    echo "    compress"
    echo "    delaycompress"
    echo "    notifempty"
    echo "    sharedscripts"
    echo "    postrotate"
    echo "      /usr/sbin/doveadm log reopen"
    echo "    endscript"
    echo "    create"
    echo "}"
    echo
    dw_conf_footer
    echo
  ) >$dovecot_logrotate
  dw_add_pkg_files "$pkg_name" "$dovecot_logrotate"
}

#===============================================================================
# Dovecot End
#===============================================================================

#===============================================================================
# Sieve Begin
#===============================================================================

#-------------------------------------------------------------------------------
# Create Sieve sieve_spam_global_file /var/vmail/sieve/global/spam-global.sieve
#-------------------------------------------------------------------------------
create_sieve_spam_global_file() {
  dw_echo_colmsg "==> Create Sieve Configuration File $sieve_spam_global_file ..." 1
  if [ ! -d "$sieve_spam_global_dir" ]; then
    mkdir -p "$sieve_spam_global_dir"
    chmod 0770 "$sieve_spam_global_dir"
    chown -R vmail:vmail "$sieve_base_dir"
  fi
  (
    echo 'require ["copy", "fileinto", "envelope"];'
    echo
    echo 'if not envelope :domain "From" "'$MAIL_DOMAIN_SIEVE'" {'
    echo '  if header :contains "X-Spam-Flag" "YES" {'
    echo '      fileinto "Spam";'
    echo '  }'
    echo
    echo '  if header :is "X-Spam" "Yes" {'
    echo '      fileinto "Spam";'
    echo '  }'
    echo '}'
  ) >$sieve_spam_global_file
  chmod 0644 $sieve_spam_global_file
  chown vmail:vmail "$sieve_spam_global_file"
}

#===============================================================================
# Sieve End
#===============================================================================

#===============================================================================
# s-nail Begin
#===============================================================================

#-------------------------------------------------------------------------------
# Create s-nail Symlinks
#-------------------------------------------------------------------------------
create_snail_links() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create S-Nail Links ..." 1
  ln -sf "/usr/bin/s-nail" "/usr/bin/mailx"
  ln -sf "/usr/bin/s-nail" "/usr/bin/mail"
  ln -sf "/usr/share/man/man1/s-nail.1.gz" "/usr/share/man/man1/mail.1.gz"
  ln -sf "/usr/share/man/man1/s-nail.1.gz" "/usr/share/man/man1/mailx.1.gz"
}

#-------------------------------------------------------------------------------
# Remove s-nail Symlinks
#-------------------------------------------------------------------------------
remove_snail_links() {
  remove_link() {
    if [ -L "$1" ]; then
      rm "$1"
    fi
  }
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Remove S-Nail Links ..." 1
  remove_link "/usr/bin/mailx"
  remove_link "/usr/bin/mail"
  remove_link "/usr/share/man/man1/mail.1.gz"
  remove_link "/usr/share/man/man1/mailx.1.gz"
}

#===============================================================================
# s-nail End
#===============================================================================

#===============================================================================
# Opendkim Begin
#===============================================================================

#-------------------------------------------------------------------------------
# Create Opendkim default File
#-------------------------------------------------------------------------------
create_opendkim_default_file() {
  dw_echo_colmsg "==> Create Opendkim Configuration File $opendkim_default_file ..." 1
  (
    echo "RUNDIR=/run/opendkim"
  ) >"$opendkim_default_file"
  chmod 0644 "$opendkim_default_file"
  chown opendkim:opendkim "$opendkim_default_file"
}

#-------------------------------------------------------------------------------
# Create Opendkim config File
#-------------------------------------------------------------------------------
create_opendkim_config_file() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Opendkim Configuration File $opendkim_config_file ..." 1
  (
# OpenDKIM agiert als Mail Filter (= Milter) in den
# Modi signer (s) und verifier (v) und verwendet eine
# Socket-Datei zur Kommunikation (alternativ: lokaler Port)
    echo "Mode                    sv"
# Socket                  local:/var/run/opendkim/opendkim.sock
    echo "Socket                  inet:12345@localhost"
# OpenDKIM verwendet diesen Benutzer bzw.
# diese Gruppe
    echo "UserID                  opendkim:opendkim"
    echo "UMask                   002"
    echo "PidFile                 /var/run/opendkim/opendkim.pid"
# OpenDKIM bei Problemen neustarten,
# aber max. 10 mal pro Stunde
    echo "AutoRestart             yes"
    echo "AutoRestartRate         10/1h"
# Logging (wenn alles funktioniert eventuell reduzieren)
    echo "Syslog                  yes"
    echo "SyslogSuccess           yes"
    echo "LogWhy                  yes"
# Verfahren, wie Header und Body durch
# OpenDKIM verarbeitet werden sollen.
    echo "Canonicalization        relaxed/simple"
# interne Mails (signieren, nicht verifizieren)
    echo "InternalHosts           refile:$opendkim_config_dir/trusted"
# Hosts, denen vertraut wird (vermeidet Warnungen beim Logging)
    echo "ExternalIgnoreList      refile:$opendkim_config_dir/trusted"
# welche Verschlüsselungs-Keys sollen für welche
# Domains verwendet werden
# (refile: für Dateien mit regulären Ausdrücke)
    echo "SigningTable            refile:$opendkim_config_dir/signing.table"
    echo "KeyTable                $opendkim_config_dir/key.table"
# diesen Signatur-Algorithmus verwenden
    echo "SignatureAlgorithm      rsa-sha256"
# Always oversign From (sign using actual From and a null From to prevent
# malicious signatures header fields (From and/or others) between the signer
# and the verifier.  From is oversigned by default in the Debian pacakge
# because it is often the identity key used by reputation systems and thus
# somewhat security sensitive.
    echo "OversignHeaders         From"
  ) >"$opendkim_config_file"
  chmod 0644 "$opendkim_config_file"
  dw_add_pkg_files "$pkg_name" "$opendkim_config_file"
}

#-------------------------------------------------------------------------------
# Create Opendkim trusted File
#-------------------------------------------------------------------------------
create_opendkim_config_file_trusted() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Opendkim Configuration File $opendkim_config_file_trusted ..." 1
  (
    echo "127.0.0.1"
    echo "::1"
    echo "localhost"
    echo "${MAIL_DOMAIN}"
    echo ".${MAIL_DOMAIN}"
  ) >"$opendkim_config_file_trusted"
  chmod 0644 "$opendkim_config_file_trusted"
  chown opendkim:opendkim "$opendkim_config_file_trusted"
  dw_add_pkg_files "$pkg_name" "$opendkim_config_file_trusted"
}

#-------------------------------------------------------------------------------
# Create Opendkim signing.table File
#-------------------------------------------------------------------------------
create_opendkim_config_file_signing_table() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Opendkim Configuration File $opendkim_config_file_signing_table ..." 1
  (
    echo "*@${MAIL_DOMAIN} $opendkim_dkim_selektor"
    echo "*@*.${MAIL_DOMAIN} $opendkim_dkim_selektor"
  ) >"$opendkim_config_file_signing_table"
  chmod 0644 "$opendkim_config_file_signing_table"
  chown opendkim:opendkim "$opendkim_config_file_signing_table"
  dw_add_pkg_files "$pkg_name" "$opendkim_config_file_signing_table"
}

#-------------------------------------------------------------------------------
# Create Opendkim key.table File
#-------------------------------------------------------------------------------
create_opendkim_config_file_key_table() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Opendkim Configuration File $opendkim_config_file_key_table ..." 1
  (
    echo "$opendkim_dkim_selektor ${MAIL_DOMAIN}:$opendkim_dkim_selektor:$opendkim_keys_dir/$opendkim_dkim_selektor.private"
  ) >"$opendkim_config_file_key_table"
  chmod 0644 "$opendkim_config_file_key_table"
  chown opendkim:opendkim "$opendkim_config_file_key_table"
  dw_add_pkg_files "$pkg_name" "$opendkim_config_file_key_table"
}

#-------------------------------------------------------------------------------
# Check Opendkim Key
#-------------------------------------------------------------------------------
check_opendkim_key() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Opendkim Key in $opendkim_keys_dir ..." 1
  if [ ! -f "$opendkim_keys_dir/$opendkim_dkim_selektor.private" ] || [ ! -f "$opendkim_keys_dir/$opendkim_dkim_selektor.txt" ]; then
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create New Opendkim Key in $opendkim_keys_dir ..." 2
    rm -f "$opendkim_keys_dir"/*.private
    rm -f "$opendkim_keys_dir"/*.txt
    opendkim-genkey -D "$opendkim_keys_dir" -d "${MAIL_DOMAIN}" -b 2048 -r -s "$opendkim_dkim_selektor"
  else
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK Found, nothing do to ..." 2 o
  fi
}

#----------------------------------------------------------------------------------------
# Check owner/rights of Opendkim directory
#----------------------------------------------------------------------------------------
check_opendkim_directory_owner_rights() {
  chown -R opendkim:opendkim "$opendkim_config_dir"
  chown -R opendkim:opendkim "$opendkim_keys_dir"
  chmod -R go-rwx "$opendkim_keys_dir"
}

#===============================================================================
# Opendkim End
#===============================================================================

#----------------------------------------------------------------------------------------
# Show DNS Entrys
#----------------------------------------------------------------------------------------
show_dns_entry() {
  dw_echo_colmsg "Recommended DNS Entrys:" 0 i
  dw_echo_colmsg "$MAIL_DOMAIN. 86400 IN MX 10 ${MAIL_HOSTNAME}.${MAIL_DOMAIN}." 1
  dw_echo_colmsg "$MAIL_DOMAIN. 3600 IN TXT v=spf1 a:${MAIL_HOSTNAME}.${MAIL_DOMAIN} ~all" 1
  dw_echo_colmsg "_dmarc.$MAIL_DOMAIN. 3600 IN TXT v=DMARC1;p=reject;" 1
  local dkim=$(cat $opendkim_keys_dir/$opendkim_dkim_selektor.txt)
  dw_echo_colmsg "$(echo $dkim | sed 's/_domainkey.*IN.*TXT/_domainkey.'$MAIL_DOMAIN' 3600 IN TXT/')" 1
  echo
  if dw_conf_var_is_enabled "$MAIL_RELAYHOST" && [ -n "$MAIL_RELAYHOST" ]; then
    dw_echo_colmsg "==> Mail Relayhost is enabled, No DNS Entries necessary ..." 0 a
    echo
  fi
  dw_echo_colmsg "==> Check MX Record for ${MAIL_HOSTNAME}.${MAIL_DOMAIN} ..."
  local result=$(dig ${MAIL_DOMAIN} IN MX | grep ${MAIL_HOSTNAME}.${MAIL_DOMAIN})
  if [ -n "$result" ]; then
    dw_echo_colmsg "$result" 1
    dw_echo_colmsg "==> OK MX Record found ..." 1 o
  else
    dw_echo_colmsg "==> ERROR MX Record NOT found ..." 1 e
  fi
  dw_echo_colmsg "==> Check SPF Record for ${MAIL_HOSTNAME}.${MAIL_DOMAIN} ..."
  result=$(dig ${MAIL_DOMAIN} IN TXT | grep spf1)
  if [ -n "$result" ]; then
    dw_echo_colmsg "$result" 1
    dw_echo_colmsg "==> OK SPF Record found ..." 1 o
  else
    dw_echo_colmsg "==> ERROR SPF Record NOT found ..." 1 e
  fi
  dw_echo_colmsg "==> Check DMARC Record for ${MAIL_HOSTNAME}.${MAIL_DOMAIN} ..."
  result=$(dig _dmarc.${MAIL_DOMAIN} IN TXT | grep DMARC1)
  if [ -n "$result" ]; then
    dw_echo_colmsg "$result" 1
    dw_echo_colmsg "==> OK DMARC Record found ..." 1 o
  else
    dw_echo_colmsg "==> ERROR DMARC Record NOT found ..." 1 e
  fi
  dw_echo_colmsg "==> Check DKIM Record for ${MAIL_HOSTNAME}.${MAIL_DOMAIN} ..."
  result=$(dig ${opendkim_dkim_selektor}._domainkey.${MAIL_DOMAIN} IN TXT | grep DKIM1)
  if [ -n "$result" ]; then
    dw_echo_colmsg "$result" 1
    dw_echo_colmsg "==> OK DKIM Record found ..." 1 o
  else
    dw_echo_colmsg "==> ERROR DKIM Record NOT found ..." 1 e
  fi
  dw_echo_colmsg "==> Check Reverse DNS Entry for ${MAIL_HOSTNAME}.${MAIL_DOMAIN} ..."
  local mail_ip=$(host ${MAIL_HOSTNAME}.${MAIL_DOMAIN} | cut -d ' ' -f 4)
  local mail_reverse=''
  if [ -n "$mail_ip" ]; then
    mail_reverse=$(host $mail_ip | cut -d ' ' -f 5)
  fi
  if [ -n "$mail_reverse" ] && [ "$mail_reverse" = "${MAIL_HOSTNAME}.${MAIL_DOMAIN}" ]; then
    dw_echo_colmsg "==> OK Reverse DNS Entry for ${MAIL_HOSTNAME}.${MAIL_DOMAIN}. = $mail_reverse found ..." 1 o
  else
    dw_echo_colmsg "==> WARNING Reverse DNS Entry for ${MAIL_HOSTNAME}.${MAIL_DOMAIN}. != $mail_reverse NOT found ..." 1 a
    if dw_conf_var_is_enabled "$MAIL_RELAYHOST"; then
      if dw_conf_var_is_enabled "$MAIL_RELAYHOST" && [ -n "$MAIL_RELAYHOST" ]; then
        dw_echo_colmsg "==> Mail Relayhost $MAIL_RELAYHOST is enabled, maybe no problem ..." 1 n
      fi
    fi
  fi
}

#----------------------------------------------------------------------------------------
# Check Settings
#----------------------------------------------------------------------------------------
check_settings() {
  dw_echo_colmsg "==> Check Outgoing Port 25 ..."
  timeout 1 bash -c 'cat < /dev/null > /dev/tcp/smtp.gmail.com/25'
  if [ $? -ne 0 ]; then
    dw_echo_colmsg "==> WARNING Outgoing Port 25 seems to be closed !!!" 1 a
    if dw_conf_var_is_enabled "$MAIL_RELAYHOST" && [ -n "$MAIL_RELAYHOST" ]; then
      dw_echo_colmsg "==> Mail Relayhost $MAIL_RELAYHOST is enabled, maybe no problem ..." 1 n
    else
      dw_echo_colmsg "==> Enable Mail Relayhost for sending !" 1 a
    fi
  else
    dw_echo_colmsg "==> OK Port Outgoing 25 seems to be open !" 1 o
  fi
  dw_echo_colmsg "==> Check SPF Check ..."
  if dw_conf_var_is_enabled "$SPF_CHECK"; then
    dw_echo_colmsg "==> OK SPF Check is enabled ..." 1 o
  else
    dw_echo_colmsg "==> SPF Check is disabled ..." 1 n
  fi
  dw_echo_colmsg "==> Check DKIM Signing ..."
  if dw_conf_var_is_enabled "$DKIM_SIGNING"; then
    dw_echo_colmsg "==> OK DKIM Signing is enabled ..." 1 o
  else
    dw_echo_colmsg "==> DKIM Signing is disabled ..." 1 n
  fi
  dw_echo_colmsg "==> Check LetsEnCrypt for $MAIL_DOMAIN ..."
  if dw_conf_var_is_enabled "$MAIL_DOMAIN_LETSENCRYPT"; then
    dw_echo_colmsg "==> OK LetsEnCrypt is enabled ..." 1 o
  else
    dw_echo_colmsg "==> LetsEnCrypt is disabled ..." 1 n
  fi
}

#===============================================================================
# Main
#===============================================================================
. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-mailserver.config

## If empty then Set it from hostname
if [ -z "$MAIL_HOSTNAME" ]; then
  MAIL_HOSTNAME=$(hostname)
fi
if [ -z "$MAIL_DOMAIN" ]; then
  MAIL_DOMAIN=$(hostname -d)
fi
if [ -z "$MAIL_DOMAIN_SIEVE" ]; then
  if [ -n "$MAIL_DOMAIN" ]; then
    MAIL_DOMAIN_SIEVE="$MAIL_DOMAIN"
  else
    MAIL_DOMAIN_SIEVE=$(hostname -d)
  fi
fi

if dw_conf_var_is_yes "$MAIL_DOMAIN_LETSENCRYPT" && [ -L /etc/letsencrypt/live/$MAIL_DOMAIN/fullchain.pem ]; then
  mail_ssl_cert="/etc/letsencrypt/live/$MAIL_DOMAIN/fullchain.pem"
  mail_ssl_key="/etc/letsencrypt/live/$MAIL_DOMAIN/privkey.pem"
fi

if [ "$1" == "-quiet" -o "$1" == "quiet" ]; then
  quiet="quiet"
  shift
else
  quiet=''
fi

case "$1" in

showdns)
  show_dns_entry
  ;;
check)
  check_settings
  ;;
remove-snail-links)
  remove_snail_links
  ;;
*)
  check_create_dir $postfix_hash_dir
  create_mailname_file
  create_snail_rc
  create_snail_links
  create_aliases_file
  create_mail_conf_file

  [ "$quiet" = "quiet" ] && dw_echo_colmsg "==> Create Opendkim Configuration ..." 1
  create_opendkim_config_file
  create_opendkim_config_file_trusted
  create_opendkim_config_file_signing_table
  create_opendkim_config_file_key_table
  check_opendkim_key
  check_opendkim_directory_owner_rights

  [ "$quiet" = "quiet" ] && dw_echo_colmsg "==> Create Dovecot Configuration ..." 1
  create_dovecot_config_file
  create_dovecot_passwd_file
  check_dovecot_dhpem_file
  write_dovecot_logrotate

  [ "$quiet" = "quiet" ] && dw_echo_colmsg "==> Create Postfix Configuration ..." 1
  create_postfix_main_cf
  create_postfix_master_cf

  create_postfix_smtp_generic_maps
  create_postfix_recipient_canonical_maps
  create_postfix_virtual_mailbox_domains
  create_postfix_virtual_mailbox_maps
  create_postfix_smtpd_sender_login_maps
  create_postfix_smtpd_recipient_restrictions
  create_postfix_virtual_alias_maps
  create_postfix_sender_canonical_maps
  create_postfix_transport_maps
  create_postfix_smtp_sasl_passwd_maps
  create_postfix_smtp_tls_policy_maps
  create_postfix_client_access_maps
  check_postfix_postscreen_access

  create_postfix_submission_header_cleanup

  create_sieve_spam_global_file
  check_vmail_data_dir
  check_vmail_sieve_dir
  ;;
esac

#===============================================================================
# End
#===============================================================================
exit 0
