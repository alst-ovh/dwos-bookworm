#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-diskbackup.update.sh - Update or Generate New Disk-Backup Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  22.06.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-diskbackup.config'
config_header='/var/dwsetup/header/dw-diskbackup.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Settings for Disk-Backup"
    dw_conf_line
    echo
    dw_conf_var "NOTIFY_MAIL"
    dw_conf_comment "# Send Mail yes or no"
    echo
    dw_conf_var "NOTIFY_TELEGRAM"
    dw_conf_comment "# Send Telegram Message yes or no"
    echo
    dw_conf_var "BACKUP_BEEP"
    dw_conf_comment "# Beep on Backup Start and End yes or no"
    echo
    dw_conf_var "BACKUP_CHECK_HDMINFREE"
    dw_conf_comment "# Check for enough Space on Backup Disk yes or no"
    dw_conf_var "BACKUP_HDMINFREE"
    dw_conf_comment "# Min Space in Percent"
    echo
    dw_conf_var "BACKUP_DELETE_BEFORE"
    dw_conf_comment "# Delete Before yes or no"
    echo
    dw_conf_line
    echo "# Rsync Settings for Disk-Backup"
    dw_conf_line
    echo
    dw_conf_var "BACKUP_RSYNC_TIMEOUT"
    dw_conf_comment "# Timeout from Rsync in Seconds, 0 Disable it"
    dw_conf_var "BACKUP_RSYNC_BWLIMIT"
    dw_conf_comment "# Limit the Bandwith KByte/Sec, leave empty or 0 for none"
    echo
    dw_conf_line
    echo "# Disk-Backup Exclude Settings for Backup"
    echo "#"
    echo "# (Prefix a Exclude in BACKUP_x_EXCLUDE with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "BACKUP_EXCLUDE_N"
    dw_conf_comment "# Number of Exludes"
    if [ $BACKUP_EXCLUDE_N -eq 0 ]
    then
      imax=1
    else
      imax=$BACKUP_EXCLUDE_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval backup_exclude='$BACKUP_EXCLUDE_'$idx
      echo "BACKUP_EXCLUDE_"$idx"=""'$backup_exclude'"
      idx=$(expr $idx + 1)
    done
    echo
    dw_conf_line
    echo "# Disk-Backup Auto Settings for Backup"
    echo "#"
    echo "# (Prefix a UUID in BACKUP_AUTO_UUID_x with a ! to Disable it)"
    dw_conf_line
    echo
    echo "BACKUP_AUTO='$BACKUP_AUTO'"
    dw_conf_comment "# Auto Backup yes or no"
    echo
    echo "BACKUP_AUTO_UUID_N='$BACKUP_AUTO_UUID_N'"
    if [ $BACKUP_AUTO_UUID_N -eq 0 ]
    then
      imax=1
    else
      imax=$BACKUP_AUTO_UUID_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval backup_auto_uuid='$BACKUP_AUTO_UUID_'$idx
      echo "BACKUP_AUTO_UUID_"$idx"=""'$backup_auto_uuid'"
      idx=$(expr $idx + 1)
    done
    dw_conf_footer e
  ) >> $generate_conf

  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
