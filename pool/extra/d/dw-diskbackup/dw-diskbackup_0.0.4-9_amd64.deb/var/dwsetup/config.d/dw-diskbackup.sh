#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-diskbackup.sh - Configuration Generator Script for Disk-Backup
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  22.06.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-diskbackup'
dwdiskbackup_conf_dir='/etc/dw-diskbackup'
dwdiskbackup_conf_file="$dwdiskbackup_conf_dir/dw-diskbackup.conf"
dwdiskbackup_exclude_file="$dwdiskbackup_conf_dir/dw-diskbackup-exclude"
dwdiskbackup_auto_uuid_file="$dwdiskbackup_conf_dir/dw-diskbackup-auto-uuid"

#----------------------------------------------------------------------------------------
# Create Disk-Backup Configuration File
#----------------------------------------------------------------------------------------
create_dwdiskbackup_conf_file ()
{
  dw_echo_colmsg "==> Create Disk-Backup Config File $dwdiskbackup_conf_file ..." 1
  (
    dw_conf_var "NOTIFY_MAIL"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    dw_conf_var "NOTIFY_TELEGRAM"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    dw_conf_var "BACKUP_BEEP"
    echo
    dw_conf_var "BACKUP_CHECK_HDMINFREE"
    dw_conf_var "BACKUP_HDMINFREE"
    echo
    dw_conf_var "BACKUP_DELETE_BEFORE"
    echo
    dw_conf_var "BACKUP_RSYNC_TIMEOUT"
    dw_conf_var "BACKUP_RSYNC_BWLIMIT"
    echo
    dw_conf_var "BACKUP_AUTO"
  ) > $dwdiskbackup_conf_file
  dw_add_pkg_files "$pkg_name" "$dwdiskbackup_conf_file"
}

#----------------------------------------------------------------------------------------
# Create Disk-Backup Exclude File
#----------------------------------------------------------------------------------------
create_dwdiskbackup_exclude_file ()
{
  dw_echo_colmsg "==> Create Exclude File $dwdiskbackup_exclude_file" 1
  :> $dwdiskbackup_exclude_file
  chmod 0644 $dwdiskbackup_exclude_file
  dw_add_pkg_files "$pkg_name" "$dwdiskbackup_exclude_file"
  idx='1'
  eval exclude_n='$BACKUP_EXCLUDE_N'
  while [ "$idx" -le "$exclude_n" ]
  do
    eval exclude='$BACKUP_EXCLUDE_'$idx
    if dw_conf_var_is_enabled "$exclude";then
      echo "$exclude" >> $dwdiskbackup_exclude_file
    else
      exclude_disabled='BACKUP_EXCLUDE_'$idx
      dw_echo_colmsg "==> INFO: Exclude $exclude_disabled is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#----------------------------------------------------------------------------------------
# Check Disk-Backup Auto Backup enabled
#----------------------------------------------------------------------------------------
check_dwdiskbackup_auto_enabled ()
{
  if dw_conf_var_is_yes "$BACKUP_AUTO"; then
    dw_echo_colmsg "==> INFO: Disk-Backup Auto Backup is enabled !" 1 a
  else
    dw_echo_colmsg "==> INFO: Disk-Backup Auto Backup is disabled !" 1 n
  fi
}

#----------------------------------------------------------------------------------------
# Create Disk-Backup Auto UUID File
#----------------------------------------------------------------------------------------
create_dwdiskbackup_auto_uuid_file ()
{
  dw_echo_colmsg "==> Create Auto UUID File ${dwdiskbackup_auto_uuid_file}" 1
  :> ${dwdiskbackup_auto_uuid_file}
  chmod 0644 ${dwdiskbackup_auto_uuid_file}
  idx='1'
  eval auto_uuid_n='$BACKUP_AUTO_UUID_N'
  while [ "$idx" -le "$auto_uuid_n" ]
  do
    eval auto_uuid='$BACKUP_AUTO_UUID_'$idx
    if dw_conf_var_is_enabled "$auto_uuid"; then
      echo "$auto_uuid" >> ${dwdiskbackup_auto_uuid_file}
    else
      auto_uuid_disabled='BACKUP_AUTO_UUID_'$idx
      dw_echo_colmsg "==> INFO: Auto UUID $auto_uuid_disabled is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-base.config
. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-diskbackup.config

create_dwdiskbackup_conf_file
create_dwdiskbackup_auto_uuid_file
create_dwdiskbackup_exclude_file
check_dwdiskbackup_auto_enabled

#===============================================================================
# End
#===============================================================================
exit 0
