#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-hdsentinel.sh - Configuration Generator Script for HDSentinel
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-hdsentinel'
dwhdsentinel_conf_dir='/etc/dw-hdsentinel'
dwhdsentinel_conf_file="$dwhdsentinel_conf_dir/dw-hdsentinel.conf"

dwhdsentinel_cron_file_daily_web='/etc/cron.daily/hdsentinel-web'
dwhdsentinel_cron_file_daily='/etc/cron.daily/hdsentinel'
dwhdsentinel_cron_file_weekly='/etc/cron.weekly/hdsentinel'
dwhdsentinel_cron_file_monthly='/etc/cron.monthly/hdsentinel'

#----------------------------------------------------------------------------------------
# Create HDSentinel Configuration File
#----------------------------------------------------------------------------------------
create_dwhdsentinel_conf_file() {
  if [ ! -d $dwhdsentinel_conf_dir ]; then
    mkdir -p $dwhdsentinel_conf_dir
  fi
  dw_echo_colmsg "==> Create HDSentinel Config File $dwhdsentinel_conf_file ..." 1
  (
    echo "NOTIFY_MAIL='$NOTIFY_MAIL'"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    echo "NOTIFY_TELEGRAM='$NOTIFY_TELEGRAM'"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    echo "HDS_CRON_DAILY_WEB='$HDS_CRON_DAILY_WEB'"
    echo
    echo "HDS_CRON_DAILY='$HDS_CRON_DAILY'"
    echo
    echo "HDS_CRON_WEEKLY='$HDS_CRON_WEEKLY'"
    echo
    echo "HDS_CRON_MONTHLY='$HDS_CRON_MONTHLY'"
  ) >$dwhdsentinel_conf_file
  dw_add_pkg_files "$pkg_name" "$dwhdsentinel_conf_file"
}

#----------------------------------------------------------------------------------------
# Create HDSentinel Cron Files
#----------------------------------------------------------------------------------------
check_dwhdsentinel_cron_files() {
  dw_echo_colmsg "==> Check HDSentinel Cron Files ..." 2
  remove_cron_file='no'

  if [ "$HDS_CRON_DAILY_WEB" = "yes" ]; then
    dw_echo_colmsg "==> Cron Daily Web Enabled, create HDSentinel Cron File $dwhdsentinel_cron_file_daily_web ..." 3
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      echo "/sbin/dwhdsentinel web >/dev/null"
    ) >$dwhdsentinel_cron_file_daily_web
    chmod 0744 $dwhdsentinel_cron_file_daily_web
    dw_add_pkg_files "$pkg_name" "$dwhdsentinel_cron_file_daily_web"
    remove_cron_file='no'
  else
    remove_cron_file='yes'
  fi

  if [ "$remove_cron_file" = 'yes' ]; then
    dw_echo_colmsg "==> Cron Daily Web Disabled, remove HDSentinel Cron File $dwhdsentinel_cron_file_daily_web ..." 3
    rm -f $dwhdsentinel_cron_file_daily_web
  fi

  if [ "$HDS_CRON_DAILY" = "yes" ]; then
    dw_echo_colmsg "==> Cron Daily Enabled, create HDSentinel Cron File $dwhdsentinel_cron_file_daily ..." 3
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      echo "/sbin/dwhdsentinel notify >/dev/null"
    ) >$dwhdsentinel_cron_file_daily
    chmod 0744 $dwhdsentinel_cron_file_daily
    dw_add_pkg_files "$pkg_name" "$dwhdsentinel_cron_file_daily"
    remove_cron_file='no'
  else
    remove_cron_file='yes'
  fi

  if [ "$remove_cron_file" = 'yes' ]; then
    dw_echo_colmsg "==> Cron Daily Disabled, remove HDSentinel Cron File $dwhdsentinel_cron_file_daily ..." 3
    rm -f $dwhdsentinel_cron_file_daily
  fi

  if [ "$HDS_CRON_WEEKLY" = "yes" ]; then
    dw_echo_colmsg "==> Cron Weekly Enabled, create HDSentinel Cron File $dwhdsentinel_cron_file_weekly ..." 3
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      echo "/sbin/dwhdsentinel notify >/dev/null"
    ) >$dwhdsentinel_cron_file_weekly
    chmod 0744 $dwhdsentinel_cron_file_weekly
    dw_add_pkg_files "$pkg_name" "$dwhdsentinel_cron_file_weekly"
    remove_cron_file='no'
  else
    remove_cron_file='yes'
  fi

  if [ "$remove_cron_file" = 'yes' ]; then
    dw_echo_colmsg "==> Cron Weekly Disabled, remove HDSentinel Cron File $dwhdsentinel_cron_file_weekly ..." 3
    rm -f $dwhdsentinel_cron_file_weekly
  fi

  if [ "$HDS_CRON_MONTHLY" = "yes" ]; then
    dw_echo_colmsg "==> Cron Monthly Enabled, create HDSentinel Cron File $dwhdsentinel_cron_file_monthly ..." 3
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      echo "/sbin/dwhdsentinel notify >/dev/null"
    ) >$dwhdsentinel_cron_file_monthly
    chmod 0744 $dwhdsentinel_cron_file_monthly
    dw_add_pkg_files "$pkg_name" "$dwhdsentinel_cron_file_monthly"
    remove_cron_file='no'
  else
    remove_cron_file='yes'
  fi

  if [ "$remove_cron_file" = 'yes' ]; then
    dw_echo_colmsg "==> Cron Monthly Disabled, remove HDSentinel Cron File $dwhdsentinel_cron_file_monthly ..." 3
    rm -f $dwhdsentinel_cron_file_monthly
  fi
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-hdsentinel.config
. /var/dwsetup/bin/setup-functions

dw_add_pkg_files "$pkg_name" "/var/www/hdsentinel/index.html"
create_dwhdsentinel_conf_file
check_dwhdsentinel_cron_files
dw_sctl_restart cron

#===============================================================================
# End
#===============================================================================
exit 0
