#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-wake.sh - Configuration Generator Script for Wake
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-wake'
dwwake_conf_dir='/etc/dw-wake'
dwwake_conf_file="$dwwake_conf_dir/dw-wake.conf"

dwwake_cron_file_daily='/etc/cron.daily/dwwake'
dwwake_cron_file_weekly='/etc/cron.weekly/dwwake'
dwwake_cron_file_monthly='/etc/cron.monthly/dwwake'

dwwake_shellyplug_shutdown_file="$dwwake_conf_dir/dwwake-shellyplug-shutdown"

#----------------------------------------------------------------------------------------
# Create Wake Configuration File
#----------------------------------------------------------------------------------------
create_dwwake_conf_file ()
{
  dw_echo_colmsg "==> Create Wake Config File $dwwake_conf_file ..." 1
  (
    echo "NOTIFY_MAIL='$NOTIFY_MAIL'"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    echo "NOTIFY_TELEGRAM='$NOTIFY_TELEGRAM'"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    echo "WAKE_COUNT='$WAKE_COUNT'"
    echo "WAKE_SLEEP='$WAKE_SLEEP'"
    echo "WAKE_SLEEP_ONLINE='$WAKE_SLEEP_ONLINE'"
    echo
    if dw_conf_var_is_enabled "$WAKE_SHELLYPLUG_SERVER"; then
      echo "WAKE_SHELLYPLUG_SERVER='$WAKE_SHELLYPLUG_SERVER'"
      echo "WAKE_SHELLYPLUG='$WAKE_SHELLYPLUG'"
      echo "WAKE_SHELLYPLUG_SHUTDOWN_DELAY='$WAKE_SHELLYPLUG_SHUTDOWN_DELAY'"
      echo
    fi
    if dw_conf_var_is_enabled "$WAKE_SERVER"; then
      echo "WAKE_SERVER='$WAKE_SERVER'"
      echo "WAKE_SERVER_MAC='$(echo "$WAKE_SERVER_MAC" | tr [:upper:] [:lower:])'"
      echo
    fi
    wake_hosts_n='0'
    if [ $WAKE_HOSTS_N -eq 0 ]
    then
      imax=1
    else
      imax=$WAKE_HOSTS_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval wake_hosts='$WAKE_HOSTS_'$idx
      if dw_conf_var_is_enabled "$wake_hosts"; then
        wake_hosts_n=$(expr $wake_hosts_n + 1)
      fi
      idx=$(expr $idx + 1)
    done
    echo "WAKE_HOSTS_N='$wake_hosts_n'"
    if [ $WAKE_HOSTS_N -eq 0 ]
    then
      imax=1
    else
      imax=$WAKE_HOSTS_N
    fi
    idx=1
    idx_n=1
    while [ $idx -le $imax ]
    do
      eval wake_hosts='$WAKE_HOSTS_'$idx
      if dw_conf_var_is_enabled "$wake_hosts";then
        echo "WAKE_HOSTS_"$idx_n"=""'$wake_hosts'"
        idx_n=$(expr $idx + 1)
      fi
      idx=$(expr $idx + 1)
    done
  ) > $dwwake_conf_file
  dw_add_pkg_files "$pkg_name" "$dwwake_conf_file"
}

#----------------------------------------------------------------------------------------
# Create Wake Cron Files
#----------------------------------------------------------------------------------------
check_dwwake_cron_files ()
{
  dw_echo_colmsg "==> Check Wake Cron Files ..." 1
  remove_cron_file='no'
  if dw_conf_var_is_enabled "$WAKE_MAC_CRON_DAILY"; then
    if [ -n "$WAKE_MAC_CRON_DAILY" ]; then
      dw_echo_colmsg "==> Cron Daily Enabled, create Wake Cron File $dwwake_cron_file_daily ..." 2
      WAKE_MAC_CRON_DAILY=$(echo "$WAKE_MAC_CRON_DAILY" | tr [:upper:] [:lower:])
      (
        echo "#!/bin/bash"
        echo 'MAILTO=""'
        echo "/usr/sbin/dwwake $WAKE_MAC_CRON_DAILY >/dev/null"
      ) >$dwwake_cron_file_daily
      chmod 0744 $dwwake_cron_file_daily
      dw_add_pkg_files "$pkg_name" "$dwwake_cron_file_daily"
      remove_cron_file='no'
    else
      remove_cron_file='yes'
    fi
  else
    remove_cron_file='yes'
  fi
  if dw_conf_var_is_yes "$remove_cron_file"; then
    dw_echo_colmsg "==> Cron Daily Disabled, remove Wake Cron File $dwwake_cron_file_daily ..." 2
    rm -f $dwwake_cron_file_daily
  fi

  if dw_conf_var_is_enabled "$WAKE_MAC_CRON_WEEKLY"; then
    if [ -n "$WAKE_MAC_CRON_WEEKLY" ]; then
      dw_echo_colmsg "==> Cron Weekly Enabled, create Wake Cron File $dwwake_cron_file_weekly ..." 2
      WAKE_MAC_CRON_WEEKLY=$(echo "$WAKE_MAC_CRON_WEEKLY" | tr [:upper:] [:lower:])
      (
        echo "#!/bin/bash"
        echo 'MAILTO=""'
        echo "/usr/sbin/dwwake $WAKE_MAC_CRON_WEEKLY >/dev/null"
      ) >$dwwake_cron_file_weekly
      chmod 0744 $dwwake_cron_file_weekly
      dw_add_pkg_files "$pkg_name" "$dwwake_cron_file_weekly"
      remove_cron_file='no'
    else
      remove_cron_file='yes'
    fi
  else
    remove_cron_file='yes'
  fi
  if dw_conf_var_is_yes "$remove_cron_file"; then
    dw_echo_colmsg "==> Cron Weekly Disabled, remove Wake Cron File $dwwake_cron_file_weekly ..." 2
    rm -f $dwwake_cron_file_weekly
  fi

  if dw_conf_var_is_enabled "$WAKE_MAC_CRON_MONTHLY"; then
    if [ -n "$WAKE_MAC_CRON_MONTHLY" ]; then
      dw_echo_colmsg "==> Cron Monthly Enabled, create Wake Cron File $dwwake_cron_file_monthly ..." 2
      WAKE_MAC_CRON_MONTHLY=$(echo "$WAKE_MAC_CRON_MONTHLY" | tr [:upper:] [:lower:])
      (
        echo "#!/bin/bash"
        echo 'MAILTO=""'
        echo "/usr/sbin/dwwake $WAKE_MAC_CRON_MONTHLY >/dev/null"
      ) >$dwwake_cron_file_monthly
      chmod 0744 $dwwake_cron_file_monthly
      dw_add_pkg_files "$pkg_name" "$dwwake_cron_file_monthly"
      remove_cron_file='no'
    else
      remove_cron_file='yes'
    fi
  else
    remove_cron_file='yes'
  fi
  if dw_conf_var_is_yes "$remove_cron_file"; then
    dw_echo_colmsg "==> Cron Monthly Disabled, remove Wake Cron File $dwwake_cron_file_monthly ..." 2
    rm -f $dwwake_cron_file_monthly
  fi

  dw_sctl_restart cron
}

#----------------------------------------------------------------------------------------
# Create Wake ShellyPlug Shutdown File
#----------------------------------------------------------------------------------------
create_dwwake_shellyplug_shutdown_file ()
{
  dw_echo_colmsg "==> Create Wake Shutdown File $dwwake_shellyplug_shutdown_file ..." 1
  (
    echo "#!/bin/bash"
    echo
    if dw_conf_var_is_enabled "$WAKE_SHELLYPLUG_SERVER"; then
      echo "systemctl stop dwwake"
      echo "dwshelly $WAKE_SHELLYPLUG off delay $WAKE_SHELLYPLUG_SHUTDOWN_DELAY"
      echo "sleep $WAKE_SHELLYPLUG_SHUTDOWN_DELAY"
      echo "sleep 60"
      echo "systemctl restart dwwake"
      echo
    else
      echo "/bin/true"
    fi
  ) > $dwwake_shellyplug_shutdown_file
  chmod 0744 $dwwake_shellyplug_shutdown_file
  dw_add_pkg_files "$pkg_name" "$dwwake_shellyplug_shutdown_file"
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-wake.config
. /var/dwsetup/bin/setup-functions

create_dwwake_conf_file
create_dwwake_shellyplug_shutdown_file
check_dwwake_cron_files

#===============================================================================
# End
#===============================================================================
exit 0
