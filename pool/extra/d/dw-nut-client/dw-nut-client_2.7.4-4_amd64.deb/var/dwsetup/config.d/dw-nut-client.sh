#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-nut-client.sh - Configuration Generator Script for NUT-Client
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  17.06.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

nut_dw_conf_file='/etc/dwconfig.d/conf/dw-nut.conf'
nut_conf_file='/etc/nut/nut.conf'
ups_mon_conf_file='/etc/nut/upsmon.conf'
ups_sched_conf_file='/etc/nut/upssched.conf'

#-------------------------------------------------------------------------------
# Create NUT-Client Configuration File /etc/dwconfig.d/conf/nut.conf
#-------------------------------------------------------------------------------
create_nut_dw_conf_file ()
{
  dw_echo_colmsg "==> Create $nut_dw_conf_file..." 1
  (
    dw_conf_header "$nut_dw_conf_file"\
      "DW NUT Notify Configuration File"\
      "$pkg_setup_menu_title > $pkg_title"
    echo "NOTIFY_MAIL='$NOTIFY_MAIL'"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    echo "NOTIFY_TELEGRAM='$NOTIFY_TELEGRAM'"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    dw_conf_var "NUT_MONITOR_UPS"
    dw_conf_footer e
    echo
  ) > $nut_dw_conf_file
  chmod 0644 $nut_dw_conf_file
  dw_add_pkg_files "$pkg_name" "$nut_dw_conf_file"
}

#-------------------------------------------------------------------------------
# Create NUT Configuration File /etc/nut/nut.conf
#-------------------------------------------------------------------------------
create_nut_conf_file ()
{
  dw_echo_colmsg "==> Create $nut_conf_file..." 1
  (
    dw_conf_header "$nut_conf_file"\
      "NUT Configuration File"\
      "$pkg_setup_menu_title > $pkg_title"
    echo "MODE=netclient"
    echo
    dw_conf_footer
  ) > $nut_conf_file
  chown root:nut $nut_conf_file
  chmod 0640 $nut_conf_file
  dw_add_pkg_files "$pkg_name" "$nut_conf_file"
}

#-------------------------------------------------------------------------------
# Create NUT upsmon Configuration File /etc/nut/upsmon.conf
#-------------------------------------------------------------------------------
create_ups_mon_conf_file ()
{
  dw_echo_colmsg "==> Create $ups_mon_conf_file..." 1
  (
    dw_conf_header "$ups_mon_conf_file"\
      "NUT upsmon Configuration File"\
      "$pkg_setup_menu_title > $pkg_title"
    echo "RUN_AS_USER root"
    echo
    echo 'SHUTDOWNCMD "/etc/shutdown.sh"'
    echo
    echo "MINSUPPLIES 1"
    echo
    echo "POLLFREQ $NUT_POLLFREQ"
    echo "POLLFREQALERT $NUT_POLLFREQALERT"
    echo
    echo "HOSTSYNC $NUT_HOSTSYNC"
    echo
    echo "DEADTIME $NUT_DEADTIME"
    echo
    echo "POWERDOWNFLAG /etc/killpower"
    echo
    echo "RBWARNTIME 86400"
    echo
    echo "NOCOMMWARNTIME $NUT_NOCOMMWARNTIME"
    echo
    echo "FINALDELAY $NUT_FINAL_DELAY"
    echo
    echo "MONITOR $NUT_MONITOR_UPS 1 $NUT_MONITOR_UPS_USER $NUT_MONITOR_UPS_PASSWD slave"
    echo
    echo "NOTIFYCMD /sbin/upssched"
    echo
    echo 'NOTIFYMSG NOPARENT  "upsmon Parent Process Died - Shutdown Impossible"'
    echo 'NOTIFYMSG NOCOMM    "UPS %s is Unavailable"'
    echo 'NOTIFYMSG COMMBAD   "Communications with UPS %s Lost"'
    echo 'NOTIFYMSG COMMOK    "Communications with UPS %s Established"'
    echo 'NOTIFYMSG ONLINE    "UPS %s on Power"'
    echo 'NOTIFYMSG ONBATT    "UPS %s on Battery"'
    echo 'NOTIFYMSG LOWBATT   "UPS %s Battery is Low, force Shutdown"'
    echo 'NOTIFYMSG REPLBATT  "UPS %s Battery needs to be Replaced"'
    echo 'NOTIFYMSG FSD       "UPS %s: forced Shutdown in Progress"'
    echo 'NOTIFYMSG SHUTDOWN  "Shutdown in Progress"'
    echo
    echo "NOTIFYFLAG NOPARENT   $NUT_NOTIFYFLAG_NOPARENT"
    echo "NOTIFYFLAG NOCOMM     $NUT_NOTIFYFLAG_NOCOMM"
    echo "NOTIFYFLAG COMMBAD    $NUT_NOTIFYFLAG_COMMBAD"
    echo "NOTIFYFLAG COMMOK     $NUT_NOTIFYFLAG_COMMOK"
    echo "NOTIFYFLAG ONLINE     $NUT_NOTIFYFLAG_ONLINE"
    echo "NOTIFYFLAG ONBATT     $NUT_NOTIFYFLAG_ONBATT"
    echo "NOTIFYFLAG LOWBATT    $NUT_NOTIFYFLAG_LOWBATT"
    echo "NOTIFYFLAG REPLBATT   $NUT_NOTIFYFLAG_REPLBATT"
    echo "NOTIFYFLAG FSD        $NUT_NOTIFYFLAG_FSD"
    echo "NOTIFYFLAG SHUTDOWN   $NUT_NOTIFYFLAG_SHUTDOWN"
    echo
    dw_conf_footer
  ) > $ups_mon_conf_file
  chown root:nut $ups_mon_conf_file
  chmod 0640 $ups_mon_conf_file
  dw_add_pkg_files "$pkg_name" "$ups_mon_conf_file"
}

#-------------------------------------------------------------------------------
# Create NUT upssched Configuration File /etc/nut/upssched.conf
#-------------------------------------------------------------------------------
create_ups_sched_conf_file ()
{
  dw_echo_colmsg "==> Create $ups_sched_conf_file..." 1
  (
    dw_conf_header "$ups_sched_conf_file"\
      "NUT upssched Configuration File"\
      "$pkg_setup_menu_title > $pkg_title"
    echo "CMDSCRIPT /bin/upssched.cmd"
    echo
    echo "PIPEFN /var/run/nut/upssched.pipe"
    echo "LOCKFN /var/run/nut/upssched.lock"
    echo
    echo "AT NOPARENT * EXECUTE noparent"
    echo "AT NOCOMM * EXECUTE nocomm"
    echo "AT COMMBAD * START-TIMER commbad 6"
    echo "AT COMMOK * EXECUTE commok"
    echo "AT COMMOK * CANCEL-TIMER commbad"
    echo "AT ONLINE * EXECUTE online"
    echo "AT ONBATT * EXECUTE onbatt"
    echo "AT LOWBATT * EXECUTE lowbatt"
    echo "AT REPLBATT * EXECUTE replbatt"
    echo "AT FSD * EXECUTE fsd"
    echo "AT SHUTDOWN * EXECUTE shutdown"
    echo
    dw_conf_footer
  ) > $ups_sched_conf_file
  chown root:nut $ups_sched_conf_file
  chmod 0640 $ups_sched_conf_file
  dw_add_pkg_files "$pkg_name" "$ups_sched_conf_file"
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /var/dwsetup/bin/pkg/dw-nut-client.functions.pkg
. /etc/dwconfig.d/dw-nut-client.config

case "$1" in
  status)
    upsc $NUT_MONITOR_UPS
    ;;
  *)
    create_nut_dw_conf_file
    create_nut_conf_file
    create_ups_mon_conf_file
    create_ups_sched_conf_file
    if dw_conf_var_is_enabled "$NUT_MONITOR_UPS"; then
      systemctl unmask nut-client
    else
      systemctl mask nut-client
    fi
    ;;
esac

#===============================================================================
# End
#===============================================================================
exit 0
