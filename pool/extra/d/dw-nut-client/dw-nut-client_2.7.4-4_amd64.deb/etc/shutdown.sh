#!/bin/bash

if [ -f /usr/sbin/dwshutdown ]; then
  dwshutdown halt
else
  shutdown -P now
fi
