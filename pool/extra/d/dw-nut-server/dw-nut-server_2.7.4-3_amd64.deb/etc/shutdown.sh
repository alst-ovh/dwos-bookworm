#!/bin/bash

if [ -f /etc/killpower ]; then
  upsdrvctl shutdown
fi

if [ -f /usr/sbin/dwshutdown ]; then
  dwshutdown halt
else
  shutdown -P now
fi
