#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-ddnsclient.sh - Configuration Generator Script for DDNS-Client
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-ddnsclient'
dwddnsclient_conf_dir='/etc/dw-ddnsclient'
dwddnsclient_conf_file="$dwddnsclient_conf_dir/dw-ddnsclient.conf"
dwddnsclient_logrotate="/etc/logrotate.d/dw-ddnsclient"
dwddnsclient_service_file='/etc/systemd/system/dwddnsclient.service'

#----------------------------------------------------------------------------------------
# Create DDNS-Client Configuration File
#----------------------------------------------------------------------------------------
create_dwddnsclient_conf_file ()
{
  dw_echo_colmsg "==> Create DDNS-Client Config File $dwddnsclient_conf_file ..." 1
  (
    echo "NOTIFY_MAIL='$NOTIFY_MAIL'"
    echo "NOTIFY_MAIL_ON_SUCCESS='$NOTIFY_MAIL_ON_SUCCESS'"
    echo "NOTIFY_MAIL_ON_FAIL='$NOTIFY_MAIL_ON_FAIL'"
    echo
    echo "NOTIFY_TELEGRAM='$NOTIFY_TELEGRAM'"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='$NOTIFY_TELEGRAM_ON_SUCCESS'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='$NOTIFY_MAIL_ON_FAIL'"
    echo
    if [ "$DDNSCLIENT_DNSOMATIC" = "yes" ]; then
      echo "DDNSCLIENT_DNSOMATIC='$DDNSCLIENT_DNSOMATIC'"
      echo "DDNSCLIENT_DNSOMATIC_HOST='$DDNSCLIENT_DNSOMATIC_HOST'"
      echo "DDNSCLIENT_DNSOMATIC_LOGIN='$DDNSCLIENT_DNSOMATIC_LOGIN'"
      echo "DDNSCLIENT_DNSOMATIC_PASSWORD='$DDNSCLIENT_DNSOMATIC_PASSWORD'"
      echo
    fi
    if [ "$DDNSCLIENT_OVH" = "yes" -a "$DDNSCLIENT_DNSOMATIC" != "yes" ]; then
      echo "DDNSCLIENT_OVH='$DDNSCLIENT_OVH'"
      echo "DDNSCLIENT_OVH_HOSTS='$DDNSCLIENT_OVH_HOSTS'"
      echo "DDNSCLIENT_OVH_LOGIN='$DDNSCLIENT_OVH_LOGIN'"
      echo "DDNSCLIENT_OVH_PASSWORD='$DDNSCLIENT_OVH_PASSWORD'"
      echo
    fi
  ) > $dwddnsclient_conf_file
  dw_add_pkg_files "$pkg_name" "$dwddnsclient_conf_file"
}

#----------------------------------------------------------------------------------------
# Check DDNS-Client Service File
#----------------------------------------------------------------------------------------
check_dwddnsclient_conf_file ()
{
  dw_echo_colmsg "==> Check DDNS-Client Service File $dwddnsclient_service_file ..." 1
  sed -i -e 's/RestartSec=60.*$/RestartSec='$DDNSCLIENT_INTERVALL'/' $dwddnsclient_service_file
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-base.config
. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-ddnsclient.config

create_dwddnsclient_conf_file
check_dwddnsclient_conf_file
if [ "$DDNSCLIENT_OVH" = "yes" -a "$DDNSCLIENT_DNSOMATIC" = "yes" ]; then
  dw_echo_colmsg "==> DDNS-Client WARNING: DDNSCLIENT_DNSOMATIC and DDNSCLIENT_OVHDDNS are both enabled, Only DDNSCLIENT_DNSOMATIC is used !!!" 1 a
fi

#===============================================================================
# End
#===============================================================================
exit 0
