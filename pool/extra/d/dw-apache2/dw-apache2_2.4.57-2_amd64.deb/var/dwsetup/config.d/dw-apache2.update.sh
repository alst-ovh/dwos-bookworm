#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-apache2.sh - Update or Generate New Apache2 Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-apache2.config'
config_header='/var/dwsetup/header/dw-apache2.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables() {
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables() {
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables() {
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables() {
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config() {
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header >$generate_conf
  (
    dw_conf_line
    echo "# General Settings"
    dw_conf_line
    echo
    dw_conf_var "APACHE_SERVER_ADMIN"
    echo
    dw_conf_var "APACHE_LOGLEVEL"
    dw_conf_comment "# Available values: trace8, ..., trace1, debug, info, notice, warn,"
    dw_conf_comment "# error, crit, alert, emerg."
    dw_conf_comment "# if APACHE_LOGLEVEL='' then warn is used"
    echo
    dw_conf_line
    echo "# Apache2 Modules Settings"
    echo "# (Prefix a APACHE_MODULES_ENABLE_x with a ! to Disable it)"
    dw_conf_line
    echo
    modules=''
    if [ $APACHE_MODULES_ENABLE_N -eq 0 ]; then
      imax=1
    else
      imax=$APACHE_MODULES_ENABLE_N
    fi
    idx=1
    while [ $idx -le $imax ]; do
      eval apache_modules_enable='$APACHE_MODULES_ENABLE_'$idx
      if [ -n "$apache_modules_enable" ]; then
        modules="$modules $apache_modules_enable"
      fi
      idx=$(expr $idx + 1)
    done
    modules=$(echo $modules | tr " " "\n" | sort | tr "\n" " ")
    APACHE_MODULES_ENABLE_N=$(echo $modules | wc -w)
    dw_conf_var "APACHE_MODULES_ENABLE_N"
    echo
    idx=1
    for modul in $modules; do
      echo "APACHE_MODULES_ENABLE_"$idx"=""'$modul'"
      idx=$(expr $idx + 1)
    done
    #    dw_conf_var "APACHE_MODULES_ENABLE_N"
    #    echo
    #    if [ $APACHE_MODULES_ENABLE_N -eq 0 ]
    #    then
    #      imax=1
    #    else
    #      imax=$APACHE_MODULES_ENABLE_N
    #    fi
    #    idx=1
    #    while [ $idx -le $imax ]
    #    do
    #      eval apache_modules_enable='$APACHE_MODULES_ENABLE_'$idx
    #      echo "APACHE_MODULES_ENABLE_"$idx"=""'$apache_modules_enable'"
    #      idx=$(expr $idx + 1)
    #    done
    echo
    dw_conf_line
    echo "# Apache2 PHP Settings"
    echo "# (Prefix a APACHE_PHP_x with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "APACHE_PHP_VERSION"
    dw_conf_var "APACHE_PHP_MEMORY_LIMIT"
    dw_conf_var "APACHE_PHP_UPLOAD_MAX_FILESIZE"
    dw_conf_var "APACHE_PHP_POST_MAX_SIZE"
    dw_conf_var "APACHE_PHP_MAX_EXECUTION_TIME"
    dw_conf_var "APACHE_PHP_DATE_TIMEZONE"
    echo
    dw_conf_line
    echo "# Apache2 Sites Settings"
    echo "# (Prefix a APACHE_SITES_x_NAME with a ! to Disable it)"
    echo "# (Prefix a APACHE_SITES_x_DIRECTORY_OPTIONS_x with a ! to Disable it)"
    echo "# (Prefix a APACHE_SITES_x_CONF_ADD_LINE_x with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "APACHE_SITES_N"
    echo
    if [ $APACHE_SITES_N -eq 0 ]; then
      imax=1
    else
      imax=$APACHE_SITES_N
    fi
    idx=1
    while [ $idx -le $imax ]; do
      eval apache_sites_name='$APACHE_SITES_'$idx'_NAME'
      eval apache_sites_enabled='$APACHE_SITES_'$idx'_ENABLED'
      eval apache_sites_ssl='$APACHE_SITES_'$idx'_SSL'
      eval apache_sites_letsencrypt='$APACHE_SITES_'$idx'_LETSENCRYPT'
      eval apache_sites_letsencrypt_wildcard_domain='$APACHE_SITES_'$idx'_LETSENCRYPT_WILDCARD_DOMAIN'
      eval apache_sites_server_name='$APACHE_SITES_'$idx'_SERVER_NAME'
      eval apache_sites_server_alias='$APACHE_SITES_'$idx'_SERVER_ALIAS'
      eval apache_sites_server_rewrite_to_alias='$APACHE_SITES_'$idx'_SERVER_REWRITE_TO_ALIAS'
      eval apache_sites_server_alias_add_n='$APACHE_SITES_'$idx'_SERVER_ALIAS_ADD_N'
      eval apache_sites_server_admin='$APACHE_SITES_'$idx'_SERVER_ADMIN'
      eval apache_sites_server_path='$APACHE_SITES_'$idx'_SERVER_PATH'
      eval apache_sites_document_root='$APACHE_SITES_'$idx'_DOCUMENT_ROOT'
      eval apache_sites_directory_options_n='$APACHE_SITES_'$idx'_DIRECTORY_OPTIONS_N'
      eval apache_sites_directory_index='$APACHE_SITES_'$idx'_DIRECTORY_INDEX'
      eval apache_sites_conf_add_line_n='$APACHE_SITES_'$idx'_CONF_ADD_LINE_N'
      eval apache_sites_loglevel='$APACHE_SITES_'$idx'_LOGLEVEL'
      eval apache_sites_own_log='$APACHE_SITES_'$idx'_OWN_LOG'
      echo "APACHE_SITES_"$idx"_NAME=""'$apache_sites_name'"
      echo "APACHE_SITES_"$idx"_ENABLED=""'$apache_sites_enabled'"
      echo "APACHE_SITES_"$idx"_SSL=""'$apache_sites_ssl'"
      echo "APACHE_SITES_"$idx"_LETSENCRYPT=""'$apache_sites_letsencrypt'"
      echo "APACHE_SITES_"$idx"_LETSENCRYPT_WILDCARD_DOMAIN=""'$apache_sites_letsencrypt_wildcard_domain'"
      echo "APACHE_SITES_"$idx"_SERVER_NAME=""'$apache_sites_server_name'"
      echo "APACHE_SITES_"$idx"_SERVER_ALIAS=""'$apache_sites_server_alias'"
      echo "APACHE_SITES_"$idx"_SERVER_REWRITE_TO_ALIAS=""'$apache_sites_server_rewrite_to_alias'"
      if [ -z $apache_sites_server_alias_add_n ]; then
        apache_sites_server_alias_add_n='0'
      fi
      echo "APACHE_SITES_"$idx"_SERVER_ALIAS_ADD_N=""'$apache_sites_server_alias_add_n'"
      if [ $apache_sites_server_alias_add_n -eq 0 ]; then
        imaxa=1
      else
        imaxa=$apache_sites_server_alias_add_n
      fi
      idxa=1
      while [ $idxa -le $imaxa ]; do
        eval apache_sites_server_alias_add='$APACHE_SITES_'$idx'_SERVER_ALIAS_ADD_'$idxa
        echo "APACHE_SITES_"$idx"_SERVER_ALIAS_ADD_"$idxa"=""'$apache_sites_server_alias_add'"
        idxa=$(expr $idxa + 1)
      done
      echo "APACHE_SITES_"$idx"_SERVER_ADMIN=""'$apache_sites_server_admin'"
      echo "APACHE_SITES_"$idx"_SERVER_PATH=""'$apache_sites_server_path'"
      echo "APACHE_SITES_"$idx"_DOCUMENT_ROOT=""'$apache_sites_document_root'"
      echo "APACHE_SITES_"$idx"_DIRECTORY_OPTIONS_N=""'$apache_sites_directory_options_n'"
      if [ $apache_sites_directory_options_n -eq 0 ]; then
        imaxa=1
      else
        imaxa=$apache_sites_directory_options_n
      fi
      idxa=1
      while [ $idxa -le $imaxa ]; do
        eval apache_sites_directory_option='$APACHE_SITES_'$idx'_DIRECTORY_OPTIONS_'$idxa
        echo "APACHE_SITES_"$idx"_DIRECTORY_OPTIONS_"$idxa"=""'$apache_sites_directory_option'"
        idxa=$(expr $idxa + 1)
      done
      echo "APACHE_SITES_"$idx"_DIRECTORY_INDEX=""'$apache_sites_directory_index'"
      echo "APACHE_SITES_"$idx"_CONF_ADD_LINE_N=""'$apache_sites_conf_add_line_n'"
      if [ $apache_sites_conf_add_line_n -eq 0 ]; then
        imaxa=1
      else
        imaxa=$apache_sites_conf_add_line_n
      fi
      idxa=1
      while [ $idxa -le $imaxa ]; do
        eval apache_sites_conf_add_line='$APACHE_SITES_'$idx'_CONF_ADD_LINE_'$idxa
        echo "APACHE_SITES_"$idx"_CONF_ADD_LINE_"$idxa"=""'$apache_sites_conf_add_line'"
        idxa=$(expr $idxa + 1)
      done
      echo "APACHE_SITES_"$idx"_LOGLEVEL=""'$apache_sites_loglevel'"
      echo "APACHE_SITES_"$idx"_OWN_LOG=""'$apache_sites_own_log'"
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_footer
  ) >>$generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]; then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1" in

update)
  source_conf=$source_conf_file
  generate_conf=$source_conf_file
  goflag=1
  ;;
test)
  source_conf=$source_conf_file
  generate_conf=$source_conf_file.test
  goflag=1
  ;;
*)
  echo
  echo "Use one of the following options:"
  echo
  echo "  $0 [update]"
  echo
  echo "  $source_conf_file will be read"
  echo "  $generate_conf_file configuration file will be written"
  echo "  the configuration will be checked and an updated."
  echo
  goflag=0
  ;;
esac

if [ $goflag -eq 1 ]; then
  if [ -f $source_conf ]; then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
