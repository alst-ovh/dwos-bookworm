#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-osbackup.sh - Configuration Generator Script for OS-Backup
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-osbackup'
dwosbackup_conf_dir='/etc/dw-osbackup'
dwosbackup_conf_file="$dwosbackup_conf_dir/dw-osbackup.conf"
dwosbackup_exclude_file="$dwosbackup_conf_dir/dw-osbackup-exclude"

cron_dir='/etc/cron'
dwosbackup_cronfile='dw-osbackup'

#----------------------------------------------------------------------------------------
# Create OS-Backup Configuration File
#----------------------------------------------------------------------------------------
create_dwosbackup_conf_file() {
  dw_echo_colmsg "==> Create OS-Backup Config File ..." 1
  (
    dw_conf_var "NOTIFY_MAIL"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    dw_conf_var "NOTIFY_TELEGRAM"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    echo "BACKUP_CHECK_HDMINFREE='$BACKUP_CHECK_HDMINFREE'"
    echo "BACKUP_HDMINFREE='$BACKUP_HDMINFREE'"
    echo
    echo "BACKUP_DELETE_BEFORE='$BACKUP_DELETE_BEFORE'"
    echo
    echo "BACKUP_RSYNC_TIMEOUT='$BACKUP_RSYNC_TIMEOUT'"
    echo "BACKUP_RSYNC_BWLIMIT='$BACKUP_RSYNC_BWLIMIT'"
    echo
  ) >$dwosbackup_conf_file
  dw_add_pkg_files "$pkg_name" "$dwosbackup_conf_file"
}

#----------------------------------------------------------------------------------------
# Create OS-Backup Exclude File
#----------------------------------------------------------------------------------------
create_dwosbackup_exclude_file() {
  dw_echo_colmsg "==> Create OS-Backup Exclude File ..." 1
  : >$dwosbackup_exclude_file
  chmod 0644 $dwosbackup_exclude_file
  dw_add_pkg_files "$pkg_name" "$dwosbackup_exclude_file"
  idx='1'
  eval os_excludes_n='$BACKUP_OS_EXCLUDES_N'
  while [ "$idx" -le "$os_excludes_n" ]; do
    eval os_excludes='$BACKUP_OS_EXCLUDES_'$idx
    if dw_conf_var_is_enabled "$os_excludes"; then
      echo "$os_excludes" >>$dwosbackup_exclude_file
    else
      os_excludes_disabled='BACKUP_OS_EXCLUDES_'$idx
      dw_echo_colmsg "==> INFO: Exclude $os_excludes_disabled is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#-------------------------------------------------------------------------------
# Create OS-Backup Scripts File /etc/dw-osbackup/do_dw-osbackup-BACKUP_OS_#_HOSTNAME.{daily | weekly | monthly}.script
#-------------------------------------------------------------------------------
create_dwosbackup_scripts() {
  dw_echo_colmsg "==> Create OS-Backup Script Files ..." 1
  rm -f $dwosbackup_conf_dir/do_dw-osbackup-*.script
  rm -f $dwosbackup_conf_dir/*.hostexclude
  idx=1
  while [ "$idx" -le "$BACKUP_OS_N" ]; do
    eval backup_os_hostname='$BACKUP_OS_'$idx'_HOSTNAME'
    eval backup_os_include_datadir='$BACKUP_OS_'$idx'_INCLUDE_DATADIR'
    eval backup_os_daily='$BACKUP_OS_'$idx'_DAILY'
    eval backup_os_daily_count='$BACKUP_OS_'$idx'_DAILY_COUNT'
    eval backup_os_weekly='$BACKUP_OS_'$idx'_WEEKLY'
    eval backup_os_weekly_count='$BACKUP_OS_'$idx'_WEEKLY_COUNT'
    eval backup_os_monthly='$BACKUP_OS_'$idx'_MONTHLY'
    eval backup_os_monthly_count='$BACKUP_OS_'$idx'_MONTHLY_COUNT'
    eval backup_daily_script_file='$dwosbackup_conf_dir/do_dw-osbackup-$backup_os_hostname-daily.script'
    eval backup_weekly_script_file='$dwosbackup_conf_dir/do_dw-osbackup-$backup_os_hostname-weekly.script'
    eval backup_monthly_script_file='$dwosbackup_conf_dir/do_dw-osbackup-$backup_os_hostname-monthly.script'
    dwosbackup_host_exclude_file="$dwosbackup_conf_dir/$backup_os_hostname.hostexclude"
    if dw_conf_var_is_enabled "$backup_os_hostname"; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create OS-Backup Host Exclude File $dwosbackup_host_exclude_file ..." 2
      if dw_conf_var_is_yes "$backup_os_include_datadir"; then
        :> "$dwosbackup_host_exclude_file"
      else
        echo "$DATA_DIR/*" >"$dwosbackup_host_exclude_file"
      fi
      if dw_conf_var_is_yes "$backup_os_daily"; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create OS-Backup Script File $backup_daily_script_file ..." 2
        (
          echo "#!/bin/bash"
          echo "dwosbackup daily $backup_os_hostname $backup_os_daily_count"
        ) >$backup_daily_script_file
        chmod 0744 $backup_daily_script_file
        dw_add_pkg_files "$pkg_name" "$backup_daily_script_file"
      fi
      if dw_conf_var_is_yes "$backup_os_weekly"; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create OS-Backup Script File $backup_weekly_script_file ..." 2
        (
          echo "#!/bin/bash"
          echo "dwosbackup weekly $backup_os_hostname $backup_os_weekly_count"
        ) >$backup_weekly_script_file
        chmod 0744 $backup_weekly_script_file
        dw_add_pkg_files "$pkg_name" "$backup_weekly_script_file"
      fi
      if dw_conf_var_is_yes "$backup_os_monthly"; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create OS-Backup Script File $backup_monthly_script_file ..." 2
        (
          echo "#!/bin/bash"
          echo "dwosbackup monthly $backup_os_hostname $backup_os_monthly_count"
        ) >$backup_monthly_script_file
        chmod 0744 $backup_monthly_script_file
        dw_add_pkg_files "$pkg_name" "$backup_monthly_script_file"
      fi
    else
      script_disabled='BACKUP_OS_'$idx'_HOSTNAME'
      dw_echo_colmsg "==> INFO: Script $script_disabled is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done
}

#-------------------------------------------------------------------------------
# Check OS-Backup Script Cronjob
#-------------------------------------------------------------------------------
check_dwosbackup_scripts_cronjob() {
  write_dwosbackup_scripts_cronjob() {
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      dw_conf_line
      echo "# $cron_dir.$1/$dwosbackup_cronfile - OS-Backup Cronjob $1 File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-osbackup.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Rsync Configuration'"
      echo "#"
      echo "# in dwsetup > Backup > OS-Backup !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo " script_dir='/etc/dw-osbackup'"
      echo
      echo ' for script in $(find $script_dir -name *-'$1'.script -type f | sort); do'
      echo '   $script >/dev/null'
      echo " done"
      echo
      dw_conf_footer
      echo
    ) >$cron_dir.$1/$dwosbackup_cronfile
  }
  case "$BACKUP_SCRIPT_CRON" in
  yes)
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create OS-Backup Cron File $1 ..." 1
    if [ ! -d $cron_dir.$1 ]; then
      mkdir -p $cron_dir.$1
    fi
    write_dwosbackup_scripts_cronjob $1
    chmod 0744 $cron_dir.$1/$dwosbackup_cronfile
    dw_add_pkg_files "$pkg_name" "$cron_dir.$1/$dwosbackup_cronfile"
    ;;
  no)
    if [ -f $cron_dir.$1/$dwosbackup_cronfile ]; then
      rm -f $cron_dir.$1/$dwosbackup_cronfile
    fi
    ;;
  *)
    true
    ;;
  esac
}

#-------------------------------------------------------------------------------
# Check OS-Backup Script Cronjobs
#-------------------------------------------------------------------------------
check_dwosbackup_scripts_cronjobs() {
  if [ "$BACKUP_SCRIPT_CRON" = "yes" ]; then
    dw_echo_colmsg "==> Create OS-Backup Cron Files ..." 1
  else
    dw_echo_colmsg "==> OS-Backup Cron Backup is Disabled ..." 1 n
  fi
  check_dwosbackup_scripts_cronjob daily
  check_dwosbackup_scripts_cronjob weekly
  check_dwosbackup_scripts_cronjob monthly
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-base.config
. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-osbackup.config

if [ "$1" == "-quiet" ]; then
  quiet="quiet"
else
  quiet=''
fi

create_dwosbackup_conf_file
create_dwosbackup_exclude_file
create_dwosbackup_scripts
check_dwosbackup_scripts_cronjobs

#===============================================================================
# End
#===============================================================================
exit 0
