#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-osbackup.update.sh - Update or Generate New OS-Backup Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-osbackup.config'
config_header='/var/dwsetup/header/dw-osbackup.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Settings for OS-Backup"
    dw_conf_line
    echo
    dw_conf_var "NOTIFY_MAIL"
    dw_conf_comment "# Send Mail yes or no"
    echo
    dw_conf_var "NOTIFY_TELEGRAM"
    dw_conf_comment "# Send Telegram Message yes or no"
    echo
    dw_conf_var "BACKUP_CHECK_HDMINFREE"
    dw_conf_comment "# Check for enough Space on Backup Disk yes or no"
    dw_conf_var "BACKUP_HDMINFREE"
    dw_conf_comment "# Min Space in Percent"
    echo
    dw_conf_var "BACKUP_DELETE_BEFORE"
    dw_conf_comment "# Delete Before yes or no"
    echo
    dw_conf_line
    echo "# Rsync Settings for OS-Backup"
    dw_conf_line
    echo
    dw_conf_var "BACKUP_RSYNC_TIMEOUT"
    dw_conf_comment "# Timeout from Rsync in Seconds, 0 Disable it"
    dw_conf_var "BACKUP_RSYNC_BWLIMIT"
    dw_conf_comment "# Limit the Bandwith KByte/Sec, leave empty or 0 for none"
    echo
    dw_conf_line
    echo "# Backup Exclude Settings for OS-Backup"
    echo "#"
    echo "# (Prefix a Exclude in BACKUP_OS_x_EXCLUDES with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "BACKUP_OS_EXCLUDES_N"
    dw_conf_comment "# Number of Exludes"
    if [ $BACKUP_OS_EXCLUDES_N -eq 0 ]
    then
      imax=1
    else
      imax=$BACKUP_OS_EXCLUDES_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval backup_os_excludes='$BACKUP_OS_EXCLUDES_'$idx
      echo "BACKUP_OS_EXCLUDES_"$idx"=""'$backup_os_excludes'"
      idx=$(expr $idx + 1)
    done
    echo
    dw_conf_line
    echo "# Backup OS Settings for OS-Backup"
    echo "#"
    echo "# (Prefix a Exclude in BACKUP_OS_x_HOSTNAME with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "BACKUP_SCRIPT_CRON"
    dw_conf_comment "# Running Backup Scripts via Cron yes or no"
    echo
    dw_conf_var "BACKUP_OS_N"
    dw_conf_comment "# Number of OS's to Backup"
    if [ $BACKUP_OS_N -eq 0 ]
    then
      imax=1
    else
      imax=$BACKUP_OS_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval backup_os_hostname='$BACKUP_OS_'$idx'_HOSTNAME'
      eval backup_os_include_datadir='$BACKUP_OS_'$idx'_INCLUDE_DATADIR'
      eval backup_os_daily='$BACKUP_OS_'$idx'_DAILY'
      eval backup_os_daily_count='$BACKUP_OS_'$idx'_DAILY_COUNT'
      eval backup_os_weekly='$BACKUP_OS_'$idx'_WEEKLY'
      eval backup_os_weekly_count='$BACKUP_OS_'$idx'_WEEKLY_COUNT'
      eval backup_os_monthly='$BACKUP_OS_'$idx'_MONTHLY'
      eval backup_os_monthly_count='$BACKUP_OS_'$idx'_MONTHLY_COUNT'
      echo "BACKUP_OS_"$idx"_HOSTNAME"="'$backup_os_hostname'"
      dw_conf_comment "# Backup OS Hostname or IP"
      echo "BACKUP_OS_"$idx"_INCLUDE_DATADIR"="'$backup_os_include_datadir'"
      dw_conf_comment "# Include Data Directory yes or no"
      echo "BACKUP_OS_"$idx"_DAILY"="'$backup_os_daily'"
      dw_conf_comment "# Backup Daily yes or no"
      echo "BACKUP_OS_"$idx"_DAILY_COUNT"="'$backup_os_daily_count'"
      dw_conf_comment "# Backup Daily Count, Empty or 0 disables Rotate"
      echo "BACKUP_OS_"$idx"_WEEKLY"="'$backup_os_weekly'"
      dw_conf_comment "# Backup Weekly yes or no"
      echo "BACKUP_OS_"$idx"_WEEKLY_COUNT"="'$backup_os_weekly_count'"
      dw_conf_comment "# Backup Weekly Count, Empty or 0 disables Rotate"
      echo "BACKUP_OS_"$idx"_MONTHLY"="'$backup_os_monthly'"
      dw_conf_comment "# Backup Monthly yes or no"
      echo "BACKUP_OS_"$idx"_MONTHLY_COUNT"="'$backup_os_monthly_count'"
      dw_conf_comment "# Backup Monthly Count, Empty or 0 disables Rotate"
      idx=$(expr $idx + 1)
      echo
    done
    dw_conf_line e
  ) >> $generate_conf

  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

dummy ()
{
  /bin/true
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
