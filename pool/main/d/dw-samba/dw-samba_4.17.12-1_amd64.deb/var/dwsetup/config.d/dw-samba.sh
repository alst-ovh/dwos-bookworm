#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-samba.sh - configuration generator script for Samba
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

samba_conf='/etc/samba/smb.conf'
samba_shares_conf='/etc/samba/smb.shares.conf'
samba_username_map='/etc/samba/username.map'

min_rlimit_max=16384
limits_file='/etc/security/limits.conf'

avahi_service_file='/etc/avahi/services/smb.service'

samba_fruit_model_default='RackMac'

do_share_always() {
  (
    echo "   level2 oplocks = No"
    echo "   blocking locks = No"
    echo "   oplocks = Yes"
    #echo "   hide files = /desktop.ini/Thumbs.db/"
  ) >>$samba_conf
}

#-------------------------------------------------------------------------------
# Create Avahi Samba Service File /etc/avahi/services/smb.service
#-------------------------------------------------------------------------------
create_avahi_service_file() {
  dw_echo_colmsg "==> Create Avahi Service File $avahi_service_file ..." 1
  if [ -z $SAMBA_FRUIT_MODEL ]; then
    SAMBA_FRUIT_MODEL=$samba_fruit_model_default
  fi
  (
    echo "<?xml version=\"1.0\" standalone='no'?>"
    echo "<!DOCTYPE service-group SYSTEM \"avahi-service.dtd\">"
    echo "<service-group>"
    echo " <name replace-wildcards=\"yes\">%h</name>"
    echo " <service>"
    echo "   <type>_smb._tcp</type>"
    echo "   <port>445</port>"
    echo " </service>"
    echo " <service>"
    echo "   <type>_device-info._tcp</type>"
    echo "   <port>0</port>"
    echo "   <txt-record>model=$SAMBA_FRUIT_MODEL,119</txt-record>"
    echo " </service>"
    echo "</service-group>"
  ) >$avahi_service_file
}

#-------------------------------------------------------------------------------
# Create Samba Configuration File /etc/samba/samba.conf
#-------------------------------------------------------------------------------
create_samba_conf() {
  dw_echo_colmsg "==> Create Samba Configuration ..." 1
  #-----------------------------------
  # Check Configuration
  #-----------------------------------

  netbiosname=$(hostname)
  servername=$(hostname -f)
  serverstring="$SAMBA_SERVERSTRING"

  #-----------------------------------
  # Wins
  #-----------------------------------
  if dw_conf_var_is_yes "$SAMBA_WINSSERVER"; then
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Configured as Wins Server" 3 n
    wins_support="Yes"
    wins_server=''
    wins_proxy="No"
    nameresolveorder="wins lmhosts host bcast"
  else
    wins_support="No"
    if [ "$SAMBA_EXTWINSIP" != '' ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Configured as Wins Client" 3 n
      wins_server="$SAMBA_EXTWINSIP"
      wins_proxy="Yes"
      nameresolveorder="wins lmhosts host bcast"
    else
      wins_server=''
      wins_proxy="No"
      nameresolveorder="lmhosts host wins bcast"
    fi
  fi

  dw_echo_colmsg "==> Create $samba_conf ..." 1
  (
    dw_conf_header "$samba_conf" \
      "Samba Configuration File" \
      "$pkg_setup_menu_title > $pkg_title"
    #-----------------------------------
    # Global Configuration
    #-----------------------------------
    echo "[global]"
    echo "   server role = standalone server"
    echo
    echo "   local master = No"
    echo
    echo "   netbios name = $netbiosname"
    echo
    if [ -z "$SAMBA_WORKGROUP" ]; then
      SAMBA_WORKGROUP='WORKGROUP'
    fi
    echo "   workgroup = $SAMBA_WORKGROUP"
    if [ -z $SAMBA_SERVERSTRING ]; then
      SAMBA_SERVERSTRING='Samba Server'
    fi
    echo "   server string = $servername $SAMBA_SERVERSTRING"
    echo
    # New disables Uppercase Server Name
    echo "   mdns name = mdns"
    echo
    if [ -n "$SAMBA_INTERFACES" ]; then
      echo "   interfaces = $SAMBA_INTERFACES"
      echo "   bind interfaces only = Yes"
    fi
    if [ -n "$SAMBA_HOSTS" ]; then
      echo "   hosts allow = $SAMBA_HOSTS"
      echo
    fi
    if [ -z "$SAMBA_MIN_PROTOCOL" ]; then
      SAMBA_MIN_PROTOCOL='SMB2'
    fi
    echo "   min protocol = $SAMBA_MIN_PROTOCOL"
    if [ -n "$SAMBA_MAX_PROTOCOL" ]; then
      echo "   max protocol = $SAMBA_MAX_PROTOCOL"
    fi
    echo
    if [ -z "$SAMBA_FRUIT_MODEL" ]; then
      SAMBA_FRUIT_MODEL=$samba_fruit_model_default
    fi
    echo "# Mac Extensions ..."
    echo "   ea support = Yes"
    if [ "$SAMBA_RECYCLE" == 'Yes' ]; then
      echo "   vfs objects = catia fruit streams_xattr recycle"
      #if [ -z $SAMBA_RECYCLE_NAME ]; then
      #  SAMBA_RECYCLE_NAME="Trash"
      #fi
      echo "   recycle:repository = $DATA_DIR/.recycle/%u"
      echo "   recycle:keeptree = Yes"
      echo "   recycle:touch = Yes"
      echo "   recycle:versions = Yes"
      echo "   recycle:maxsize = 0"
      echo "   recycle:directory_mode = 0777"
      #if [ ! -d "$DATA_DIR/.recycle" ]; then
      #  mkdir -p "$DATA_DIR/.recycle"
      #fi
      #chown root:root "$DATA_DIR/.recycle"
      #chmod 0777 "$DATA_DIR/.recycle"
    else
      echo "   vfs objects = catia fruit streams_xattr"
    fi
    echo "   fruit:model = $SAMBA_FRUIT_MODEL"
    echo "   fruit:metadata = stream"
    echo "   fruit:posix_rename = Yes"
    echo "   fruit:veto_appledouble = No"
    echo "   fruit:wipe_intentionally_left_blank_rfork = Yes"
    echo "   fruit:delete_empty_adfiles = Yes"
    # fruit:advertise_fullsync must be enabled for TM show correct disk size
    echo "   fruit:advertise_fullsync = true"
    echo "   fruit:aapl = Yes"
    echo "   spotlight = Yes"
    echo
    echo "# Testing"
    echo "   fruit:resource = stream"
    echo "   # fruit:metadata = netatalk"
    echo "   # fruit:resource = file"
    echo "   fruit:locking = none"
    echo "   fruit:encoding = private"
    echo "   #fruit:aapl = yes"
    echo "   readdir_attr:aapl_rsize = Yes"
    echo "   readdir_attr:aapl_finder_info = Yes"
    echo "   readdir_attr:aapl_max_access = Yes"
    echo "   fruit:nfs_aces = Yes"
    echo "   fruit:copyfile= Yes"
    echo "   fruit:posix_rename = Yes"
    echo "   fruit:zero_file_id = Yes"
    echo
    echo "# NEW from wdmc"
    echo "   create mask = 0777"
    echo "   directory mask  = 0777"
    echo "   force create mode = 0777"
    echo "   force directory mode = 0777"
    echo "# Hide Share from Invalid Users .."
    echo "   access based share enum = Yes"
    echo "   hide unreadable = Yes"
    echo
    echo "   oplocks = Yes"
    echo
    #-----------------------------------
    # User
    #-----------------------------------
    echo "   security = user"
    # deprecated
    #echo "   encrypt passwords = Yes"
    echo "   passdb backend = smbpasswd"
    echo "   smb passwd file = /etc/samba/smbpasswd"
    #echo "   null passwords = Yes"
    #echo "   passdb backend = tdbsam"
    #echo "   obey pam restrictions = No"
    #echo "   pam password change = No"
    #echo "   passwd program = /usr/bin/passwd %u"
    #echo "   passwd chat = *Enter\snew\s*\spassword:* %n\n *Retype\snew\s*\spassword:* %n\n *password\supdated\ssuccessfully* ."
    #echo "   unix password sync = No"
    if [ -n "$SAMBA_INVALID_USERS" ]; then
      echo "   invalid users = $SAMBA_INVALID_USERS"
    fi
    echo
    if dw_conf_var_is_yes "$SAMBA_MAP_TO_GUEST"; then
      echo "   map to guest = bad user"
      echo "   guest account = nobody"
      echo
    fi
    echo "   panic action = /usr/share/samba/panic-action %d"
    echo
    echo "   deadtime = 15"
    echo
    echo "   username map = $samba_username_map"
    echo
    #-----------------------------------
    # Wins
    #-----------------------------------
    echo "   wins support = $wins_support"
    echo "   wins server = $wins_server"
    echo "   wins proxy = $wins_proxy"
    echo "   dns proxy = Yes"
    echo "   nameresolveorder = $nameresolveorder"
    echo
    #-----------------------------------
    # Localization
    #-----------------------------------
    if [ -n "$SAMBA_DOS_CHARSET" ]; then
      echo "   dos charset = $SAMBA_DOS_CHARSET"
    fi
    if [ -n "$SAMBA_UNIX_CHARSET" ]; then
      echo "   unix charset = $SAMBA_UNIX_CHARSET"
    fi
    echo
    #-----------------------------------
    # Unix Extensions
    #-----------------------------------
    if dw_conf_var_is_yes "$SAMBA_UNIX_EXTENSIONS"; then
      echo "   unix extensions = Yes"
    else
      echo "   unix extensions = No"
    fi
    #-----------------------------------
    # Dot Files
    #-----------------------------------
    if dw_conf_var_is_yes "$SAMBA_HIDE_DOT_FILES"; then
      echo "   hide dot files = Yes"
      echo "   hide files = /.*/"
      echo
    fi
    echo "   printable = No"
    echo "   load printers = No"
    echo
    if dw_conf_var_is_yes "$SAMBA_TIMESERVER"; then
      echo "   time server = Yes"
    else
      echo "   time server = No"
    fi
    echo
    echo "   log file = /var/log/samba/%m.log"
    echo "   log level = $SAMBA_LOGLEVEL"
    echo "   debug level = $debuglevel"
    echo "   max log size = 1000"
    echo
    echo "   include = $samba_shares_conf"
    dw_conf_footer
  ) >$samba_conf
  if [ ! -f "$samba_shares_conf" ]; then
    touch "$samba_shares_conf"
  fi
}

#-------------------------------------------------------------------------------
# Creating Samba Users Mapping File
#-------------------------------------------------------------------------------
create_samba_username_map() {
  dw_echo_colmsg "==> Create Samba Usermap File $samba_username_map ..." 1
  dw_conf_header "$samba_username_map" \
    "Samba Usermap Configuration File" \
    "$pkg_setup_menu_title > $pkg_title" >$samba_username_map
  idx=1
  while [ "$idx" -le "$SAMBA_USER_MAP_N" ]; do
    eval user_from='$SAMBA_USER_MAP_'$idx'_USER_FROM'
    eval user_to='$SAMBA_USER_MAP_'$idx'_USER_TO'
    if dw_conf_var_is_enabled "$user_from"; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Usermap $user_from = $user_to" 3 o
      echo "$user_from = $user_to" >>$samba_username_map
    else
      samba_user_map_disabled='SAMBA_USER_MAP_'$idx'_USER_FROM'
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: User $samba_user_map_disabled is disabled !" 3 n
    fi
    idx=$(expr $idx + 1)
  done
  (dw_conf_footer) >>$samba_username_map
}

#-------------------------------------------------------------------------------
#  rlimit_max to minimum Windows limit (16384)
#-------------------------------------------------------------------------------
check_rlimit_max() {
  dw_echo_colmsg "==> Check rlimit_max ..." 1
  rlimit_max=$(ulimit -n)
  dw_echo_colmsg "==> OK rlimit_max = $rlimit_max" 2
  if [ $rlimit_max -lt $min_rlimit_max ]; then
    dw_echo_colmsg "==> Set rlimit_max to $min_rlimit_max" 3
    dw_echo_colmsg "==> Reboot to take effect new rlimit_max !!!" 4 a
    if ! grep -qw "root            -       nofile         $min_rlimit_max" $limits_file; then
      sed -i -e '/.*# End of file.*$/d' $limits_file
      echo "root            -       nofile         $min_rlimit_max" >>$limits_file
      echo "# End of file" >>$limits_file
    fi
  fi
}

#===============================================================================
# restart-services - Restart Services
#===============================================================================
restart_services() {
  do_restart() {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
  do_restart nmbd
  do_restart smbd
  do_restart avahi-daemon
  do_restart wsdd
}
#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/lib/dw-all.libs
. /var/dwsetup/bin/setup-functions
. /var/dwsetup/bin/pkg/dw-samba.functions.pkg
. /etc/dwconfig.d/dw-samba.config
. /etc/dwconfig.d/dw-shares.config
. /etc/dwconfig.d/dw-base.config

if [ "$1" == "-quiet" ]; then
  quiet="quiet"
else
  quiet=''
fi

if [ "$SAMBA_DEBUGLEVEL" -gt "0" ]; then
  if [ "$SAMBA_DEBUGLEVEL" -gt "3" ]; then
    debuglevel="3"
  else
    debuglevel="$SAMBA_DEBUGLEVEL"
  fi
else
  debuglevel="0"
fi

check_rlimit_max
create_avahi_service_file
create_samba_conf
create_samba_username_map

if [ -f /var/dwsetup/config.d/dw-shares.sh ]; then
  /var/dwsetup/config.d/dw-shares.sh $quiet smbd
fi
if [ -f /var/dwsetup/config.d/dw-users.sh ]; then
  /var/dwsetup/config.d/dw-users.sh $quiet
fi

restart_services

#===============================================================================
# End
#===============================================================================
exit 0
