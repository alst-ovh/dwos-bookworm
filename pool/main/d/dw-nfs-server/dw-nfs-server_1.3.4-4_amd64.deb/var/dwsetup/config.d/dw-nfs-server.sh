#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-nfs-server.sh - Configuration Generator Script for NFS-Server
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

nfs_kernel_server_conf='/etc/default/nfs-kernel-server'
nfs_exports_conf='/etc/exports'
hosts_deny_file='/etc/hosts.deny'
hosts_allow_file='/etc/hosts.allow'

#-------------------------------------------------------------------------------
# Check Default NFS Configuration File $nfs_kernel_server_conf
#-------------------------------------------------------------------------------
check_nfs_kernel_server_conf ()
{
  dw_echo_colmsg "==> Check $nfs_kernel_server_conf ..." 1
  sed -i -e 's/.*RPCNFSDCOUNT.*$/RPCNFSDCOUNT='$NFS_RPCNFSDCOUNT'/' $nfs_kernel_server_conf
  sed -i -e 's/.*RPCMOUNTDOPTS.*$/RPCMOUNTDOPTS="'$NFS_RPCMOUNTDOPTS'"/' $nfs_kernel_server_conf
}

#-------------------------------------------------------------------------------
# Check hosts files /etc/hosts.deny /etc/hosts.allow
#-------------------------------------------------------------------------------
check_hosts_files ()
{
  dw_echo_colmsg "==> Check hosts files ..." 1
  (
    if ! grep -qw "rpcbind mountd nfsd statd lockd rquotad:" $hosts_deny_file; then
      echo "rpcbind mountd nfsd statd lockd rquotad:" >> $hosts_deny_file
    fi
    sed -i -e 's/.*rpcbind mountd nfsd statd lockd rquotad:.*$/rpcbind mountd nfsd statd lockd rquotad: ALL/' $hosts_deny_file

    if ! grep -qw "ALL: 127.0.0.0/255.0.0.0" $hosts_allow_file; then
      echo "ALL: 127.0.0.0/255.0.0.0" >> $hosts_allow_file
    fi

    if ! grep -qw "rpcbind mountd nfsd statd lockd rquotad:" $hosts_allow_file; then
      echo "rpcbind mountd nfsd statd lockd rquotad:" >> $hosts_allow_file
    fi
    sed -i -e 's#.*rpcbind mountd nfsd statd lockd rquotad:.*$#rpcbind mountd nfsd statd lockd rquotad: '$NFS_NETWORK_ALLOW'#' $hosts_allow_file
    #dw_echo_colmsg "==> Check host files finished" 3
  )
}

#===============================================================================
# restart-services - Restart Services
#===============================================================================
restart_services ()
{
  do_restart ()
  {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
  do_restart nfs-kernel-server
  do_restart avahi-daemon
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-nfs-server.config

if [ "$1" == "-quiet" ]; then
  quiet="quiet"
else
  quiet=''
fi

check_nfs_kernel_server_conf
check_hosts_files

if [ -f /var/dwsetup/config.d/dw-shares.sh ]; then
  /var/dwsetup/config.d/dw-shares.sh "$quiet" nfs
fi

restart_services

#===============================================================================
# End
#===============================================================================
exit 0
