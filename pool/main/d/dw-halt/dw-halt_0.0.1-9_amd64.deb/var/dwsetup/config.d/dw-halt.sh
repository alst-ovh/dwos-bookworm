#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-halt.sh - Configuration Generator Script for Halt
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

pkg_name='dw-halt'
dwhalt_conf_dir='/etc/dw-halt'
dwhalt_conf_file="$dwhalt_conf_dir/dw-halt.conf"
dwhalt_shutdown_file="$dwhalt_conf_dir/dw-halt-shutdown"

#----------------------------------------------------------------------------------------
# Create Halt Configuration File
#----------------------------------------------------------------------------------------
create_dwhalt_conf_file() {
  dw_echo_colmsg "==> Create Halt Config File $dwhalt_conf_file ..." 2
  (
    echo "NOTIFY_MAIL='$NOTIFY_MAIL'"
    echo "NOTIFY_MAIL_ON_SUCCESS='yes'"
    echo "NOTIFY_MAIL_ON_FAIL='yes'"
    echo
    echo "NOTIFY_TELEGRAM='$NOTIFY_TELEGRAM'"
    echo "NOTIFY_TELEGRAM_ON_SUCCESS='yes'"
    echo "NOTIFY_TELEGRAM_ON_FAIL='yes'"
    echo
    echo "HALT_COUNT='$HALT_COUNT'"
    echo "HALT_SLEEP='$HALT_SLEEP'"
    echo
    if dw_conf_var_is_enabled "$HALT_MAC"; then
      echo "HALT_MAC='$(echo "$HALT_MAC" | tr [:upper:] [:lower:])'"
      echo
    fi
    if dw_conf_var_is_enabled "$HALT_SHELLYPLUG_MASTER"; then
      echo "HALT_SHELLYPLUG_MASTER='$HALT_SHELLYPLUG_MASTER'"
      echo
    fi
    echo "HALT_CHECK_USERS='$HALT_CHECK_USERS'"
    echo
    echo "HALT_CHECK_APPLICATIONS='$HALT_CHECK_APPLICATIONS'"
    echo
    halt_applications_n='0'
    if [ $HALT_APPLICATIONS_N -eq 0 ]; then
      imax=1
    else
      imax=$HALT_APPLICATIONS_N
    fi
    idx=1
    while [ $idx -le $imax ]; do
      eval halt_applications='$HALT_APPLICATIONS_'$idx
      if dw_conf_var_is_enabled "$halt_applications"; then
        halt_applications_n=$(expr $halt_applications_n + 1)
      fi
      idx=$(expr $idx + 1)
    done
    echo "HALT_APPLICATIONS_N='$halt_applications_n'"
    if [ $HALT_APPLICATIONS_N -eq 0 ]; then
      imax=1
    else
      imax=$HALT_APPLICATIONS_N
    fi
    idx=1
    idx_n=1
    while [ $idx -le $imax ]; do
      eval halt_applications='$HALT_APPLICATIONS_'$idx
      if dw_conf_var_is_enabled "$halt_applications"; then
        echo "HALT_APPLICATIONS_"$idx_n"=""'$halt_applications'"
        idx_n=$(expr $idx_n + 1)
      fi
      idx=$(expr $idx + 1)
    done
    echo

    halt_ports_param=''
    if [ $HALT_PORTS_N -eq 0 ]; then
      imax=1
    else
      imax=$HALT_PORTS_N
    fi
    idx=1
    while [ $idx -le $imax ]; do
      eval halt_ports='$HALT_PORTS_'$idx
      if dw_conf_var_is_enabled "$halt_ports"; then
        if [ -n "$halt_ports_param" ]; then
          halt_ports_param="$halt_ports_param -i :$halt_ports"
        else
          halt_ports_param="-i :$halt_ports"
        fi
      fi
      idx=$(expr $idx + 1)
    done
    echo "HALT_PORTS='$halt_ports_param'"

    ### PORTS

    echo
    halt_hosts_n='0'
    if [ $HALT_HOSTS_N -eq 0 ]; then
      imax=1
    else
      imax=$HALT_HOSTS_N
    fi
    idx=1
    while [ $idx -le $imax ]; do
      eval halt_hosts='$HALT_HOSTS_'$idx
      if dw_conf_var_is_enabled "$halt_hosts"; then
        halt_hosts_n=$(expr $halt_hosts_n + 1)
      fi
      idx=$(expr $idx + 1)
    done
    echo "HALT_HOSTS_N='$halt_hosts_n'"
    if [ $HALT_HOSTS_N -eq 0 ]; then
      imax=1
    else
      imax=$HALT_HOSTS_N
    fi
    idx=1
    idx_n=1
    while [ $idx -le $imax ]; do
      eval halt_hosts='$HALT_HOSTS_'$idx
      if dw_conf_var_is_enabled "$halt_hosts"; then
        echo "HALT_HOSTS_"$idx_n"=""'$halt_hosts'"
        idx_n=$(expr $idx_n + 1)
      fi
      idx=$(expr $idx + 1)
    done
  ) >$dwhalt_conf_file
  dw_add_pkg_files "$pkg_name" "$dwhalt_conf_file"
}

#----------------------------------------------------------------------------------------
# Create Halt Shutdown File
#----------------------------------------------------------------------------------------
create_dwhalt_shutdown_file() {
  dw_echo_colmsg "==> Create Halt Shutdown File $dwhalt_shutdown_file ..." 2
  (
    echo "#!/bin/bash"
    echo
  ) >$dwhalt_shutdown_file
  if dw_conf_var_is_enabled "$HALT_MAC"; then
    (
      echo "wakeonlan $(dwrmac $HALT_MAC)"
      echo
    ) >>$dwhalt_shutdown_file
  fi

  chmod 0744 $dwhalt_shutdown_file
  dw_add_pkg_files "$pkg_name" "$dwhalt_shutdown_file"
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/dw-halt.config
. /var/dwsetup/bin/setup-functions

create_dwhalt_conf_file
create_dwhalt_shutdown_file

#===============================================================================
# End
#===============================================================================
exit 0
