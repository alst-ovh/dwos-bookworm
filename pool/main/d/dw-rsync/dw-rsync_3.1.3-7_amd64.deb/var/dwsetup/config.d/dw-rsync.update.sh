#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-rsync.update.sh - Update or Generate New Rsync Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  17.06.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-rsync.config'
config_header='/var/dwsetup/header/dw-rsync.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "  ==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_var "RSYNC_MAX_CONNECTIONS"
    dw_conf_comment "# Max Connections"
    echo
    dw_conf_var "NOTIFY_MAIL"
    dw_conf_comment "# Send Mail yes or no"
    dw_conf_var "NOTIFY_MAIL_ON_SUCCESS"
    dw_conf_comment "# Send Mail on Success yes or no"
    dw_conf_var "NOTIFY_MAIL_ON_FAIL"
    dw_conf_comment "# Send Mail on Error yes or no"
    echo
    dw_conf_var "NOTIFY_TELEGRAM"
    dw_conf_comment "# Send Telegram Message yes or no"
    dw_conf_var "NOTIFY_TELEGRAM_ON_SUCCESS"
    dw_conf_comment "# Send Telegram Message on Success yes or no"
    dw_conf_var "NOTIFY_TELEGRAM_ON_FAIL"
    dw_conf_comment "# Send Telegram Message on Error yes or no"
    echo
    dw_conf_line
    echo "# Rsync: Area Settings"
    echo "#"
    echo "# (Prefix a RSYNC_SCRIPT_x_NAME with a ! to Disable it)"
    echo "# (Prefix a RSYNC_SCRIPT_x_EXCLUDE_x with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "RSYNC_N"
    dw_conf_comment "# Number of Areas"
    if [ $RSYNC_N -eq 0 ]
    then
      imax=1
    else
      imax=$RSYNC_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval name='$RSYNC_'$idx'_NAME'
      eval path='$RSYNC_'$idx'_PATH'
      eval hosts_allow='$RSYNC_'$idx'_HOSTS_ALLOW'
      eval hosts_deny='$RSYNC_'$idx'_HOSTS_DENY'
      eval list='$RSYNC_'$idx'_LIST'
      eval read_only='$RSYNC_'$idx'_READ_ONLY'
      eval comment='$RSYNC_'$idx'_COMMENT'
      eval user_n='$RSYNC_'$idx'_USER_N'
      echo "RSYNC_"$idx"_NAME=""'$name'"
      echo "RSYNC_"$idx"_PATH=""'$path'"

      echo "RSYNC_"$idx"_HOSTS_ALLOW=""'$hosts_allow'"
      echo "RSYNC_"$idx"_HOSTS_DENY=""'$hosts_deny'"
      echo "RSYNC_"$idx"_LIST=""'$list'"
      echo "RSYNC_"$idx"_READ_ONLY=""'$read_only'"
      echo "RSYNC_"$idx"_COMMENT=""'$comment'"
      echo "RSYNC_"$idx"_USER_N=""'$user_n'"
      if [ -n "$user_n" -a "$user_n" -gt "0" ]; then
        imaxu=$user_n
        idxu=1
        while [ $idxu -le $imaxu ]
        do
          eval user='$RSYNC_'$idx'_USER_'$idxu
          eval passwd='$RSYNC_'$idx'_USER_'$idxu'_PASSWD'
          echo "RSYNC_"$idx"_USER_"$idxu"=""'$user'"
          echo "RSYNC_"$idx"_USER_"$idxu"_PASSWD=""'$passwd'"
          idxu=$(expr $idxu + 1)
        done
      fi
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_line
    echo "# Rsync: Scripts Settings"
    echo "#"
    echo "# (Prefix a RSYNC_SCRIPT_x_NAME with a ! to Disable it)"
    echo "# (Prefix a RSYNC_SCRIPT_x_EXCLUDE_x with a ! to Disable it)"
    echo "# RSYNC_SCRIPT_x_CRON (hourly, daily, weekly, monthly, leave it empty for no CRON)"
    dw_conf_line
    echo
    dw_conf_var "RSYNC_SCRIPT_CRON"
    dw_conf_comment "# Running Rsync Scripts via Cron yes or no"
    echo
    dw_conf_var "RSYNC_SCRIPT_N"
    dw_conf_comment "# Number of Scripts"
    if [ $RSYNC_SCRIPT_N -eq 0 ]
    then
      imax=1
    else
      imax=$RSYNC_SCRIPT_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval name='$RSYNC_SCRIPT_'$idx'_NAME'
      eval param='$RSYNC_SCRIPT_'$idx'_PARAM'
      eval host_dir='$RSYNC_SCRIPT_'$idx'_HOST_DIR'
      eval to_dir='$RSYNC_SCRIPT_'$idx'_TO_DIR'
      eval secrets='$RSYNC_SCRIPT_'$idx'_SECRETS'
      eval exclude_n='$RSYNC_SCRIPT_'$idx'_EXCLUDE_N'
      eval cron='$RSYNC_SCRIPT_'$idx'_CRON'
      eval halt='$RSYNC_SCRIPT_'$idx'_HALT'
      echo "RSYNC_SCRIPT_"$idx"_NAME=""'$name'"
      echo "RSYNC_SCRIPT_"$idx"_PARAM=""'$param'"
      echo "RSYNC_SCRIPT_"$idx"_HOST_DIR=""'$host_dir'"
      echo "RSYNC_SCRIPT_"$idx"_TO_DIR=""'$to_dir'"
      echo "RSYNC_SCRIPT_"$idx"_SECRETS=""'$secrets'"
      echo "RSYNC_SCRIPT_"$idx"_EXCLUDE_N=""'$exclude_n'"
      idxa=1
      while [ "$idxa" -le "$exclude_n" ]
      do
        eval exclude='$RSYNC_SCRIPT_'$idx'_EXCLUDE_'$idxa
        echo "RSYNC_SCRIPT_"$idx"_EXCLUDE_"$idxa"=""'$exclude'"
        idxa=$(expr $idxa + 1)
      done
      echo "RSYNC_SCRIPT_"$idx"_CRON=""'$cron'"
      echo "RSYNC_SCRIPT_"$idx"_HALT=""'$halt'"
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_line
    echo "# Rsync: Log Rotate Settings"
    dw_conf_line
    echo
    dw_conf_var "RSYNC_LOG_ROTATE"
    dw_conf_comment "# Rotate Log Files using Logrotate yes or no"
    dw_conf_var "RSYNC_MAX_LOGSIZE"
    dw_conf_comment "# Log Files are Rotated when they"
    dw_conf_comment "# Grow Bigger then RSYNC_MAX_LOGSIZE Bytes"
    dw_conf_comment "# Possible Values xxx, xxxk or xxxM"
    dw_conf_comment "# xxx Size in Bytes"
    dw_conf_comment "# xxxk Size in Kilobytes"
    dw_conf_comment "# xxxM Size in Megabyte"
    dw_conf_var "RSYNC_LOG_COUNT"
    dw_conf_comment "# Number of Log Files to Save"
    dw_conf_footer e
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
