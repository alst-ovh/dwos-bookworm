#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-base.update.sh - Update or Generate New Base Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-base.config'
config_header='/var/dwsetup/header/dw-base.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables() {
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for Renamed Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables() {
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables() {
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ -z "$DATA_DIR" ]; then
    DATA_DIR='/data'
  fi

  if [ -z "$JOURNALD_SYSTEMMAXUSE" ]; then
    JOURNALD_SYSTEMMAXUSE='200M'
  fi

  if [ $added -eq 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables() {
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]; then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]; then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config() {
  function check_entry() {
    # $1 varname
    # $2 min
    # $3 max
    # $4 default
    local __resultvar=$1
    local __resultvalue=${!1}
    if [[ ${__resultvalue} =~ ^[0-9]+$ ]]; then
      if [ $__resultvalue -lt $2 -o $__resultvalue -gt $3 ]; then
        eval $__resultvar="$4"
      fi
    else
      eval $__resultvar="$4"
    fi
  }

  check_entry "CRON_HOURLY_MINUTE" 0 59 17

  check_entry "CRON_DAILY_MINUTE" 0 59 25
  check_entry "CRON_DAILY_HOUR" 0 23 3

  check_entry "CRON_WEEKLY_MINUTE" 0 59 47
  check_entry "CRON_WEEKLY_HOUR" 0 23 3
  check_entry "CRON_WEEKLY_DAYOFWEEK" 0 7 7

  check_entry "CRON_MONTHLY_MINUTE" 0 59 52
  check_entry "CRON_MONTHLY_HOUR" 0 23 3
  check_entry "CRON_MONTHLY_DAYOFMONTH" 1 31 1

  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header >$generate_conf
  (
    dw_conf_line
    echo "# Data Config"
    dw_conf_line
    echo
    dw_conf_var "DATA_DIR"
    dw_conf_comment "# Main Data Directory"
    dw_conf_comment "# After changing the DATA_DIR, you have to take care of the data movement yourself !!!"
    echo
    dw_conf_var "USERS_HOME_DIR"
    dw_conf_comment "# Main User Home Directory, if USERS_HOME_DIR='' then DATA_DIR is used"
    dw_conf_comment "# After changing the DATA_DIR or the USERS_HOME_DIR, you have to take care of the data movement yourself !!!"
    echo
    dw_conf_line
    echo "# dwsetup Backup Config"
    dw_conf_line
    echo
    dw_conf_var "BACKUP_CONFIG_MAIL"
    dw_conf_comment "# Mail Config Backup yes or no"
    echo
    dw_conf_var "BACKUP_CONFIG_PASSWD"
    dw_conf_comment "# dwsetup Backup Config Password"
    echo
    dw_conf_line
    echo "# apt Check Update(s) Notify Config"
    dw_conf_line
    echo
    dw_conf_var "APT_NOTIFY_MAIL"
    dw_conf_comment "# Mail Update(s) Notify yes or no"
    echo
    dw_conf_var "APT_NOTIFY_TELEGRAM"
    dw_conf_comment "# Telegram Update(s) Notify  yes or no"
    echo
    dw_conf_line
    echo "# Grub Parameter"
    dw_conf_line
    echo
    dw_conf_var "GRUB_PARAMETER"
    dw_conf_comment "# Grub Parameter list separated with spaces, entries can be disabled with !"
    echo
    dw_conf_line
    echo "# Modules Blacklist"
    dw_conf_line
    echo
    dw_conf_var "MODULE_BLACKLIST"
    dw_conf_comment "# Modules Blacklist list separated with spaces, entries can be disabled with !"
    echo
    dw_conf_line
    echo "# Localization"
    dw_conf_line
    echo
    dw_conf_var "LOCALE"
    dw_conf_comment "# Locale /etc/default/locale, found in /usr/local/share/i18n/SUPPORTED"
    echo
    dw_conf_var "KEYBOARD_XKBMODEL"
    dw_conf_var "KEYBOARD_XKBLAYOUT"
    dw_conf_var "KEYBOARD_XKBVARIANT"
    dw_conf_var "KEYBOARD_XKBOPTIONS"
    dw_conf_var "KEYBOARD_BACKSPACE"
    dw_conf_comment "# Keyboard /etc/default/keyboard"
    echo
    dw_conf_var "TIMEZONE"
    dw_conf_comment "# Timezones are found in /usr/share/zoneinfo"
    echo
    dw_conf_line
    echo "# Hostname"
    dw_conf_line
    echo
    dw_conf_var "HOSTNAME"
    dw_conf_comment "# Your Hostname"
    echo
    dw_conf_line
    echo "# Network"
    dw_conf_line
    echo
    dw_conf_var "NET_DHCP"
    dw_conf_comment "# DHCP yes or no"
    echo
    dw_conf_var "NET_INTERFACE"
    dw_conf_var "NET_ADDRESS"
    dw_conf_var "NET_NETMASK"
    dw_conf_var "NET_GATEWAY"
    dw_conf_var "NET_WOL"
    echo
    dw_conf_var "NET_NTP_SERVER"
    echo
    dw_conf_line
    echo "# Domain & DNS Search"
    dw_conf_line
    echo
    dw_conf_var "DOMAIN"
    dw_conf_comment "# Your Domain"
    echo
    dw_conf_var "DNS_SEARCH"
    dw_conf_comment "# DNS Search Domain(s) list of 3 separated with spaces, entries can be disabled with !"
    echo
    dw_conf_var "DNS_SERVER"
    dw_conf_comment "# DNS Server(s) list of 3 separated with spaces, entries can be disabled with !"
    echo
    dw_conf_line
    echo "# Cron"
    dw_conf_line
    echo
    dw_conf_var "CRON_HOURLY_MINUTE"
    dw_conf_comment "# Hourly Minute 0-59"
    echo
    dw_conf_var "CRON_DAILY_MINUTE"
    dw_conf_comment "# Daily Minute 0-59"
    dw_conf_var "CRON_DAILY_HOUR"
    dw_conf_comment "# Daily Hour 0-23"
    echo
    dw_conf_var "CRON_WEEKLY_MINUTE"
    dw_conf_comment "# Weekly Minute 0-59"
    dw_conf_var "CRON_WEEKLY_HOUR"
    dw_conf_comment "# Weekly Hour 0-23"
    dw_conf_var "CRON_WEEKLY_DAYOFWEEK"
    dw_conf_comment "# Weekly Day of Week 0-6 Sunday=0 or 7"
    echo
    dw_conf_var "CRON_MONTHLY_MINUTE"
    dw_conf_comment "# Monthly Minute 0-59"
    dw_conf_var "CRON_MONTHLY_HOUR"
    dw_conf_comment "# Monthly Hour 0-23"
    dw_conf_var "CRON_MONTHLY_DAYOFMONTH"
    dw_conf_comment "# Monthly Day of Month 1-31"
    echo
    dw_conf_line
    echo "# Journald Logging"
    dw_conf_line
    echo
    dw_conf_var "JOURNALD_SYSTEMMAXUSE"
    dw_conf_comment "# Limit Maximum Disk use in M=Megabytes, G=Gigabytes"
    echo
    dw_conf_line
    echo "# Others"
    dw_conf_line
    echo
    dw_conf_var "SSH_PORT"
    dw_conf_comment "# SSH Port if empty defaults to 22"
    echo
    dw_conf_var "SSH_ROOT_LOGIN"
    dw_conf_comment "# SSH Root Login yes or no"
    echo
    dw_conf_var "SSH_ALLOW_USERS"
    dw_conf_comment "# SSH Users Allowed to Login, list with space user1 user2"
    echo
    dw_conf_var "SWAPFILE_SIZE"
    dw_conf_comment "# Set Swapfile Size in Megabytes"
    echo
    dw_conf_var "VM_SWAPPINESS"
    dw_conf_comment "# Change swappiness from 0 to 100, default is 60, to decrease swap usage, if VM_SWAPPINESS='' then defaults to 60"
    echo
    dw_conf_var "GETTY_CLEARSCREEN"
    dw_conf_comment "# Set Clear Screen yes or no"
    echo
    dw_conf_var "NUMLOCK"
    dw_conf_comment "# Numlock on or off"
    echo
    dw_conf_var "SHUTDOWN_CTRLALTDEL"
    dw_conf_comment "# Shutdown with Keys CRTL+ALT+DEL yes or no"
    echo
    dw_conf_var "BEEP_ENABLE"
    dw_conf_comment "# Enable Beep yes or no"
    echo
    dw_conf_var "DISABLE_POWER_MANAGEMENT"
    dw_conf_comment "# Enable Power Management, sleep,suspend,hibernate yes or no"
    echo
    dw_conf_var "DISABLE_WLAN"
    dw_conf_comment "# Disable Wlan yes or no"
    echo
    dw_conf_var "DISABLE_BLUETOOTH"
    dw_conf_comment "# Disable Bluetooth yes or no"
    dw_conf_footer e
  ) >>$generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]; then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1" in

update)
  source_conf=$source_conf_file
  generate_conf=$source_conf_file
  goflag=1
  ;;
test)
  source_conf=$source_conf_file
  generate_conf=$source_conf_file.test
  goflag=1
  ;;
*)
  echo
  echo "Use one of the following options:"
  echo
  echo "  $0 [update]"
  echo
  echo "  $source_conf_file will be read"
  echo "  $generate_conf_file configuration file will be written"
  echo "  the configuration will be checked and an updated."
  echo
  goflag=0
  ;;
esac

if [ $goflag -eq 1 ]; then
  if [ -f $source_conf ]; then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
