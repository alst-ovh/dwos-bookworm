#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-printers.update.sh - Update or Generate New Printers Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-printers.config'
config_header='/var/dwsetup/header/dw-printers.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a

    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "  ==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Printers"
    echo "#"
    echo "# (Prefix a PRINTERS_x_NAME with a ! to Disable it)"
    echo "# if PRINTERS_x_PAGESIZE='' then defaults to 'A4'"
    echo "# if PRINTERS_x_SHARE='' then defaults to 'yes'"
    dw_conf_line
    echo
    dw_conf_var "PRINTERS_DEFAULT"
    dw_conf_comment "# Cups Default Printer"
    echo
    dw_conf_var "PRINTERS_N"
    dw_conf_comment "# Cups Printer(s)"
    if [ $PRINTERS_N -eq 0 ]
    then
      imax=1
    else
      imax=$PRINTERS_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval name='$PRINTERS_'$idx'_NAME'
      eval location='$PRINTERS_'$idx'_LOCATION'
      eval info='$PRINTERS_'$idx'_INFO'
      eval driver='$PRINTERS_'$idx'_DRIVER'
      eval device='$PRINTERS_'$idx'_DEVICE'
      eval pagesize='$PRINTERS_'$idx'_PAGESIZE'
      eval share='$PRINTERS_'$idx'_SHARE'
      echo "PRINTERS_"$idx"_NAME=""'$name'"
      echo "PRINTERS_"$idx"_LOCATION=""'$location'"
      echo "PRINTERS_"$idx"_INFO=""'$info'"
      echo "PRINTERS_"$idx"_DRIVER=""'$driver'"
      echo "PRINTERS_"$idx"_DEVICE=""'$device'"
      echo "PRINTERS_"$idx"_PAGESIZE=""'$pagesize'"
      echo "PRINTERS_"$idx"_SHARE=""'$share'"
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_footer
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
