#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-printers.sh - Configuration Generator Script for Printers Settings
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  25.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

DWCUPS_DOCKER_CONTAINER='dw-cups'

# Defaults
default_pagesize='A4'
default_sides='one-sided'
default_shared='yes'

do_docker_cmd() {
  docker exec "$DWCUPS_DOCKER_CONTAINER" bash -c "$1" >/dev/null
}

#-------------------------------------------------------------------------------
# Create Cups Printers
#-------------------------------------------------------------------------------
create_cups_printer() {
  if docker_is_container "$DWCUPS_DOCKER_CONTAINER"; then
    if docker_is_container_running "$DWCUPS_DOCKER_CONTAINER"; then
      dw_echo_colmsg "==> OK: Cups Running" 1
    else
      dw_echo_colmsg "==> Cups not Running Trying to Start ..." 1
      docker start "$DWCUPS_DOCKER_CONTAINER" 2 &>/dev/null
      sleep 2
    fi
  fi
  if docker_is_container_running "$DWCUPS_DOCKER_CONTAINER"; then
    delete_all_printers
    dw_echo_colmsg "==> Create Cups Printer(s) ..." 1
    idx=1
    while [ "$idx" -le "$PRINTERS_N" ]; do
      printer_created='no'
      eval name='$PRINTERS_'$idx'_NAME'
      eval location='$PRINTERS_'$idx'_LOCATION'
      eval info='$PRINTERS_'$idx'_INFO'
      eval driver='$PRINTERS_'$idx'_DRIVER'
      eval device='$PRINTERS_'$idx'_DEVICE'
      eval pagesize='$PRINTERS_'$idx'_PAGESIZE'
      # Check PageSize
      if [ -z "$pagesize" ]; then
        pagesize=$default_pagesize
      fi
      if dw_conf_var_is_enabled "$name"; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Create Printer $name ..." 1
        if [ "$driver" = "" ]; then
          # Raw printer
          result=$(do_docker_cmd "lpadmin -p '$name' -L '$location' -D '$info' -E -v $device -o media=$pagesize" 2>&1)
        else
          result=$(do_docker_cmd "lpadmin -p '$name' -L '$location' -D '$info' -E -v $device -m $driver -o media=$pagesize" 2>&1)
        fi
        if [ $? -eq 0 ]; then
          [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Creating Printer $name Success" 2 o
          printer_created='yes'
        else
          dw_echo_colmsg "==> ERROR: Creating Printer $name Failure !" 2 e
          result=$(echo $result | sed "s/lpadmin: Printer drivers are deprecated and will stop working in a future version of CUPS. //")
          dw_echo_colmsg "$result" 2
        fi

        if dw_conf_var_is_yes "$printer_created"; then

          [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Trying Setting Pagesize $pagesize ..." 2
          do_docker_cmd "lpoptions -p '$name' -o media=$pagesize"
          if [ $? -eq 0 ]; then
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Pagesize $pagesize Success" 3
          else
            dw_echo_colmsg "==> ERROR: Setting Pagesize $pagesize Failure !" 3 e
          fi
          if [ -n "$share" ]; then
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Trying Setting Share $share ..." 2
            do_docker_cmd "lpadmin -p '$name' -o printer-is-shared=$share"
            if [ $? -eq 0 ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Share Success" 3
            else
              dw_echo_colmsg "==> ERROR: Setting Share Failure !" 3 e
            fi
          fi
          if [ "$PRINTERS_DEFAULT" -gt '0' -a "$PRINTERS_DEFAULT" -eq "$idx" ]; then
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Printer $name to Default ..." 2
            do_docker_cmd "lpadmin -d '$name'"
            if [ $? -eq 0 ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Printer $name to Default Success" 3
            else
              dw_echo_colmsg "==> ERROR: Setting Printer $name to Default Failure !" 3 e
            fi
          fi
          dw_echo_colmsg "==> Create Printer $name Finished" 2

        else
          dw_echo_colmsg "==> Create Printer $name Failed !" 1 e
        fi

      else
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Printer PRINTERS_$idx is disabled !" 1 n
      fi
      idx=$(expr $idx + 1)
    done
    dw_echo_colmsg "==> Create Cups Printer(s) Finished" 1
  else
    dw_echo_colmsg "==> Cups Starting Failed !" 1 e
  fi
}

#-------------------------------------------------------------------------------
# Delete All Cups Printers
#-------------------------------------------------------------------------------
delete_all_printers() {
  dw_echo_colmsg "==> Delete All Cups Printer(s) ..." 1
  do_docker_cmd "lpstat -p | cut -d' ' -f2 | xargs -I{} lpadmin -x {}"
}

#-------------------------------------------------------------------------------
# Restart Shares Services
#-------------------------------------------------------------------------------
restart_services() {
  do_restart() {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-printers.config
if [ -f /etc/dwconfig.d/dw-cups.config ]; then
  . /etc/dwconfig.d/dw-cups.config
fi

if [ "$1" == "-quiet" -o "$1" == "quiet" ]; then
  quiet="quiet"
else
  quiet=''
fi

if dw_is_pkg_installed dw-cups; then
  create_cups_printer
else
  dw_echo_colmsg "==> Install dw-cups for Printer Configuration" 1 a
fi

#===============================================================================
# End
#===============================================================================
exit 0
