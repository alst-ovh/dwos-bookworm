#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-shares.update.sh - Update or Generate New Shares Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  25.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-shares.config'
config_header='/var/dwsetup/header/dw-shares.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Renamed Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 1
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Shares"
    echo "#"
    echo "# !!! add insecure for Mac OS to the SHARE_x_NFS_OPTION !!!"
    echo "# (Prefix a Shares Name with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "SHARES_HOME"
    dw_conf_comment "# User Home Share's enabled yes or no"
    echo
    dw_conf_var "SHARES_PUBLIC"
    dw_conf_comment "# Public Share enabled yes or no"
    dw_conf_var "SHARES_PUBLIC_NFS"
    dw_conf_comment "# NFS Public Share enabled yes or no"
    dw_conf_var "SHARES_PUBLIC_NFS_OPTION"
    dw_conf_comment "# Export Option(s)"
    echo
    dw_conf_var "SHARES_N"
    dw_conf_comment "# Number of Shares"
    echo
    if [ $SHARES_N -eq 0 ]
    then
      imax=1
    else
      imax=$SHARES_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval name='$SHARES_'$idx'_NAME'
      eval path='$SHARES_'$idx'_PATH'
      eval comment='$SHARES_'$idx'_COMMENT'
      eval public='$SHARES_'$idx'_PUBLIC'
      eval browseable='$SHARES_'$idx'_BROWSEABLE'
      eval writable='$SHARES_'$idx'_WRITABLE'
      eval users_valid='$SHARES_'$idx'_USERS_VALID'
      eval users_read='$SHARES_'$idx'_USERS_READ'
      eval users_write='$SHARES_'$idx'_USERS_WRITE'
      eval force_user='$SHARES_'$idx'_FORCE_USER'
      eval force_group='$SHARES_'$idx'_FORCE_GROUP'
      eval nfs='$SHARES_'$idx'_NFS'
      eval nfs_option='$SHARES_'$idx'_NFS_OPTION'
      echo "SHARES_"$idx"_NAME=""'$name'"
      echo "SHARES_"$idx"_PATH=""'$path'"
      echo "SHARES_"$idx"_COMMENT=""'$comment'"
      echo "SHARES_"$idx"_PUBLIC=""'$public'"
      echo "SHARES_"$idx"_BROWSEABLE=""'$browseable'"
      echo "SHARES_"$idx"_WRITABLE=""'$writable'"
      echo "SHARES_"$idx"_USERS_VALID=""'$users_valid'"
      echo "SHARES_"$idx"_USERS_READ=""'$users_read'"
      echo "SHARES_"$idx"_USERS_WRITE=""'$users_write'"
      echo "SHARES_"$idx"_FORCE_USER=""'$force_user'"
      echo "SHARES_"$idx"_FORCE_GROUP=""'$force_group'"
      echo "SHARES_"$idx"_NFS=""'$nfs'"
      echo "SHARES_"$idx"_NFS_OPTION=""'$nfs_option'"
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_line
    echo "# Shares NFS Section"
    echo "#"
    echo "# !!! add insecure for Mac OS to the NFS_EXPORTS_x_OPTION !!!"
    echo "# Sample user map export"
    echo "# NFS_EXPORTS_x_OPTION='rw,insecure,anonuid=1000,anongid=1000,all_squash,sync,no_subtree_check'"
    echo "# (Prefix a Path with a ! to Disable it)"
    dw_conf_line
    echo
    dw_conf_var "SHARES_NFS_EXPORTS_N"
    dw_conf_comment "# Number of Export(s)"
    echo
    if [ $SHARES_NFS_EXPORTS_N -eq 0 ]
    then
      imax=1
    else
      imax=$SHARES_NFS_EXPORTS_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval path='$SHARES_NFS_EXPORTS_'$idx'_PATH'
      eval machine='$SHARES_NFS_EXPORTS_'$idx'_MACHINE'
      eval option='$SHARES_NFS_EXPORTS_'$idx'_OPTION'
      echo "SHARES_NFS_EXPORTS_"$idx"_PATH=""'$path'"
      dw_conf_comment "# Export Path"
      echo "SHARES_NFS_EXPORTS_"$idx"_MACHINE=""'$machine'"
      dw_conf_comment "# Export Machine(s), Seperate with ,"
      echo "SHARES_NFS_EXPORTS_"$idx"_OPTION=""'$option'"
      dw_conf_comment "# Export Option(s)"
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_footer
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
