#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-base.sh - Configuration Generator Script for Base Settings
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  25.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

dwbackup_file_hostname=$(hostname -f)

dwbackup_file_date=$(date +"%Y-%m-%d")

dwbackup_file_mail="/root/dwsetup-backup_${dwbackup_file_hostname}_${dwbackup_file_date}.tar"

dwbackup_file_mail_crypt="${dwbackup_file_mail}.cpt"

dwbackup_file_passwd="/etc/dwconfig.d/conf/dwsetup-backup-passwd.conf"

dwbackup_file='/root/dwsetup-backup.tar'

dwbackup_file_last='/root/dwsetup-backup-last.tar'

dwbackup_file_cron='/etc/cron.daily/dwsetup-backup'

dw_release_file="/etc/dawel-release"

getty_file='/lib/systemd/system/getty@.service'

ctrl_alt_del_target_file="/lib/systemd/system/ctrl-alt-del.target"

hostname_file="/etc/hostname"
hosts_file="/etc/hosts"

dnsmasq_sh='/var/dwsetup/config.d/dw-dnsmasq.sh'
pihole_sh='/var/dwsetup/config.d/dw-pihole.sh'

locale_gen_file='/etc/locale.gen'
locale_file='/etc/default/locale'
keyboard_file='/etc/default/keyboard'
timezone_file="/etc/timezone"

dhcpcd_conf_file="/etc/dhcpcd.conf"
interfaces_file="/etc/network/interfaces"
resolv_conf_file="/etc/resolv.conf"

ntp_file='/etc/systemd/timesyncd.conf'

motd_file="/etc/motd"
issue_file="/etc/issue"
issue_file_net="/etc/issue.net"
issue_debian='Debian 12 (bookworm)'

sshd_config_file='/etc/ssh/sshd_config'

crontab_file='/etc/crontab'
crontab_root_file='/var/spool/cron/crontabs/root'

dwsetup_logrotate_file="/etc/logrotate.d/dwsetup"

swapsize_file='/etc/dphys-swapfile'

sysctl_file='/etc/sysctl.conf'

fstab_file='/etc/fstab'

journald_file='/etc/systemd/journald.conf'

dwapt_file_cron='/etc/cron.daily/dwapt-check'

grub_file='/etc/default/grub'
grub_interfaces_file='/etc/default/grub.d/interfaces.cfg'
grub_apparmor_file='/etc/default/grub.d/apparmor.cfg'
grub_dw_param_file='/etc/default/grub.d/dw-grub.cfg'
selinux_config_file='/etc/selinux/config'

modules_blacklist_dw_file='/etc/modprobe.d/dw-blacklist.conf'

services_reconfig_dir='/var/dwsetup/reconfig.d/services'
modprobe_reconfig_dir='/var/dwsetup/reconfig.d/modprobe'

#-------------------------------------------------------------------------------
# Check if IP is Private
#-------------------------------------------------------------------------------
function ip_private() {
  PATTERN='^10\.'         #  10.0.0.0/8
  PATTERN+='|^192\.168\.' # 192.168.0.0/16
  PATTERN+='|^169\.254\.' # not strictly private range, but link local
  for i in $(# 172.16.0.0/12
    seq 16 31
  ); do
    PATTERN+="|^172\.$i\."
  done
  private=$(echo $1 | grep -E "$PATTERN")
  if [ -n "$private" ]; then
    #echo "Private $1"
    return 0
  else
    #echo "Public $1"
    return 1
  fi
}

#-------------------------------------------------------------------------------
# Convert Netmask to Cidr
#-------------------------------------------------------------------------------
function netmask_to_cidr() {
  c=0 x=0$(printf '%o' ${1//./ })
  while [ $x -gt 0 ]; do
    let c+=$((x % 2)) 'x>>=1'
  done
  echo $c
}

#-------------------------------------------------------------------------------
# Set Getty Clear Screen in /lib/systemd/system/getty@.service
#-------------------------------------------------------------------------------
check_getty() {
  dw_echo_colmsg "==> Check Getty Clear Screen $getty_file ..." 1
  getty_cls='no'
  if [ "$GETTY_CLEARSCREEN" = "yes" ]; then
    getty_cls='yes'
  fi
  sed -i -e 's/.*TTYVTDisallocate=.*$/TTYVTDisallocate='$getty_cls'/' $getty_file
  if [ "$GETTY_CLEARSCREEN" = "yes" ]; then
    dw_echo_colmsg "==> Getty Clear Screen Enabled" 2 o
  else
    dw_echo_colmsg "==> Getty Clear Screen Disabled" 2 o
  fi
  systemctl daemon-reload
}

#-------------------------------------------------------------------------------
# Check CTRL+ALT+DEL Entry in /lib/systemd/system/crtl-alt-del.target
#-------------------------------------------------------------------------------
check_crtlaltdel() {
  dw_echo_colmsg "==> Check $ctrl_alt_del_target_file for CTRL+ALT+DEL ..." 1
  if [ "$SHUTDOWN_CTRLALTDEL" = "yes" ]; then
    ln -sf reboot.target $ctrl_alt_del_target_file
    dw_echo_colmsg "==> CTRL+ALT+DEL Enabled" 2 o
  else
    ln -sf /dev/null $ctrl_alt_del_target_file
    dw_echo_colmsg "==> CTRL+ALT+DEL Disabled" 2 o
  fi
  systemctl daemon-reload
}

#-------------------------------------------------------------------------------
# Check Power Management sleep.target suspend.target hibernate.target hybrid-sleep.target
#-------------------------------------------------------------------------------
check_powermanagement() {
  dw_echo_colmsg "==> Check Power Management ..." 1
  if [ "$DISABLE_POWER_MANAGEMENT" != "yes" ]; then
    systemctl unmask sleep.target suspend.target hibernate.target hybrid-sleep.target
    dw_echo_colmsg "==> Power Management Enabled" 2 o
  else
    systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
    dw_echo_colmsg "==> Power Management Disabled" 2 o
  fi
  systemctl daemon-reload
}

#-------------------------------------------------------------------------------
# Check Swap File Size /etc/dphys-swapfile
#-------------------------------------------------------------------------------
check_swapfilesize() {
  dw_echo_colmsg "==> Check Swapfile Size ..." 1
  if [ -n "$SWAPFILE_SIZE" ]; then
    swapfile_size=$(cat "$swapsize_file" | grep ^CONF_SWAPSIZE | cut -d '=' -f 2)
    if [ "$SWAPFILE_SIZE" != "$swapfile_size" ]; then
      dw_echo_colmsg "==> Swapfile Size $swapfile_size is not equal, generate new with $SWAPFILE_SIZE ..." 2 o
      dphys-swapfile swapoff
      sed -i -e 's/.*CONF_SWAPSIZE=.*$/CONF_SWAPSIZE='$SWAPFILE_SIZE'/' $swapsize_file
      dphys-swapfile setup
      dphys-swapfile swapon
    else
      dw_echo_colmsg "==> Swapfile Size $swapfile_size is equal, nothing to to ..." 2 o
    fi
  else
    dw_echo_colmsg "==> SWAPFILE_SIZE in Config is empty, nothing to to ..." 2 o
  fi
}

#-------------------------------------------------------------------------------
# Check vm.swappinnes /etc/sysctl_file
#-------------------------------------------------------------------------------
check_vm_swapinnes() {
  dw_echo_colmsg "==> Check vm.swapinnes Entry ..." 1
  if [ -z "$VM_SWAPPINESS" ]; then
    VM_SWAPPINESS=60
  fi
  if ! grep -qw "vm.swappiness" $sysctl_file; then
    echo "vm.swappiness=$VM_SWAPPINESS" >>$sysctl_file
  else
    sed -i -e 's/.*vm.swappiness=.*$/vm.swappiness='"$VM_SWAPPINESS"'/' $sysctl_file
  fi
  dw_echo_colmsg "==> vm.swappinnes is $VM_SWAPPINESS" 2 o
  sysctl -p &>/dev/null
  systemctl restart dphys-swapfile
}

#-------------------------------------------------------------------------------
# Check Grub Settings apparmor /etc/default/grub.d/dw-grub.cfg
#-------------------------------------------------------------------------------
check_grub_settings() {
  if ! grep -qw "^GRUB_TIMEOUT=0" $grub_file; then
    sed -i -e 's/.*GRUB_TIMEOUT=.*$/GRUB_TIMEOUT=0/' $grub_file
  fi
  sed -i -e 's/.*GRUB_CMDLINE_LINUX_DEFAULT=.*$/GRUB_CMDLINE_LINUX_DEFAULT=""/' $grub_file
  # Interface Names
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Grub Interface Naming Disable ..." 1
  echo 'GRUB_CMDLINE_LINUX_DEFAULT="$GRUB_CMDLINE_LINUX_DEFAULT net.ifnames=0 biosdevname=0"' > $grub_interfaces_file
  # Disable apparmor
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Grub Apparmor Disable ..." 1
  echo 'GRUB_CMDLINE_LINUX_DEFAULT="$GRUB_CMDLINE_LINUX_DEFAULT apparmor=0"' > $grub_apparmor_file
  # Disable selinux
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Grub Selinux Disable ..." 1
  (
   echo 'SELINUX=disabled'
   echo 'SELINUXTYPE=targeted'
  ) > $selinux_config_file
  # Grub Parameter
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Grub Parameter Settings ..." 1
  local params=''
  for param in $GRUB_PARAMETER; do
     if dw_conf_var_is_enabled "$param"; then
       if [ -n "$params" ]; then
         params+=" $param"
       else
         params="$param"
       fi
     fi
  done
  if [ -n "$params" ]; then
    echo 'GRUB_CMDLINE_LINUX_DEFAULT="$GRUB_CMDLINE_LINUX_DEFAULT '$params'"' > $grub_dw_param_file
  else
    rm -f "$grub_dw_param_file"
  fi
  update-grub &>/dev/null
}

#-------------------------------------------------------------------------------
# Check Modules Blacklist File /etc/modprobe.d/dw-blacklist.conf
#-------------------------------------------------------------------------------
check_modules_blacklist_file() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Modules Blacklist $modules_blacklist_dw_file ..." 1
  :>"$modules_blacklist_dw_file"
  for module in $MODULE_BLACKLIST; do
    if dw_conf_var_is_enabled "$module"; then
      echo "blacklist $module" >>"$modules_blacklist_dw_file"
    fi
  done
}

#-------------------------------------------------------------------------------
# Check fstab File /etc/fstab
#-------------------------------------------------------------------------------
check_fstab_file() {
  [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check fstab $fstab_file ..." 1
  if [ "$FSTAB_ASYNC" = "yes" ]; then
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: fstab async is enabled..." 2 o
    sed -ie '/^[^#].*UUID/s/,async//g' $fstab_file
    sed -ie '/^[^#].*UUID/s/async,//g' $fstab_file
    sed -ie '/^[^#].*UUID/s/async//g' $fstab_file
    sed -ie '/^[^#].*UUID/s/,sync//g' $fstab_file
    sed -ie '/^[^#].*UUID/s/sync,//g' $fstab_file
    sed -ie '/^[^#].*UUID/s/sync//g' $fstab_file
    sed -ie '/^[^#].*UUID/s/defaults/defaults,async/g' $fstab_file
  else
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: fstab async is disabled !" 2 o
  fi
}

#-------------------------------------------------------------------------------
# Check Numlock Service
#-------------------------------------------------------------------------------
check_numlock() {
  dw_echo_colmsg "==> Check Numlock ..." 1
  if [ "$NUMLOCK" = "yes" ]; then
    dw_sctl_enable numlock
    dw_echo_colmsg "==> Numlock Enabled" 2 o
  else
    dw_sctl_disable numlock
    dw_echo_colmsg "==> Numlock Disabled" 2 o
  fi
  dw_sctl_reload
}

#-------------------------------------------------------------------------------
# Set Hostname /etc/hostname
#-------------------------------------------------------------------------------
check_hostname() {
  dw_echo_colmsg "==> Check Hostname File $hostname_file ..." 1
  dw_echo_colmsg "==> Setting Hostname to $HOSTNAME" 2 o
  echo $HOSTNAME >$hostname_file
  chmod 0644 $hostname_file
  hostname -F /etc/hostname
}

#-------------------------------------------------------------------------------
# Set Hostname /etc/hosts
#-------------------------------------------------------------------------------
check_hosts() {
  dw_echo_colmsg "==> Check Hosts File $hosts_file ..." 1
  if [ -f "$dnsmasq_sh" -o -f "$pihole_sh" ]; then
    dw_echo_colmsg "==> PiHole or Dnsmasq found, Nothing do to ..." 2 o
  else
    dw_echo_colmsg "==> Create Hosts File" 2 o
    (
      echo "127.0.0.1	localhost"
      #echo "127.0.1.1	$HOSTNAME.$DOMAIN	$HOSTNAME"
      echo
      echo "# The following lines are desirable for IPv6 capable hosts"
      echo "::1     localhost ip6-localhost ip6-loopback"
      echo "ff02::1 ip6-allnodes"
      echo "ff02::2 ip6-allrouters"
    ) >$hosts_file
    chmod 0644 $hosts_file
  fi
}

#-------------------------------------------------------------------------------
# Set Timezone /etc/timezone
#-------------------------------------------------------------------------------
check_timezone() {
  dw_echo_colmsg "==> Check Timezone ..." 1
  if ! grep -qw "$TIMEZONE" $timezone_file; then
    dw_echo_colmsg "==> Setting Timezone to $TIMEZONE" 2 o
    echo $TIMEZONE >$timezone_file
    chmod 0644 $timezone_file
    if [ -L /etc/localtime ]; then
      rm /etc/localtime
    fi
    dpkg-reconfigure --frontend noninteractive tzdata
  else
    dw_echo_colmsg "==> Timezone nothing do to" 2 o
  fi
}

#-------------------------------------------------------------------------------
# Set Network /etc/network/interfaces /etc/resolv.conf
#-------------------------------------------------------------------------------
check_network ()
{
  dw_echo_colmsg "==> Check Network ..." 1
  interface_restart="no"
  interface="$NET_INTERFACE"
  if [ -z "$interface" ]; then
    interface='eth0'
  fi
    interface="$NET_INTERFACE"
    if [ -z "$interface" ]; then
      interface='eth0'
    fi
    if ! grep -qw "^allow-hotplug $interface" $interfaces_file; then
       echo "allow-hotplug $interface" >> $interfaces_file
    fi
    if ! grep -qw "^iface $interface inet" $interfaces_file; then
       echo "iface $interface inet dhcp" >> $interfaces_file
    fi
  if [ ! -z $interface ]; then
    if [ "$NET_DHCP" = "yes" ]; then
      if ! grep -qw "^iface $interface inet dhcp" $interfaces_file; then
        sed -i -e '/.*address.*$/d' $interfaces_file
        sed -i -e '/.*netmask.*$/d' $interfaces_file
        sed -i -e '/.*gateway.*$/d' $interfaces_file
        sed -i -e 's/.*iface '$interface'.*$/iface '$interface' inet dhcp/' $interfaces_file
        sed -i -e '/.*up.*$/d' $interfaces_file
        sed -i -e '/.*down.*$/d' $interfaces_file
        interface_restart="yes"
      else
        dw_echo_colmsg "==> Network nothing do to" 2
      fi
      dw_echo_colmsg "==> Interface $interface configured with DHCP" 2 o
    else
      if ! grep -qw "^iface $interface inet static" $interfaces_file ||
      ! grep -qw "^ address $NET_ADDRESS" $interfaces_file ||
      ! grep -qw "^ netmask $NET_NETMASK" $interfaces_file ||
      ! grep -qw "^ gateway $NET_GATEWAY" $interfaces_file; then
        sed -i -e 's/.*iface '$interface'.*$/iface '$interface' inet static/' $interfaces_file
        sed -i -e '/.*address.*$/d' $interfaces_file
        sed -i -e '/.*netmask.*$/d' $interfaces_file
        sed -i -e '/.*gateway.*$/d' $interfaces_file
        echo " address $NET_ADDRESS" >> $interfaces_file
        echo " netmask $NET_NETMASK" >> $interfaces_file
        echo " gateway $NET_GATEWAY" >> $interfaces_file
        interface_restart="yes"
      else
        dw_echo_colmsg "==> Network nothing do to" 2
      fi
      dw_echo_colmsg "==> Interface $interface configured Static" 2 o
    fi
    sed -i -e '/.*post-up.*$/d' $interfaces_file
    sed -i -e '/.*post-down.*$/d' $interfaces_file
    if [ "$NET_WOL" = "yes" ]; then
      dw_echo_colmsg "==> Enable WOL on Interface $interface ..." 2 o
      #echo " post-up /usr/sbin/ethtool -s \$IFACE wol gu" >> $interfaces_file
      #echo " post-down /usr/sbin/ethtool -s \$IFACE wol gu" >> $interfaces_file
      echo " post-up /usr/sbin/ethtool -s \$IFACE wol g" >> $interfaces_file
      echo " post-down /usr/sbin/ethtool -s \$IFACE wol g" >> $interfaces_file
    else
      dw_echo_colmsg "==> Disabled WOL on Interface $interface ..." 2
    fi
    dw_echo_colmsg "==> Create $resolv_conf_file ..." 2
    if [ "$NET_DHCP" = "yes" ]; then
      :>$resolv_conf_file
      dhclient -r 2>/dev/null
      dhclient 2>/dev/null
    else
      (
      local dns_search=''
      for dnssearch in $DNS_SEARCH; do
       if dw_conf_var_is_enabled "$dnssearch"; then
         if [ -n "$dns_search" ]; then
           dns_search+=" $dnssearch"
         else
           dns_search="$dnssearch"
         fi
       fi
      done
      echo "search $dns_search"
      for dnsserver in $DNS_SERVER; do
       if dw_conf_var_is_enabled "$dnsserver"; then
         echo "nameserver $dnsserver"
       fi
      done
      ) >$resolv_conf_file
    fi
    if [ "$interface_restart" = "yes" ]; then
      chmod 0644 $interfaces_file
      chmod 0644 $resolv_conf_file
      #ifdown $interface 2>/dev/null && ifup $interface 2>/dev/null
      dw_sctl_restart networking
    fi
  else
    dw_echo_colmsg "==> ERROR: No Interface found !!!" 1 e
  fi
  #dw_echo_colmsg "==> Check Network finished" 1
}

#-------------------------------------------------------------------------------
# Set NTP /etc/systemd/timesyncd.conf
#-------------------------------------------------------------------------------
check_ntp() {
  dw_echo_colmsg "==> Check NTP $ntp_file ..." 1
  sed -i -e 's/^NTP=.*$/NTP='"$NET_NTP_SERVER"'/' $ntp_file
  sed -i -e 's/^#NTP=.*$/NTP='"$NET_NTP_SERVER"'/' $ntp_file
  dw_echo_colmsg "==> NTP set to $NET_NTP_SERVER" 2 o
  timedatectl set-ntp true
  dw_sctl_restart systemd-timesyncd
}

#-------------------------------------------------------------------------------
# Set Keyboard /etc/default/locale
#-------------------------------------------------------------------------------
check_locale() {
  dw_echo_colmsg "==> Check Locale $locale_file ..." 1
  if grep -qw "^$LOCALE" $locale_gen_file; then
    dw_echo_colmsg "==> Locale $LOCALE enabled, nothing do to ..." 2 o
  else
    locale_short=$(echo $LOCALE | cut -d " " -f 1)
    dw_echo_colmsg "==> Locale $LOCALE not enabled, setting to $locale_short ..." 2 o
    echo "locales locales/default_environment_locale select $locale_short" | debconf-set-selections
    echo "locales locales/locales_to_be_generated multiselect $LOCALE" | debconf-set-selections
    if [ -f /etc/locale.gen ]; then
      rm /etc/locale.gen
    fi
    dpkg-reconfigure --frontend noninteractive locales
  fi
  source ~/.bashrc
}

#-------------------------------------------------------------------------------
# Set Keyboard /etc/default/keyboard
#-------------------------------------------------------------------------------
check_keyboard() {
  dw_echo_colmsg "==> Check Keyboard $keyboard_file ..." 1
  (
    echo 'XKBMODEL="'$KEYBOARD_XKBMODEL'"'
    echo 'XKBLAYOUT="'$KEYBOARD_XKBLAYOUT'"'
    echo 'XKBVARIANT="'$KEYBOARD_XKBVARIANT'"'
    echo 'XKBOPTIONS="'$KEYBOARD_XKBOPTIONS'"'
    echo 'BACKSPACE="'$KEYBOARD_BACKSPACE'"'
  ) >$keyboard_file
  dw_sctl_restart keyboard-setup
}

#-------------------------------------------------------------------------------
# Copy .bashrc files /root/.bashrc /etc/skel/.bashrc
#-------------------------------------------------------------------------------
check_bashrc() {
  dw_echo_colmsg "==> Copy bashrc files ..." 1
  cp /etc/dwconfig.d/share/skel/.bashrc_root /root/.bashrc
  chown root:root /root/.bashrc
  chmod 0644 /root/.bashrc
  cp /etc/dwconfig.d/share/skel/.bashrc_skel /etc/skel/.bashrc
  chown root:root /etc/skel/.bashrc
  chmod 0644 /etc/skel/.bashrc
  dw_echo_colmsg "==> Copy bashrc files finished" 2 o
}

#-------------------------------------------------------------------------------
# Check SSH Config $sshd_config_file
#-------------------------------------------------------------------------------
check_sshd() {
  dw_echo_colmsg "==> Check SSH Config $sshd_config_file ..." 1
  if ([ -z "$SSH_PORT" ] || [ "$SSH_PORT" = "22" ]); then
    dw_echo_colmsg "==> SSH Port default 22" 2 o
    ssh_port='#Port 22'
  else
    dw_echo_colmsg "==> SSH Port = $SSH_PORT" 2 o
    ssh_port="Port $SSH_PORT"
  fi
  if grep -qw "^#Port" $sshd_config_file; then
    sed -i -e "s/^#Port.*/$ssh_port/" $sshd_config_file
  else
    if grep -qw "^Port" $sshd_config_file; then
      sed -i -e "s/^Port.*$/$ssh_port/" $sshd_config_file
    else
      echo "$ssh_port" >>$sshd_config_file
    fi
  fi
  if [ "$SSH_ROOT_LOGIN" = "yes" ]; then
    dw_echo_colmsg "==> SSH root Login Enabled" 2 o
    ssh_rootlogin='PermitRootLogin yes'
  else
    dw_echo_colmsg "==> SSH root Login Disabled" 2 o
    ssh_rootlogin='#PermitRootLogin prohibit-password'
  fi
  if grep -qw "^#PermitRootLogin" $sshd_config_file; then
    sed -i -e "s/^#PermitRootLogin.*/$ssh_rootlogin/" $sshd_config_file
  else
    if grep -qw "^PermitRootLogin" $sshd_config_file; then
      sed -i -e "s/^PermitRootLogin.*$/$ssh_rootlogin/" $sshd_config_file
    else
      echo "$ssh_rootlogin" >>$sshd_config_file
    fi
  fi
  SSH_ALLOW_USERS=${SSH_ALLOW_USERS/root/}
  if [ -n "$SSH_ALLOW_USERS" ]; then
    if [ "$SSH_ROOT_LOGIN" = "yes" ]; then
      SSH_ALLOW_USERS="root $SSH_ALLOW_USERS"
    fi
  else
    if [ "$SSH_ROOT_LOGIN" = "yes" ]; then
      SSH_ALLOW_USERS="root"
    fi
  fi
  dw_echo_colmsg "==> SSH Allowed Users: $SSH_ALLOW_USERS" 2 o
  if grep -qw "^#AllowUsers" $sshd_config_file; then
    sed -i -e "s/^#AllowUsers.*/AllowUsers $SSH_ALLOW_USERS/" $sshd_config_file
  else
    if grep -qw "^AllowUsers" $sshd_config_file; then
      sed -i -e "s/^AllowUsers.*$/AllowUsers $SSH_ALLOW_USERS/" $sshd_config_file
    else
      echo "AllowUsers $SSH_ALLOW_USERS" >>$sshd_config_file
    fi
  fi
  dw_sctl_enable ssh
  dw_sctl_restart ssh
}

#-------------------------------------------------------------------------------
# Create issue / motd Configuration File /etc/issue /etc/issue.net /etc/motd
#-------------------------------------------------------------------------------
create_issue_motd() {
  dw_echo_colmsg "==> Create $motd_file ..." 1
  (
    echo "<< ${DW_LINUX} ${DW_VERSION} ($DW_CODENAME) >>"
    echo "The programs included with the system are free software."
    echo "the exact distribution terms for each program are described in the"
    echo "individual files in /usr/share/doc/*/copyright."
    echo ""
    echo "${DW_LINUX} ${DW_VERSION} ($DW_CODENAME) based on $issue_debian"
    echo "comes with ABSOLUTELY NO WARRANTY, to the extent permitted by applicable law."
  ) >$motd_file
  dw_echo_colmsg "==> Create $issue_file ..." 1
  (
    echo "${DW_LINUX} ${DW_VERSION} ($DW_CODENAME) based on $issue_debian (\n) (\l)"
  ) >$issue_file
  dw_echo_colmsg "==> Create $issue_file_net ..." 1
  (
    echo "${DW_LINUX} ${DW_VERSION} ($DW_CODENAME) based on $issue_debian (\n) (\l)"
  ) >$issue_file_net
}

#-------------------------------------------------------------------------------
# Create dawel-release Configuration File /etc/dawel-release
#-------------------------------------------------------------------------------
create_dw_release() {
  dw_echo_colmsg "==> Create $dw_release_file ..." 1
  (
    echo "${DW_LINUX} ${DW_VERSION} ($DW_CODENAME)"
  ) >$dw_release_file
}

#===============================================================================
# create crontab - Create crontab
#===============================================================================
create_crontab() {
  function check_entry() {
    # $1 varname
    # $2 min
    # $3 max
    # $4 default
    local __resultvar=$1
    local __resultvalue=${!1}
    if [[ ${__resultvalue} =~ ^[0-9]+$ ]]; then
      if [ $__resultvalue -lt $2 -o $__resultvalue -gt $3 ]; then
        eval $__resultvar="$4"
      fi
    else
      eval $__resultvar="$4"
    fi
  }

  check_entry "CRON_HOURLY_MINUTE" 0 59 17

  check_entry "CRON_DAILY_MINUTE" 0 59 25
  check_entry "CRON_DAILY_HOUR" 0 23 3

  check_entry "CRON_WEEKLY_MINUTE" 0 59 47
  check_entry "CRON_WEEKLY_HOUR" 0 23 3
  check_entry "CRON_WEEKLY_DAYOFWEEK" 0 7 7

  check_entry "CRON_MONTHLY_MINUTE" 0 59 52
  check_entry "CRON_MONTHLY_HOUR" 0 23 3
  check_entry "CRON_MONTHLY_DAYOFMONTH" 1 31 1

  crontab_file='/etc/crontab'
  crontab_root_file='/var/spool/cron/crontabs/root'

  dw_echo_colmsg "==> Create crontab $crontab_file & $crontab_root_file ..." 1
  (
    echo "# /etc/crontab: system-wide crontab"
    echo "# Unlike any other crontab you don't have to run the \`crontab'"
    echo "# command to install the new version when you edit this file"
    echo "# and files in /etc/cron.d. These files also have username fields,"
    echo "# that none of the other crontabs do."
    echo
    echo "SHELL=/bin/sh"
    echo "PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin"
    echo
    echo "# Example of job definition:"
    echo "# .---------------- minute (0 - 59)"
    echo "# |  .------------- hour (0 - 23)"
    echo "# |  |  .---------- day of month (1 - 31)"
    echo "# |  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ..."
    echo "# |  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat"
    echo "# |  |  |  |  |"
    echo "# *  *  *  *  * user-name command to be executed"
    echo "$CRON_HOURLY_MINUTE *	* * *	root    cd / && run-parts --report /etc/cron.hourly"
    echo "$CRON_DAILY_MINUTE $CRON_DAILY_HOUR	* * *	root	test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.daily )"
    echo "$CRON_WEEKLY_MINUTE $CRON_WEEKLY_HOUR	* * $CRON_WEEKLY_DAYOFWEEK	root	test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.weekly )"
    echo "$CRON_MONTHLY_MINUTE $CRON_MONTHLY_HOUR	$CRON_MONTHLY_DAYOFMONTH * *	root	test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.monthly )"
    echo "#"
    echo
  ) >$crontab_file
  chmod 0644 $crontab_file
  dw_sctl_restart cron
  if [ -x /sbin/dwanacronsynccron ]; then
    /sbin/dwanacronsynccron start
  fi
}

#===============================================================================
# backup - Backup /etc/dwconfig
#===============================================================================
do_backup() {
  do_backup_mail() {
    if [ -f $dwbackup_file ]; then
      if [ "$BACKUP_CONFIG_MAIL" = "yes" ]; then
        if [ -z "$(which mail)" ]; then
           dw_echo_colmsg "==> mail not found!" 1 e
           dw_echo_colmsg "==> Cannot send $dwbackup_file_mail_crypt via Mail ..." 2
           dw_echo_colmsg "==> Install dw-msmtp or dw-mailserver ..." 3 n
        else
          #øln -sf "$dwbackup_file" "$dwbackup_file_mail"
          cp "$dwbackup_file" "$dwbackup_file_mail"
          ccrypt -e -k "$dwbackup_file_passwd" "$dwbackup_file_mail"
          dw_echo_colmsg "==> Sending $dwbackup_file_mail_crypt via Mail ..." 2
          subject="$(hostname -f) dwsetup Backup Config vom $(dw_date) !"
          msg="You will find your dwsetup Config Backup in the appendix, use ccrypt -d *.cpt to decrypt:"
          dwmailbackup "-quiet" "$subject" "$msg" "$dwbackup_file_mail_crypt"
          if [ -f "$dwbackup_file_mail" ]; then
            rm "$dwbackup_file_mail"
          fi
          if [ -f "$dwbackup_file_mail_crypt" ]; then
            rm "$dwbackup_file_mail_crypt"
          fi
        fi
      fi
    fi
  }

  mkdir -p "$DW_BR_DIR"
  dw_get_dawel_pkg_installed > "$DW_BR_FILE_CONF"

  #cd /etc
  if [ -d letsencrypt ]; then
    tar cf $dwbackup_file -C /etc dwconfig.d letsencrypt
  else
    tar cf $dwbackup_file -C /etc dwconfig.d
  fi

  dw_echo_colmsg "==> Backup to $dwbackup_file ..." 1

  if [ "$1" == 'check' -a -f $dwbackup_file -a -f $dwbackup_file_last ]; then
    result=$(tardiff -m $dwbackup_file $dwbackup_file_last)
    if [ -n "$result" ]; then
      cp $dwbackup_file $dwbackup_file_last
      do_backup_mail
    else
      dw_echo_colmsg "==> $dwbackup_file Nothing Changed, Nothing to do ..." 2
    fi
  else
    cp $dwbackup_file $dwbackup_file_last
    do_backup_mail
  fi
}

#-------------------------------------------------------------------------------
# Create dwsetup Backup Password File
#-------------------------------------------------------------------------------
create_dwbackup_file_passwd() {
  dw_echo_colmsg "==> Create dwsetup Backup Password File $dwbackup_file_passwd ..." 1
  echo "$BACKUP_CONFIG_PASSWD" >$dwbackup_file_passwd
  chmod 0644 $dwbackup_file_passwd
}

#-------------------------------------------------------------------------------
# Create dwsetup Backup Cron Daily Script
#-------------------------------------------------------------------------------
create_dwsetup_backup_cronjob() {
  write_dwsetup_backup_cronjob() {
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      dw_conf_line
      echo "# $dwbackup_file_cron - dwsetup Backup Cronjob File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-base.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Base Configuration'"
      echo "#"
      echo "# in dwsetup > Base !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo '/var/dwsetup/config.d/dw-base.sh backup check > /dev/null 2>&1'
      dw_conf_footer e
    ) >$dwbackup_file_cron
  }
  dw_echo_colmsg "==> Create dwsetup Backup Cronjob $dwbackup_file_cron ..." 1
  write_dwsetup_backup_cronjob
  chmod 0744 $dwbackup_file_cron
}

#===============================================================================
# restore - Restore Backup /etc/dwconfig
#===============================================================================
do_restore() {
  do_backup_before_restore() {
    local dwbackup_file="/root/$(dw_date_backup_file)-dwsetup-restore-backup.tar"
    dw_echo_colmsg "==> Backup before Restore to $dwbackup_file ..." 0
    local old_dir=$(pwd)
    #cd /etc
    if [ -d letsencrypt ]; then
      tar cf $dwbackup_file -C /etc dwconfig.d letsencrypt
    else
      tar cf $dwbackup_file -C /etc dwconfig.d
    fi
    #cd "$old_dir"
  }
  do_remove_dawel_pkg_before_restore() {
    dw_echo_colmsg "==> Check Installed Packages ..." 0
    local pkgs=$(dw_get_dawel_pkg_installed | grep -Fxv 'dw-setup' | grep -Fxv 'dw-utils')
    if [ -n "$pkgs" ]; then
      dw_echo_colmsg "==> Remove Installed Packages ..." 1
      apt remove -y --purge $pkgs
    else
      dw_echo_colmsg "==> No Installed Packages found, Nothing do to ..." 1
    fi
  }

  do_restore_backup() {
    # remove dirs
    mkdir -p /etc/dwconfig.d
    rm -rf /etc/dwconfig.d/*
    if dw_backup_has_letsencrypt; then
      mkdir -p /etc/letsencrypt
      rm -rf /etc/letsencrypt/*
    fi
    # restore backup tar
    mkdir -p /etc
    tar xf $dwrestore_file -C /etc
    local restore_pkg_file="$DW_BR_FILE_CONF"
    if [ -f "$restore_pkg_file" ]; then
      dw_echo_colmsg "==> Restore Packages from $restore_pkg_file ..." 0 a
      apt update
      dw_echo_colmsg "==> Check Restore Packages from $restore_pkg_file ..." 0
      local pkgs=$(dw_check_dawel_pkg_restore "$restore_pkg_file")
      apt install --reinstall -y $pkgs
    else
      dw_echo_colmsg "==> Restore Packages File $restore_pkg_file not found, exit ..." 0 e
    fi
  }

  dwrestore_file="$dwbackup_file"
  if [ -n "$1" ]; then
    dwrestore_file="$1"
  fi

  if [ ! -f "$dwrestore_file" ]; then
    dw_echo_colmsg "Backup File $1 not found, exit ..." 0 e
    exit 1
  fi

  dw_echo_colmsg "==> Check $dwrestore_file is a Config Backup ..." 0
  if dw_is_backup_config_tar $dwrestore_file; then
    dw_echo_colmsg "==> $dwrestore_file is a Config Backup ..." 1 o
  else
    dw_echo_colmsg "==> $dwrestore_file is not a Config Backup, exit ..." 1 e
    exit 1
  fi

  dwrestore_hostname=$(dw_backup_config_tar_get_hostname $dwrestore_file)

  dwbeep
  if dw_ask "Restore Backup Configuration Hostname $dwrestore_hostname from $dwrestore_file ?" 0 a; then
    dwbeep 3
    if dw_ask "WARNING: All Config Data lost and overwritten ?" 0 a; then
      dw_echo_colmsg "==> Start Restore $dwrestore_file ..." 0 o
      do_backup_before_restore
      dw_anykey
      do_remove_dawel_pkg_before_restore
      dw_anykey
      dw_echo_colmsg "==> Restore from $dwrestore_file ..." 0
      do_restore_backup
      dw_echo_colmsg "It is recommended to do < apt autoremove >, for Cleanup Your System" 0 a
      dw_echo_colmsg "It is recommended to Reboot your System if" 0 a
      dw_echo_colmsg "You Changed Base Settings (e.g. IP Address)" 0 a
      dw_echo_colmsg "==> Finished Restore $dwrestore_file ..." 0 o
    fi
  fi
}

#===============================================================================
# check-useradd - Check Default useradd
#===============================================================================
check_useradd() {
  dw_echo_colmsg "==> Check Default useradd HOME /etc/default/useradd ..." 1
  data_dir_home="$DATA_DIR/home"
  if [ -n "$USERS_HOME_DIR" ]; then
    if [ ! "$USERS_HOME_DIR" = '/home' ]; then
      data_dir_home="$USERS_HOME_DIR/home"
    else
      data_dir_home="$USERS_HOME_DIR"
    fi
  fi
  data_dir_home_sed=$(echo "$data_dir_home" | sed 's/\//\\\//g')
  sed -i -e 's/.*HOME=.*$/HOME='$data_dir_home_sed'/' /etc/default/useradd
  if [ ! -d "$data_dir_home" ]; then
    mkdir -p "$data_dir_home"
  fi
  chmod 0755 "$data_dir_home"
}

#===============================================================================
# check-journald - Check Journald Settings
#===============================================================================
check_journald() {
  dw_echo_colmsg "==> Check Journald Settings $journald_file ..." 1
  if [ -n "$JOURNALD_SYSTEMMAXUSE" ]; then
    sed -i -e 's/.*SystemMaxUse=.*$/SystemMaxUse='$JOURNALD_SYSTEMMAXUSE'/' "$journald_file"
    dw_echo_colmsg "==> SystemMaxUse = $JOURNALD_SYSTEMMAXUSE" 2 o
  else
    sed -i -e 's/.*SystemMaxUse=.*$/#SystemMaxUse='$JOURNALD_SYSTEMMAXUSE'/' "$journald_file"
    dw_echo_colmsg "==> SystemMaxUse = 10% from Disk max. 4GB" 2 n
  fi
  dw_sctl_restart systemd-journald
}

#===============================================================================
# reconfig-services - Reconfigure Services
#===============================================================================
reconfig_services() {
  if [ -d "$services_reconfig_dir" ]; then
    dw_echo_colmsg "==> INFO: Reconfigure Services!" 1 n
    find "$services_reconfig_dir/" -type f -name "*.reconfig" -executable -exec "{}" \;
  fi
}

#===============================================================================
# reconfig-modprobe - Reconfigure Modprobe
#===============================================================================
reconfig_modprobe() {
  if [ -d "$modprobe_reconfig_dir" ]; then
    dw_echo_colmsg "==> INFO: Reconfigure Modprobe!" 1 n
    find "$modprobe_reconfig_dir/" -type f -name "*.reconfig" -executable -exec "{}" \;
  fi
}

#===============================================================================
# check-wlan_bt - Check Wlan Bluetooth
#===============================================================================
check_wlan_bt() {
  dw_echo_colmsg "==> Check Wlan ..." 1
  if [ "$DISABLE_WLAN" = "yes" ]; then
    dw_echo_colmsg "==> Wlan is disabled" 2 n
    rfkill block $(rfkill list | grep phy0 | cut -d : -f 1)
  else
    dw_echo_colmsg "==> Wlan is enabled" 2 o
    rfkill unblock $(rfkill list | grep phy0 | cut -d : -f 1)
  fi
  dw_echo_colmsg "==> Check Bluetooth ..." 1
  if [ "$DISABLE_BLUETOOTH" = "yes" ]; then
    dw_echo_colmsg "==> Bluetooth is disabled" 2 n
    rfkill block $(rfkill list | grep hci0 | cut -d : -f 1)
  else
    dw_echo_colmsg "==> Bluetooth is enabled" 2 o
    rfkill unblock $(rfkill list | grep hci0 | cut -d : -f 1)
  fi
}

#===============================================================================
# check-beeper - Check Beeper
#===============================================================================
check_beeper() {
  dw_echo_colmsg "==> Check Beeper ..." 1
  if [ "$BEEP_ENABLE" = "yes" ]; then
    dw_echo_colmsg "==> Beeper is enabled" 2 o
    if ! dw_is_pkg_installed dw-alsa; then
      dw_echo_colmsg "==> Install dw-alsa for Beeper Sound Configuration" 2 a
    fi
  else
    dw_echo_colmsg "==> Beeper is disabled" 2 n
  fi
}

#-------------------------------------------------------------------------------
# Check dwapt Check Update(s) Cron Daily Script
#-------------------------------------------------------------------------------
check_dwapt_check_cronjob() {
  write_dwapt_check_cronjob() {
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      dw_conf_line
      echo "# $dwapt_file_cron - dwapt Check Update(s) Cronjob File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-base.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Base Configuration'"
      echo "#"
      echo "# in dwsetup > Base !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo '/sbin/dwapt check notify > /dev/null 2>&1'
      dw_conf_footer e
    ) >$dwapt_file_cron
  }
  if [ "$APT_NOTIFY_MAIL" = 'yes' -o "$APT_NOTIFY_TELEGRAM" = 'yes' ]; then
    dw_echo_colmsg "==> Create dwapt Check Update(s) Cronjob $dwapt_file_cron..." 1
    write_dwapt_check_cronjob
    chmod 0744 $dwapt_file_cron
  else
    dw_echo_colmsg "==> Remove dwapt Check Update(s) Cronjob $dwapt_file_cron..." 1
    rm -f $dwapt_file_cron
  fi
  dw_sctl_restart cron
}

#===============================================================================
# Main
#===============================================================================

. /etc/dwconfig.d/release.config
. /etc/dwconfig.d/dw-base.config
. /var/dwsetup/bin/setup-functions

case "$1" in
backup)
  shift
  do_backup $@
  ;;
restore)
  shift
  do_restore $@
  ;;
check-useradd)
  check_useradd
  ;;
*)
  ### All Configuration Files ###
  # Fuck apparmor Shit
  if [ -f /etc/apparmor.d/usr.bin.msmtp ]; then
    ln -sf /etc/apparmor.d/usr.bin.msmtp /etc/apparmor.d/disable/usr.bin.msmtp
  fi
  check_modules_blacklist_file
  check_grub_settings
  check_locale
  check_keyboard
  check_timezone
  check_getty
  check_crtlaltdel
  check_numlock
  check_wlan_bt
  check_powermanagement
  check_swapfilesize
  check_vm_swapinnes
  #check_hostname
  #check_hosts
  #check_network
  check_ntp
  check_useradd
  create_crontab
  check_journald
  create_dwbackup_file_passwd
  create_dwsetup_backup_cronjob
  check_sshd
  check_bashrc
  create_issue_motd
  check_beeper
  check_dwapt_check_cronjob
  # Fix Console Setup Failure
  dw_sctl_enable console-setup
  dw_sctl_restart console-setup
  /var/dwsetup/config.d/dw-users.sh -quiet
  reconfig_services
  reconfig_modprobe
  depmod -a
  update-initramfs -u -k all
  check_hostname
  check_hosts
  check_network
  #Fix Runlevel 3 to 5 !!!
  #systemctl set-default graphical.target
  ;;
esac

#===============================================================================
# End
#===============================================================================
exit 0
