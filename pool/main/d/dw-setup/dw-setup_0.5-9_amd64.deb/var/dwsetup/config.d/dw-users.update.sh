#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-users.update.sh - Update or Generate New Users Configuration
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  25.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

config_file='dw-users.config'
config_header='/var/dwsetup/header/dw-users.config.header'

source_conf_file=/etc/dwconfig.d/$config_file
generate_conf_file=$source_conf_file

#------------------------------------------------------------------------------
# rename variables
#------------------------------------------------------------------------------
rename_variables ()
{
  renamed=0
  #dw_echo_colmsg "==> Renaming Parameter(s) ..." 2

  if [ $renamed = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Renamed Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# modify variables
#------------------------------------------------------------------------------
modify_variables ()
{
  modified=0
  #dw_echo_colmsg "==> Modifying Parameter(s) ..." 2

  if [ $modified = 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Modified Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# add variables
#------------------------------------------------------------------------------
add_variables ()
{
  added=0
  #dw_echo_colmsg "==> Adding New Parameter(s) ..." 2

  if [ $added -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for New Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# delete variables
#------------------------------------------------------------------------------
delete_variables ()
{
  deleted=0
  #dw_echo_colmsg "==> Deleting Old Parameters ..." 2

  if [ $deleted -eq 1 ]
  then
    dw_echo_colmsg "==> ... Read Documentation for Deleted Old Parameter(s)!" 3 a
    if [ "$quietflag" != "-quiet" ]
    then
      setup_anykey
    fi
    #else
    #  dw_echo_colmsg "==> ... Nothing to Do." 3 o
  fi
}

#------------------------------------------------------------------------------
# create new configuration
#------------------------------------------------------------------------------
create_config ()
{
  dw_echo_colmsg "==> Updating/Creating Configuration $source_conf ..." 2
  cat $config_header > $generate_conf
  (
    dw_conf_line
    echo "# Groups Settings"
    echo "#"
    echo "# (Prefix a Name with a ! to Disable it)"
    echo "# Valid ID >=300 and < 65534"
    dw_conf_line
    echo
    dw_conf_var "GROUPS_N"
    dw_conf_comment "# Number of Groups"
    if [ $GROUPS_N -eq 0 ]
    then
      imax=1
    else
      imax=$GROUPS_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval name='$GROUPS_'$idx'_NAME'
      eval id='$GROUPS_'$idx'_ID'
      echo "GROUPS_"$idx"_NAME=""'$name'"
      dw_conf_comment "# Group Name"
      echo "GROUPS_"$idx"_ID=""'$id'"
      dw_conf_comment "# Group ID"
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_line
    echo "# Users Settings"
    echo "#"
    echo "# (Prefix a Name with a ! to Disable it)"
    echo "# Valid ID >= 2000 and < 65534"
    echo "#"
    echo "# Do Disable Password Set PASSWD to ''"
    echo "# Do Disable Login and FTP Set SHELL to '/bin/false'"
    echo "# If SHELL Entry is Empty will '/bin/bash' automatically registered"
    echo "# If GROUP Entry is Empty will 'users' automatically registered"
    dw_conf_line
    echo
    dw_conf_var "USERS_N"
    dw_conf_comment "# Number of Users"
    if [ $USERS_N -eq 0 ]
    then
      imax=1
    else
      imax=$USERS_N
    fi
    idx=1
    while [ $idx -le $imax ]
    do
      eval name='$USERS_'$idx'_NAME'
      eval id='$USERS_'$idx'_ID'
      eval home='$USERS_'$idx'_HOME'
      eval passwd='$USERS_'$idx'_PASSWD'
      eval comment='$USERS_'$idx'_COMMENT'
      eval shell='$USERS_'$idx'_SHELL'
      eval group='$USERS_'$idx'_GROUP'
      eval add_group_n='$USERS_'$idx'_ADD_GROUPS_N'
      echo "USERS_"$idx"_NAME=""'$name'"
      dw_conf_comment "# User Name"
      echo "USERS_"$idx"_ID=""'$id'"
      dw_conf_comment "# User ID"
      echo "USERS_"$idx"_HOME=""'$home'"
      dw_conf_comment "# User Home Directory yes or no"
      echo "USERS_"$idx"_PASSWD=""'$passwd'"
      dw_conf_comment "# User Password"
      echo "USERS_"$idx"_COMMENT=""'$comment'"
      dw_conf_comment "# User Comment"
      echo "USERS_"$idx"_SHELL=""'$shell'"
      dw_conf_comment "# User Shell"
      echo "USERS_"$idx"_GROUP=""'$group'"
      dw_conf_comment "# User Group"
      echo "USERS_"$idx"_ADD_GROUPS_N=""'$add_group_n'"
      dw_conf_comment "# Number of Additional Group(s)"
      if [ $add_group_n -eq 0 ]
      then
        imaxag=1
      else
        imaxag=$add_group_n
      fi
      idxag=1
      while [ $idxag -le $imaxag ]
      do
        eval add_group='$USERS_'$idx'_ADD_GROUPS_'$idxag
        echo "USERS_"$idx"_ADD_GROUPS_"$idxag"=""'$add_group'"
        dw_conf_comment "# Additional Group Name"
        idxag=`expr $idxag + 1`
      done
      echo
      idx=$(expr $idx + 1)
    done
    dw_conf_footer
  ) >> $generate_conf
  dw_echo_colmsg "==> ... Finished." 1 o
  if [ "$quietflag" != "-quiet" ]
  then
    echo
    setup_anykey
  fi
}

#==============================================================================
# Main
#==============================================================================
. /var/dwsetup/bin/setup-functions

goflag=0
quietflag=$2

case "$1"
    in
  update)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file
    goflag=1
    ;;
  test)
    source_conf=$source_conf_file
    generate_conf=$source_conf_file.test
    goflag=1
    ;;
  *)
    echo
    echo "Use one of the following options:"
    echo
    echo "  $0 [update]"
    echo
    echo "  $source_conf_file will be read"
    echo "  $generate_conf_file configuration file will be written"
    echo "  the configuration will be checked and an updated."
    echo
    goflag=0
esac

if [ $goflag -eq 1 ]
then
  if [ -f $source_conf ]
  then
    # previous configuration file exists
    dw_echo_colmsg "==> Previous Configuration $source_conf found ..." 1
    . $source_conf

    rename_variables
    modify_variables
    add_variables
    delete_variables

    create_config
  else
    dw_echo_colmsg "==> No Configuration $source_conf found - exiting." 1 e
    setup_anykey
  fi
fi

#==============================================================================
# End
#==============================================================================
exit 0
