#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-users.sh - Configuration Generator Script for Users Settings
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  25.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

log_cmd="/tmp/$$log_cmd"
min_user_id='2000'
min_group_id='300'

errors='0'

#-------------------------------------------------------------------------------
# Do Log Command
#-------------------------------------------------------------------------------
do_log_cmd() {
  if [ -f $log_cmd ]; then
    [ "$quiet" != "quiet" ] && echo "         Command Returns:"
    while read line; do
      [ "$quiet" != "quiet" ] && echo "           $line"
    done <$log_cmd
    rm -f $log_cmd
  fi
}

#-------------------------------------------------------------------------------
# Check Groups
#-------------------------------------------------------------------------------
check_groups() {
  dw_echo_colmsg "==> Check Groups ..." 1
  idx='1'
  eval group_n='$GROUPS_N'
  while [ "$idx" -le "$group_n" ]; do
    do_it='0'
    eval group_name='$GROUPS_'$idx'_NAME'
    if dw_conf_var_is_enabled "$group_name"; then
      if [ "$group_name" != "" ]; then
        eval group_id='$GROUPS_'$idx'_ID'
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Group $group_name ID $group_id ..." 3
        if [ $group_id -ge $min_group_id ]; then
          # Check for Group Name
          chk_name=$(getent group $group_name)
          chk_group_name=$(echo $chk_name | cut -d: -f 1)
          chk_group_passwd=$(echo $chk_name | cut -d: -f 2)
          chk_group_id=$(echo $chk_name | cut -d: -f 3)
          chk_group_users=$(echo $chk_name | cut -d: -f 4)
          # Check for Group ID
          chk_id=$(getent group $group_id)
          chk_group_id_name=$(echo $chk_id | cut -d: -f 1)
          chk_group_id_passwd=$(echo $chk_id | cut -d: -f 2)
          chk_group_id_id=$(echo $chk_id | cut -d: -f 3)
          chk_group_id_users=$(echo $chk_id | cut -d: -f 4)
          if [ "$group_name" == "$chk_group_name" -a "$group_id" == "$chk_group_id_id" ]; then
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Group Name $group_name ID $group_id exists" 5 o
            do_it='1'
          else
            if [ "$group_name" == "$chk_group_name" ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Group Name $group_name exists ID $group_id = $chk_group_id !" 5 a
              errors=$(expr $errors + 1)
              do_it='1'
            fi
            if [ "$group_id" == "$chk_group_id_id" ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Group ID $group_id exists Name $group_name = $chk_group_id_name !" 5 a
              errors=$(expr $errors + 1)
              do_it='1'
            fi
          fi
          if [ $do_it -eq 0 ]; then
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Adding Group Name $group_name ID $group_id ..." 5 o
            groupadd -g $group_id $group_name &>$log_cmd
            if [ $? -eq 0 ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Group added" 5 o
            else
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Group not added !" 5 a
              do_log_cmd
              errors=$(expr $errors + 1)
            fi
          fi
        else
          [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Group $group_name has Gid $group_id defined, but Gid >= $min_group_id and Gid < 65534 is allowed !" 5 a
          errors=$(expr $errors + 1)
        fi
      else
        group_name_empty='GROUPS_'$idx'_NAME'
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Group $group_name_empty is empty, this is not allowed !" 3 a
        errors=$(expr $errors + 1)
      fi
    else
      group_name_disabled='GROUPS_'$idx'_NAME'
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Group $group_name_disabled is disabled !" 3 n
    fi
    idx=$(expr $idx + 1)
  done
  dw_echo_colmsg "==> Check Groups finished" 1
}

#-------------------------------------------------------------------------------
# Check Users
#-------------------------------------------------------------------------------
check_users() {
  #-----------------------------------------------------------------------------
  # Sub set_user_passwd - Set User Password
  #-----------------------------------------------------------------------------
  set_user_passwd() {
    if [ "$user_passwd" = "" ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Clear Password ..." 5 a
      crypt_user_passwd=''
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Password ..." 5
      #crypt_user_passwd=$(/sbin/dwcrypt $user_passwd)
      crypt_user_passwd=$(/usr/bin/openssl passwd -1 -salt 5RPVAd $user_passwd)
      # Linux
      usermod -p "$crypt_user_passwd" "$user_name" &>$log_cmd
      # Samba
      smb_passwd=$(which smbpasswd)
      if [ -n "$smb_passwd" ]; then
        (
          echo "$user_passwd"
          echo "$user_passwd"
        ) | smbpasswd -a -s "$user_name" &>/dev/null
      fi
    fi
    if [ $? -eq 0 ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Password success" 7 o
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Password failure !" 7 a
      do_log_cmd
      errors=$(expr $errors + 1)
    fi
  }

  #-----------------------------------------------------------------------------
  # Sub set_user_comment - Set User Comment
  #-----------------------------------------------------------------------------
  set_user_comment() {
    if [ "$user_comment" = "" ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Clear Comment ..." 5 a
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Comment $user_comment ..."
    fi
    usermod -c "$user_comment" "$user_name" &>$log_cmd
    if [ $? -eq 0 ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Comment success" 7 o
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Comment failure !" 7 a
      do_log_cmd
      errors=$(expr $errors + 1)
    fi
  }

  #-----------------------------------------------------------------------------
  # Sub set_user_group - Set User Group
  #-----------------------------------------------------------------------------
  set_user_group() {
    if [ "$user_group" != "" ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Group $user_group ..." 5
      chk_group=$(getent group "$user_group")
      if [ -n "$chk_group" ]; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Group $user_group found" 7 o
        usermod -g "$user_group" "$user_name"
        if [ $? -eq 0 ]; then
          [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting User Group success" 9 o
        else
          [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting User Group failure !" 9 a
        fi
      else
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Group $user_group failure, because not found ..." 7 a
      fi
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> No Group defined, nothing changed ..." 5 a
    fi
  }

  #-----------------------------------------------------------------------------
  # Sub set_user_add_groups - Set User Additional Groups
  #-----------------------------------------------------------------------------
  set_user_add_groups() {
    eval user_add_groups_n='$USERS_'$idx'_ADD_GROUPS_N'
    if [ $user_add_groups_n -gt 0 ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Additional Group(s) ..." 5
      idxag='1'
      user_add_groups=''
      while [ "$idxag" -le "$user_add_groups_n" ]; do
        eval add_group='$USERS_'$idx'_ADD_GROUPS_'$idxag
        if [ "$add_group" != "" ]; then
          if dw_conf_var_is_enabled "$add_group"; then
            chk_add_group=$(getent group "$add_group")
            if [ -n "$chk_add_group" ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Group $add_group found" 7 o
              if [ "$user_add_groups" == "" ]; then
                user_add_groups="$add_group"
              else
                user_add_groups="$user_add_groups,$add_group"
              fi
            else
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Additional Group $add_group failure, because not found ..." 7 a
              errors=$(expr $errors + 1)
            fi
          else
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Additional Group $add_group is disabled !" 3 n
          fi
        else
          add_group_empty='$USERS_'$idx'_ADD_GROUPS_'$idxag
          [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Additional Group $add_group_empty is empty, this is not allowed !" 7 a
          errors=$(expr $errors + 1)
        fi
        idxag=$(expr $idxag + 1)
      done
      if [ -z $user_add_groups ]; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> WARNING: Additional Groups are Empty, Try Clearing !" 7 a
      fi
      usermod -G "$user_add_groups" "$user_name" &>$log_cmd
      if [ $? -eq 0 ]; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Additional Group(s) success" 9 o
      else
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Additional Group(s) failure !" 9 a
        do_log_cmd
        errors=$(expr $errors + 1)
      fi
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> No Additional Group(s) defined ..." 5 a
    fi
  }

  #-----------------------------------------------------------------------------
  # Sub set_user_shell - Set User Shell
  #-----------------------------------------------------------------------------
  set_user_shell() {
    if [ "$user_shell" = "" ]; then
      user_shell='/bin/bash'
    fi
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Shell $user_shell ..." 5
    usermod -s "$user_shell" "$user_name" &>$log_cmd
    if [ $? -eq 0 ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Shell success" 7 o
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Shell failure !" 7 a
      do_log_cmd
      errors=$(expr $errors + 1)
    fi
  }

  #-----------------------------------------------------------------------------
  # Sub set_user_home_dir - Set User Home Directory
  #-----------------------------------------------------------------------------
  set_user_home_dir() {
    set_user=$(getent passwd $user_name)
    set_user_home=$(echo $set_user | cut -d: -f 6)
    user_home_dir='/home'
    if [ -n "$HOME" ]; then
      user_home_dir="$HOME/$user_name"
    fi
    if [ "$set_user_home" != "$user_home_dir" ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Home Directory $user_home_dir ..." 5
      usermod -m -d "$user_home_dir" "$user_name" &>$log_cmd
      if [ $? -eq 0 ]; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Home Directory success" 7 o
      else
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Home Directory failure !" 7 a
        do_log_cmd
        errors=$(expr $errors + 1)
      fi
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Home Directory = $user_home_dir, Nothing to do ..." 7 o
    fi
  }

  #-----------------------------------------------------------------------------
  # Sub set_user_home_dir_rights - Set User Home Directory Rights
  #-----------------------------------------------------------------------------
  set_user_home_dir_rights() {
    set_user=$(getent passwd $user_name)
    set_user_id=$(echo $set_user | cut -d: -f 3)
    set_user_gid=$(echo $set_user | cut -d: -f 4)
    set_user_home=$(echo $set_user | cut -d: -f 6)
    if [ -d $set_user_home ]; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Home Directory Owner $set_user_home ..." 5
      chown -Rf $set_user_id.$set_user_gid $set_user_home &>$log_cmd
      if [ $? -eq 0 ]; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Home Directory Owner success" 7 o
      else
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Home Directory Owner failure !" 7 a
        do_log_cmd
        errors=$(expr $errors + 1)
      fi
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Setting Home Directory Rights $set_user_home ..." 5
      chmod 0700 $set_user_home &>$log_cmd
      if [ $? -eq 0 ]; then
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Setting Home Directory Rights success" 7 o
      else
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Setting Home Directory Rights failure !" 7 a
        do_log_cmd
        errors=$(expr $errors + 1)
      fi
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Home Directory $set_user_home not exists ..." 5 a
      errors=$(expr $errors + 1)
    fi
  }

  #-----------------------------------------------------------------------------
  # Sub do_settings_user - Do User Settings
  #-----------------------------------------------------------------------------
  do_settings_user() {
    set_user_passwd
    set_user_comment
    set_user_group
    set_user_add_groups
    set_user_shell
    set_user_home_dir
    set_user_home_dir_rights
  }

  #-----------------------------------------------------------------------------

  dw_echo_colmsg "==> Check Users ..." 1
  idx='1'
  eval user_n='$USERS_N'
  while [ "$idx" -le "$user_n" ]; do
    do_it='0'
    eval user_name='$USERS_'$idx'_NAME'
    if dw_conf_var_is_enabled "$user_name"; then
      if [ "$user_name" != "" ]; then
        eval user_id='$USERS_'$idx'_ID'
        eval user_passwd='$USERS_'$idx'_PASSWD'
        eval user_comment='$USERS_'$idx'_COMMENT'
        eval user_group='$USERS_'$idx'_GROUP'
        eval user_shell='$USERS_'$idx'_SHELL'
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check User $user_name Uid $user_id ..." 3
        if [ $user_id -ge $min_user_id ]; then
          # Check for User Name
          chk_name=$(getent passwd $user_name)
          chk_user_name=$(echo $chk_name | cut -d: -f 1)
          chk_user_x=$(echo $chk_name | cut -d: -f 2)
          chk_user_id=$(echo $chk_name | cut -d: -f 3)
          chk_user_gid=$(echo $chk_name | cut -d: -f 4)
          chk_user_comment=$(echo $chk_name | cut -d: -f 5)
          chk_user_home=$(echo $chk_name | cut -d: -f 6)
          chk_user_shell=$(echo $chk_name | cut -d: -f 7)
          # Check for User ID
          chk_id=$(getent passwd $user_id)
          chk_user_id_name=$(echo $chk_id | cut -d: -f 1)
          chk_user_id_x=$(echo $chk_id | cut -d: -f 2)
          chk_user_id_id=$(echo $chk_id | cut -d: -f 3)
          chk_user_id_gid=$(echo $chk_id | cut -d: -f 4)
          chk_user_id_comment=$(echo $chk_id | cut -d: -f 5)
          chk_user_id_home=$(echo $chk_id | cut -d: -f 6)
          chk_user_id_shell=$(echo $chk_id | cut -d: -f 7)
          if [ "$user_name" == "$chk_user_name" -a "$user_id" == "$chk_user_id_id" ]; then
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: User Name $user_name Uid $user_id exists" 5 o
            do_settings_user
            do_it='1'
          else
            if [ "$user_name" == "$chk_user_name" ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: User Name $user_name exists Uid $user_id = $chk_user_id !" 5 a
              errors=$(expr $errors + 1)
              do_it='1'
            fi
            if [ "$user_id" == "$chk_user_id_id" ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: User Uid $user_id exists Name $user_name = $chk_user_id_name !" 5 a
              errors=$(expr $errors + 1)
              do_it='1'
            fi
          fi
          if [ $do_it -eq 0 ]; then
            [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Try Adding User Name $user_name Uid $user_id ..." 5
            useradd "$user_name" -u "$user_id" -m &>$log_cmd
            if [ $? -eq 0 ]; then
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Adding User success" 7 o
              do_settings_user
            else
              [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: Adding User failure !" 7 a
              do_log_cmd
              errors=$(expr $errors + 1)
            fi
          fi
        else
          [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: User $user_name has Uid $user_id defined, but Uid >= $min_user_id and Uid < 65534 is allowed !" 5 a
          errors=$(expr $errors + 1)
        fi
      else
        user_name_empty='USERS_'$idx'_NAME'
        [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> ERROR: User $user_name_empty is empty, this is not allowed !" 3 a
        errors=$(expr $errors + 1)
      fi
    else
      user_name_disabled='USERS_'$idx'_NAME'
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: User $user_name_disabled is disabled !" 3 n
    fi
    idx=$(expr $idx + 1)
  done
  dw_echo_colmsg "==> Check Users finished" 1
}

#-------------------------------------------------------------------------------
# Restart Shares Services
#-------------------------------------------------------------------------------
restart_services() {
  do_restart() {
    if dw_sctl_exists $1; then
      dw_sctl_restart $1
    fi
  }
  do_restart nmbd
  do_restart smbd
  do_restart nfs-kernel-server
  do_restart avahi-daemon
}

#===============================================================================
# Main
#===============================================================================

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-users.config
if [ -f /etc/default/useradd ]; then
  . /etc/default/useradd
fi

if [ "$1" == "-quiet" -o "$1" == "quiet" ]; then
  quiet="quiet"
else
  quiet=''
fi

/var/dwsetup/config.d/dw-base.sh check-useradd
check_groups
check_users
if [ $errors -gt 0 ]; then
  dw_echo_colmsg "==> ERROR: You have $errors Error(s) correct it !" 2 a
else
  dw_echo_colmsg "==> OK: No Error(s)" 2 o
fi
rm -f $log_cmd

restart_services

#===============================================================================
# End
#===============================================================================
exit 0
