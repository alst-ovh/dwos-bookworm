#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-shares.sh - Configuration Generator Script for Shares Settings
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  25.07.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

samba_shares_conf='/etc/samba/smb.shares.conf'
nfs_exports='/etc/exports'
dwdelrecycle_cronfile='/etc/cron.daily/dwdelrecycle'

#-------------------------------------------------------------------------------
# Check Share Directory exists
#-------------------------------------------------------------------------------
check_share_dir() {
  if [ ! -d "$1" ]; then
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Create Share Directory $1 ..." 2
    mkdir -p "$1"
  else
    [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> OK: Share Directory $1 exists ..." 2 o
  fi
  chmod 0777 "$1"
}

#-------------------------------------------------------------------------------
# Create Samba Shares
#-------------------------------------------------------------------------------
create_samba_shares() {
  dw_echo_colmsg "==> Check Shares Configuration ..." 1
  dw_conf_header "$samba_shares_conf" \
    "Shares Configuration File" \
    "Shares" >$samba_shares_conf
  if [ $SAMBA_RECYCLE_MAX_DAYS -le 0 ]; then
    sed -i -e 's/.*SAMBA_RECYCLE_MAX_DAYS=.*$/SAMBA_RECYCLE_MAX_DAYS='"'30'"'/' /etc/dwconfig.d/dw-samba.config
  fi
  if dw_conf_var_is_yes "$SAMBA_RECYCLE"; then
    (
      if [ -z $SAMBA_RECYCLE_NAME ]; then
        SAMBA_RECYCLE_NAME="Trash"
      fi
      echo "[$SAMBA_RECYCLE_NAME]"
      echo "   comment = Recycle Bin Directories"
      echo "   path = $DATA_DIR/.recycle/%u"
      echo "   writable = yes"
      echo "   guest ok = yes"
      echo
    ) >>$samba_shares_conf
    if [ ! -d "$DATA_DIR/.recycle" ]; then
      mkdir -p "$DATA_DIR/.recycle"
    fi
    chown root:root "$DATA_DIR/.recycle"
    chmod 0777 "$DATA_DIR/.recycle"
    users=$(pdbedit -L | cut -d: -f1)
    for u in $users; do
      #echo $u
      if [ ! -d "$DATA_DIR/.recycle/$u" ]; then
        mkdir -p "$DATA_DIR/.recycle/$u"
      fi
      chmod 0777 "$DATA_DIR/.recycle/$u"
      #chown $u:$u "$DATA_DIR/.recycle/$u"
    done
  fi
  if dw_conf_var_is_yes "$SHARES_HOME"; then
    (
      echo "[homes]"
      echo "   comment = Home Directories"
      echo "   browseable = no"
      echo "   writable = yes"
      echo "   valid users = %S"
      echo "   create mode = 0600"
      echo "   directory mode = 0700"
      echo
    ) >>$samba_shares_conf
  fi
  if dw_conf_var_is_yes "$SHARES_PUBLIC"; then
    check_share_dir "$DATA_DIR/Public"
    (
      echo "[Public]"
      echo "   comment = Public"
      echo "   path = $DATA_DIR/Public"
      echo "   browseable = yes"
      echo "   public = yes"
      echo "   guest ok = yes"
      echo "   writable = yes"
      echo
    ) >>$samba_shares_conf
  fi
  if [ ! -d /media ]; then
    mkdir /media
  fi
  chmod 0755 /media
  check_share_dir "/media"
  (
    echo "[Media]"
    echo "   comment = Usb Media"
    echo "   path = /media"
    echo "   browseable = yes"
    echo "   writable = yes"
    echo "   valid users = @users"
    echo
  ) >>$samba_shares_conf
  if dw_is_pkg_installed dw-osbackup; then
    check_share_dir "$DATA_DIR/OS-Backup"
    (
      echo "[OS-Backup]"
      echo "   comment = OS-Backup"
      echo "   path = $DATA_DIR/OS-Backup"
      echo "   browseable = yes"
      echo "   writable = no"
      echo "   valid users = @backup"
      echo
    ) >>$samba_shares_conf
  fi
  check_share_dir "/mnt/backup"
  (
    echo "[Backup]"
    echo "   comment = Backup"
    echo "   path = /mnt/backup"
    echo "   browseable = yes"
    echo "   writable = no"
    echo "   valid users = @backup"
    echo
  ) >>$samba_shares_conf
  if [ $SHARES_N -eq 0 ]; then
    imax=1
  else
    imax=$SHARES_N
  fi
  idx=1
  while [ $idx -le $imax ]; do
    eval name='$SHARES_'$idx'_NAME'
    eval path='$SHARES_'$idx'_PATH'
    eval comment='$SHARES_'$idx'_COMMENT'
    eval public='$SHARES_'$idx'_PUBLIC'
    eval browseable='$SHARES_'$idx'_BROWSEABLE'
    eval writable='$SHARES_'$idx'_WRITABLE'
    eval users_valid='$SHARES_'$idx'_USERS_VALID'
    eval users_read='$SHARES_'$idx'_USERS_READ'
    eval users_write='$SHARES_'$idx'_USERS_WRITE'
    eval force_user='$SHARES_'$idx'_FORCE_USER'
    eval force_group='$SHARES_'$idx'_FORCE_GROUP'
    #dw_echo_colmsg "==> Check Samba Timemachine Backup Configuration ..." 1
    #echo " ==> Check Samba Timemachine Backup Configuration ..." >> $log_file
    if dw_conf_var_is_enabled "$name"; then
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> Check Share $name ..." 1
      if [ -z $path ]; then
        check_share_dir "$DATA_DIR/$name"
      else
        check_share_dir "$path"
      fi
      (
        echo "[$name]"
        echo "    comment = $comment"
        if [ -z $path ]; then
          echo "    path = $DATA_DIR/$name"
        else
          echo "    path = $path"
        fi
        if dw_conf_var_is_yes "$browseable"; then
          echo "    browseable = yes"
        else
          echo "    browseable = no"
        fi
        if dw_conf_var_is_yes "$public"; then
          echo "    public = yes"
        else
          echo "    public = no"
        fi
        if dw_conf_var_is_yes "$writable"; then
          echo "    writable = yes"
        else
          echo "    writable = no"
        fi
        if [ -n "$users_valid" ]; then
          echo "    valid users = $users_valid"
        fi
        if [ -n "$users_read" ]; then
          echo "    read list = $users_read"
        fi
        if [ -n "$users_write" ]; then
          echo "    write list = $users_write"
        fi
        if [ -n "$force_user" ]; then
          echo "    force user = $force_user"
        fi
        if [ -n "$force_group" ]; then
          echo "    force group = $force_group"
        fi
        echo
      ) >>$samba_shares_conf
    else
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Share $name is disabled !" 1 n
    fi
    idx=$(expr $idx + 1)
  done
  dw_conf_footer >>$samba_shares_conf
}

#-------------------------------------------------------------------------------
# Create NFS Shares
#-------------------------------------------------------------------------------
create_nfs_exports() {
  dw_echo_colmsg "==> Create $nfs_exports ..." 1
  (
    dw_conf_line
    echo "# $nfs_exports - NFS-Server Exports Configuration File"
    echo "#"
    echo "# This file is automatically generated by /var/dwsetup/config.d/dw-shares.sh"
    echo "#"
    echo "# Do not edit this file, use"
    echo "#"
    echo "# 'Edit Configuration'"
    echo "#"
    echo "# in dwsetup > Shares !"
    echo "#"
    dw_conf_date "# Creation date:"
    dw_conf_line
    echo
    echo "# See exports(5) for a description."
    echo "# use exportfs -arv to reread"
    echo
  ) >$nfs_exports

  idx='1'
  #eval exports_n='$SHARES_NFS_EXPORTS_N'
  while [ "$idx" -le "$SHARES_NFS_EXPORTS_N" ]; do
    eval export_path='$SHARES_NFS_EXPORTS_'$idx'_PATH'
    if dw_conf_var_is_enabled "$export_path"; then
      eval export_option='$SHARES_NFS_EXPORTS_'$idx'_OPTION'
      eval export_machine='$SHARES_NFS_EXPORTS_'$idx'_MACHINE'
      echo "$export_path $export_machine($export_option)" >>$nfs_exports
    else
      export_path_disabled='SHARES_NFS_EXPORTS_'$idx'_PATH'
      [ "$quiet" != "quiet" ] && dw_echo_colmsg "==> INFO: Export $export_path_disabled is disabled !" 2 n
    fi
    idx=$(expr $idx + 1)
  done

  if dw_conf_var_is_yes "$SHARES_PUBLIC"; then
    if dw_conf_var_is_yes "$SHARES_PUBLIC_NFS"; then
      echo "$DATA_DIR/Public $export_machine($SHARES_PUBLIC_NFS_OPTION)" >>$nfs_exports
    fi
  fi

  idx=1
  while [ $idx -le $SHARES_N ]; do
    eval name='$SHARES_'$idx'_NAME'
    eval nfs='$SHARES_'$idx'_NFS'
    eval nfs_option='$SHARES_'$idx'_NFS_OPTION'
    #if dw_conf_var_is_enabled "$name"; then
    if dw_conf_var_is_enabled "$name"; then
      if dw_conf_var_is_yes "$nfs"; then
        echo "$DATA_DIR/$name $export_machine($nfs_option)" >>$nfs_exports
      fi
    fi
    idx=$(expr $idx + 1)
  done
  (
    echo
    dw_conf_footer
    echo
  ) >>$nfs_exports
}

#-------------------------------------------------------------------------------
# Check dwdelrecycle Script Cronjob
#-------------------------------------------------------------------------------
check_dwdelrecycle_cronjob() {
  write_dwdelrecycle_cronjob() {
    (
      echo "#!/bin/bash"
      echo 'MAILTO=""'
      dw_conf_line
      echo "# $dwdelrecycle_cronfile - dwdelrecycle Cronjob File"
      echo "#"
      echo "# This file is automatically generated by /var/dwsetup/config.d/dw-shares.sh"
      echo "#"
      echo "# Do not edit this file, use"
      echo "#"
      echo "# 'Edit Shares Configuration'"
      echo "#"
      echo "# in dwsetup > Shares !"
      echo "#"
      dw_conf_date "# Creation date:"
      dw_conf_line
      echo
      echo '/usr/sbin/dwdelrecycle'
      echo
      dw_conf_footer
      echo
    ) >$dwdelrecycle_cronfile
    chmod 0744 $dwdelrecycle_cronfile
  }
  dw_echo_colmsg "==> Check dwdelrecycle Script Cronjob Configuration ..." 1
  if dw_conf_var_is_yes "$SAMBA_RECYCLE"; then
    write_dwdelrecycle_cronjob
  else
    if [ -f $dwdelrecycle_cronfile ]; then
      rm -f $dwdelrecycle_cronfile
    fi
  fi
}

#===============================================================================
# Main
#===============================================================================

#. /var/dwsetup/lib/dw-all.libs
. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config
. /etc/dwconfig.d/dw-shares.config
if [ -f /etc/dwconfig.d/dw-samba.config ]; then
  . /etc/dwconfig.d/dw-samba.config
fi

if [ "$1" == "-quiet" -o "$1" == "quiet" ]; then
  quiet="quiet"
  shift
else
  quiet=''
fi

case "$1" in
smbd)
  if dw_is_pkg_installed dw-samba; then
    create_samba_shares
  else
    dw_echo_colmsg "==> Install dw-samba for SMB Shares Configuration" 0 a
  fi
  ;;
nfs)
  if dw_is_pkg_installed dw-nfs-server; then
    create_nfs_exports
  else
    dw_echo_colmsg "==> Install dw-nfs-server for NFS Shares Configuration" 0 a
  fi
  ;;
esac

check_dwdelrecycle_cronjob

#===============================================================================
# End
#===============================================================================
exit 0
