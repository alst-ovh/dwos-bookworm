#!/bin/bash
#-------------------------------------------------------------------------------
# /var/dwsetup/config.d/dw-docker.sh - Configuration Generator Script for Docker
#
# Copyright (c) 2003-2024 Albert Steiner <alst.ovh@gmail.com>
#
# Creation:     26.02.2003  alst
# Last Update:  09.05.2024  alst
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#-------------------------------------------------------------------------------

. /var/dwsetup/bin/setup-functions
. /etc/dwconfig.d/dw-base.config

#===============================================================================
# Main
#===============================================================================


#===============================================================================
# End
#===============================================================================
exit 0
